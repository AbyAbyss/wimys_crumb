// proto-types-history.jsx — File Types and History screens.

// ───────────────────────────────────────────────────────────────────────
// File types
// ───────────────────────────────────────────────────────────────────────

// Sample top files for each type — shown when a type card is expanded.
const TYPE_SAMPLES = {
  Video: [
    { name: 'family-2023.mov',           size: 18.2e9, mod: 240, where: '~/Movies' },
    { name: 'wedding-raw.mov',           size: 14.6e9, mod: 720, where: '~/Movies/Old' },
    { name: 'screen-rec-april.mp4',      size: 4.2e9,  mod: 24,  where: '~/Movies' },
    { name: 'travel-2021/iceland.mp4',   size: 3.8e9,  mod: 1100,where: '~/Movies' },
    { name: 'birthday-uncut.mov',        size: 3.1e9,  mod: 360, where: '~/Movies' },
  ],
  Photos: [
    { name: '2023 burst (412 photos)',   size: 2.4e9,  mod: 220, where: 'Photos Lib' },
    { name: 'iPhone backup',             size: 8.6e9,  mod: 4,   where: '~/Photos Library' },
    { name: 'screenshots/',              size: 1.2e9,  mod: 0,   where: '~/Desktop' },
  ],
  Code: [
    { name: 'node_modules (18)',         size: 41.2e9, mod: 240, where: '~/Developer' },
    { name: '.git/objects (×24)',        size: 9.8e9,  mod: 14,  where: '~/Developer' },
    { name: 'DerivedData/',              size: 14.8e9, mod: 22,  where: '~/Library' },
  ],
  Apps: [
    { name: 'Xcode.app',                 size: 18e9,   mod: 12,  where: '/Applications' },
    { name: 'Photoshop 2024.app',        size: 6.2e9,  mod: 80,  where: '/Applications' },
    { name: 'Final Cut Pro.app',         size: 5.4e9,  mod: 200, where: '/Applications' },
  ],
  Documents: [
    { name: 'Thesis-final-FINAL.pdf',    size: 220e6,  mod: 540, where: '~/Documents' },
    { name: 'Old contracts/ (×88)',      size: 1.6e9,  mod: 720, where: '~/Documents' },
  ],
  Music: [
    { name: 'iTunes Library',            size: 12e9,   mod: 89,  where: '~/Music' },
    { name: 'GarageBand projects/',      size: 4.2e9,  mod: 300, where: '~/Music' },
  ],
  Archives: [
    { name: 'Xcode_15.2.xip',            size: 8.4e9,  mod: 14,  where: '~/Downloads' },
    { name: 'photos-backup-2022.zip',    size: 6.2e9,  mod: 920, where: '~/Downloads' },
  ],
  Other: [
    { name: 'misc cached blobs',         size: 12e9,   mod: 90,  where: '~/Library/Caches' },
  ],
};

const PTypes = () => {
  const { state, nav, set } = React.useContext(AppCtx);
  const [active, setActive] = React.useState('Video');
  const total = FILE_TYPES.reduce((s, t) => s + t.size, 0);
  const activeType = FILE_TYPES.find((t) => t.name === active);
  const samples = TYPE_SAMPLES[active] || [];

  return (
    <div style={{ padding: '0 20px 20px', height: '100%',
      display: 'flex', flexDirection: 'column', gap: 14 }}>
      {/* Stacked bar hero */}
      <Card pad={20}>
        <div style={{ display: 'flex', alignItems: 'flex-start',
          justifyContent: 'space-between', marginBottom: 12 }}>
          <div>
            <div style={{ fontWeight: 700, fontSize: 15 }}>Disk by file type</div>
            <div style={{ fontSize: 12, color: A.ink2, marginTop: 2,
              maxWidth: 540, lineHeight: 1.4 }}>
              Click a slice (or a card below) to see the heaviest files in that bucket.
            </div>
          </div>
          <Pill color={A.honey} soft={A.honeySoft}>{fmtBytes(total)} scanned</Pill>
        </div>
        <div style={{ display: 'flex', height: 56, borderRadius: 12,
          overflow: 'hidden', border: '1px solid ' + A.line, background: A.line }}>
          {FILE_TYPES.map((t, i) => {
            const sel = active === t.name;
            return (
              <button key={t.name} onClick={() => setActive(t.name)}
                style={{
                  flex: t.size, background: A_HUES[i % A_HUES.length],
                  border: 'none', cursor: 'pointer', position: 'relative',
                  padding: 0, opacity: sel ? 1 : 0.86,
                  outline: sel ? '3px solid ' + A.ink : 'none',
                  outlineOffset: -3, transition: 'opacity .12s',
                }}
                title={`${t.name} — ${fmtBytes(t.size)}`}>
                <span style={{ position: 'absolute', top: 6, left: 8,
                  color: A.paper, fontSize: 11, fontWeight: 700,
                  textShadow: '0 0 4px rgba(0,0,0,.25)',
                  whiteSpace: 'nowrap', pointerEvents: 'none' }}>
                  {t.name}
                </span>
                <span style={{ position: 'absolute', bottom: 6, left: 8,
                  color: A.paper, fontSize: 11, fontWeight: 600, opacity: 0.92,
                  pointerEvents: 'none' }}>
                  {fmtBytes(t.size)}
                </span>
              </button>
            );
          })}
        </div>
      </Card>

      {/* Grid of types + detail panel */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 400px',
        gap: 14, flex: 1, minHeight: 0 }}>
        <Card pad={16} style={{ overflow: 'auto' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)',
            gap: 10 }}>
            {FILE_TYPES.map((t, i) => {
              const sel = active === t.name;
              const pct = (t.size / total) * 100;
              const color = A_HUES[i % A_HUES.length];
              return (
                <button key={t.name} onClick={() => setActive(t.name)}
                  style={{
                    border: '1px solid ' + (sel ? A.coral : A.line),
                    background: sel ? A.coralSoft + '55' : A.paper,
                    borderRadius: 12, padding: 14, textAlign: 'left',
                    cursor: 'pointer', fontFamily: 'inherit',
                    display: 'flex', flexDirection: 'column', gap: 8,
                    transition: 'transform .1s',
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-1px)'}
                  onMouseLeave={(e) => e.currentTarget.style.transform = ''}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <div style={{ width: 32, height: 32, borderRadius: 8,
                      background: color + '22', color,
                      display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <Icon name={t.icon} size={17} stroke={2} />
                    </div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 700, fontSize: 14 }}>{t.name}</div>
                      <div style={{ fontSize: 11, color: A.ink2 }}>
                        {t.count.toLocaleString()} files · {Math.round(pct)}% of disk
                      </div>
                    </div>
                    <div style={{ fontFamily: '"Bricolage Grotesque", sans-serif',
                      fontWeight: 800, fontSize: 18, letterSpacing: -0.5 }}>
                      {fmtBytes(t.size)}
                    </div>
                  </div>
                  <Bar pct={pct * 3 /* scale for visibility */} color={color} height={5} />
                </button>
              );
            })}
          </div>
        </Card>

        {/* Detail panel */}
        <Card pad={0} style={{ display: 'flex', flexDirection: 'column',
          overflow: 'hidden' }}>
          <div style={{ padding: '18px 20px',
            background: A_HUES[FILE_TYPES.findIndex((t) => t.name === active)] + '18',
            borderBottom: '1px solid ' + A.line }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ width: 44, height: 44, borderRadius: 11,
                background: A_HUES[FILE_TYPES.findIndex((t) => t.name === active)],
                color: A.paper, display: 'flex', alignItems: 'center',
                justifyContent: 'center' }}>
                <Icon name={activeType?.icon || 'other'} size={20} stroke={2} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: '"Bricolage Grotesque", sans-serif',
                  fontWeight: 800, fontSize: 22, letterSpacing: -0.5 }}>
                  {active}
                </div>
                <div style={{ fontSize: 12, color: A.ink2, marginTop: 2 }}>
                  {fmtBytes(activeType?.size || 0)} ·{' '}
                  {(activeType?.count || 0).toLocaleString()} files
                </div>
              </div>
            </div>
          </div>
          <div style={{ padding: '14px 20px', fontSize: 11, fontWeight: 700,
            color: A.ink3, letterSpacing: 0.5, textTransform: 'uppercase' }}>
            Biggest {active.toLowerCase()} files
          </div>
          <div style={{ flex: 1, overflow: 'auto' }}>
            {samples.map((s) => {
              const stale = s.mod > 180;
              return (
                <div key={s.name} style={{ display: 'flex', alignItems: 'center',
                  gap: 10, padding: '10px 20px',
                  borderTop: '1px solid ' + A.line }}>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 600,
                      whiteSpace: 'nowrap', textOverflow: 'ellipsis',
                      overflow: 'hidden' }}>{s.name}</div>
                    <div style={{ fontSize: 11, color: A.ink2,
                      whiteSpace: 'nowrap', textOverflow: 'ellipsis',
                      overflow: 'hidden' }}>
                      {s.where} · {fmtAge(s.mod)}{stale && ' · stale'}
                    </div>
                  </div>
                  <div style={{ fontFamily: '"Bricolage Grotesque", sans-serif',
                    fontWeight: 700, fontSize: 14,
                    fontVariantNumeric: 'tabular-nums',
                    color: stale ? A.red : A.ink }}>
                    {fmtBytes(s.size)}
                  </div>
                </div>
              );
            })}
          </div>
          <div style={{ padding: 14, borderTop: '1px solid ' + A.line,
            background: A.panel, display: 'flex', gap: 8 }}>
            <button
              onClick={() => set({ deleteOpen: true,
                deleteTargets: samples.filter((s) => s.mod > 180)
                  .map((s) => ({ path: s.where + '/' + s.name,
                    size: s.size, mod: s.mod })) })}
              style={{ background: A.coral, color: A.paper, border: 'none',
                borderRadius: 8, padding: '8px 12px', fontSize: 12,
                fontWeight: 600, cursor: 'pointer', flex: 1,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                gap: 6 }}>
              <Icon name="sparkle" size={12} stroke={2.2} />
              Clean stale {active.toLowerCase()}
            </button>
            <button onClick={() => set({ toast: { message:
              `Sorting Finder by largest ${active.toLowerCase()} file…` } })}
              style={{ background: A.paper, color: A.ink,
                border: '1px solid ' + A.line, borderRadius: 8,
                padding: '8px 12px', fontSize: 12, fontWeight: 600,
                cursor: 'pointer' }}>
              Show all in Finder
            </button>
          </div>
        </Card>
      </div>
    </div>
  );
};

// ───────────────────────────────────────────────────────────────────────
// History
// ───────────────────────────────────────────────────────────────────────

// Mock daily history — last 30 days. Slight upward trend with noise.
const HISTORY_DAILY = (() => {
  const out = [];
  const base = 570e9;
  for (let i = 29; i >= 0; i--) {
    const wobble = Math.sin(i * 0.6) * 4e9 + Math.cos(i * 0.3) * 3e9;
    const trend = (29 - i) * 1.5e9;
    out.push({ daysAgo: i, used: base + trend + wobble });
  }
  return out;
})();

// "What grew since last week" deltas.
const HISTORY_DELTAS = [
  { path: '~/Developer/dashboard-v2/node_modules', delta: +3.8e9, kind: 'grew' },
  { path: '~/Photos Library.photoslibrary',         delta: +2.1e9, kind: 'grew' },
  { path: '~/Library/Caches/com.apple.Safari',      delta: +1.4e9, kind: 'grew' },
  { path: '~/Downloads',                            delta: +0.9e9, kind: 'grew' },
  { path: '~/Library/Logs',                         delta: +0.4e9, kind: 'grew' },
  { path: '~/Movies/Old',                           delta: -8.2e9, kind: 'shrunk' },
  { path: '~/.Trash',                               delta: -3.1e9, kind: 'shrunk' },
];

const PHistory = () => {
  const { state, nav, set } = React.useContext(AppCtx);
  const max = Math.max(...HISTORY_DAILY.map((d) => d.used));
  const min = Math.min(...HISTORY_DAILY.map((d) => d.used));
  const range = max - min || 1;
  const W = 720, H = 200;
  const [hover, setHover] = React.useState(null);
  const grew = HISTORY_DELTAS.filter((d) => d.kind === 'grew');
  const shrunk = HISTORY_DELTAS.filter((d) => d.kind === 'shrunk');

  return (
    <div style={{ padding: '0 20px 20px', height: '100%',
      display: 'flex', flexDirection: 'column', gap: 14 }}>
      {/* Chart */}
      <Card pad={20}>
        <div style={{ display: 'flex', alignItems: 'flex-start',
          justifyContent: 'space-between', marginBottom: 14 }}>
          <div>
            <div style={{ fontWeight: 700, fontSize: 15 }}>Disk usage · last 30 days</div>
            <div style={{ fontSize: 12, color: A.ink2, marginTop: 2 }}>
              Hover the chart to inspect a day. Tracked via daily snapshots.
            </div>
          </div>
          <div style={{ display: 'flex', gap: 14, fontSize: 12 }}>
            <div>
              <div style={{ color: A.ink3, fontSize: 11, fontWeight: 600,
                letterSpacing: 0.4, textTransform: 'uppercase' }}>Today</div>
              <div style={{ fontFamily: '"Bricolage Grotesque", sans-serif',
                fontWeight: 800, fontSize: 20 }}>
                {fmtBytes(HISTORY_DAILY[HISTORY_DAILY.length - 1].used)}
              </div>
            </div>
            <div>
              <div style={{ color: A.ink3, fontSize: 11, fontWeight: 600,
                letterSpacing: 0.4, textTransform: 'uppercase' }}>30d change</div>
              <div style={{ fontFamily: '"Bricolage Grotesque", sans-serif',
                fontWeight: 800, fontSize: 20, color: A.coral }}>
                +{fmtBytes(HISTORY_DAILY[HISTORY_DAILY.length - 1].used
                  - HISTORY_DAILY[0].used)}
              </div>
            </div>
          </div>
        </div>

        <svg viewBox={`0 0 ${W} ${H + 30}`} style={{ width: '100%',
          height: H + 30, display: 'block' }}>
          {/* gridlines */}
          {[0, 1, 2, 3].map((i) => (
            <line key={i} x1="0" x2={W}
              y1={H - (H * i / 3)} y2={H - (H * i / 3)}
              stroke={A.line} strokeWidth="1" strokeDasharray="3 4" />
          ))}
          {/* area */}
          <defs>
            <linearGradient id="histArea" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={A.coral} stopOpacity="0.35" />
              <stop offset="100%" stopColor={A.coral} stopOpacity="0" />
            </linearGradient>
          </defs>
          {(() => {
            const pts = HISTORY_DAILY.map((d, i) => {
              const x = (i / (HISTORY_DAILY.length - 1)) * W;
              const y = H - ((d.used - min) / range) * (H - 20);
              return [x, y];
            });
            const line = pts.map((p, i) => (i === 0 ? 'M' : 'L') + p[0] + ' ' + p[1]).join(' ');
            const area = line + ` L${W} ${H} L0 ${H} Z`;
            return (
              <>
                <path d={area} fill="url(#histArea)" />
                <path d={line} fill="none" stroke={A.coral} strokeWidth="2.5"
                  strokeLinejoin="round" />
                {pts.map(([x, y], i) => (
                  <g key={i}>
                    {/* invisible hit area */}
                    <rect x={x - W / 60} y="0" width={W / 30} height={H}
                      fill="transparent"
                      onMouseEnter={() => setHover(i)}
                      onMouseLeave={() => setHover(null)} />
                    {hover === i && (
                      <>
                        <circle cx={x} cy={y} r="5" fill={A.paper}
                          stroke={A.coral} strokeWidth="2.5" />
                        <line x1={x} x2={x} y1={y - 6} y2={H}
                          stroke={A.coral} strokeWidth="1" strokeDasharray="2 3" />
                      </>
                    )}
                  </g>
                ))}
                {/* Today marker */}
                <circle cx={pts[pts.length - 1][0]} cy={pts[pts.length - 1][1]}
                  r="4" fill={A.coral} />
                <text x={pts[pts.length - 1][0]} y={pts[pts.length - 1][1] - 12}
                  fontFamily="Geist, sans-serif" fontWeight="600" fontSize="11"
                  fill={A.ink} textAnchor="middle">today</text>
              </>
            );
          })()}
          {/* x-axis labels */}
          {[0, 7, 14, 21, 29].map((di) => {
            const i = HISTORY_DAILY.findIndex((d) => d.daysAgo === (29 - di));
            const x = (i / (HISTORY_DAILY.length - 1)) * W;
            const label = di === 29 ? 'today' : di === 0 ? '30d ago' : (29 - di) + 'd ago';
            return (
              <text key={di} x={x} y={H + 20}
                fontFamily="Geist, sans-serif" fontSize="11" fill={A.ink3}
                textAnchor="middle">{label}</text>
            );
          })}
        </svg>
        {hover !== null && (
          <div style={{ marginTop: 4, fontSize: 12, color: A.ink2 }}>
            <b style={{ color: A.ink, fontFamily: '"Bricolage Grotesque", sans-serif',
              fontSize: 16 }}>
              {fmtBytes(HISTORY_DAILY[hover].used)}
            </b> &nbsp;·&nbsp; {HISTORY_DAILY[hover].daysAgo === 0
              ? 'today' : HISTORY_DAILY[hover].daysAgo + ' days ago'}
          </div>
        )}
      </Card>

      {/* Bottom: snapshots list + growers/shrinkers */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.4fr',
        gap: 14, flex: 1, minHeight: 0 }}>
        {/* Snapshots */}
        <Card pad={0} style={{ overflow: 'hidden', display: 'flex',
          flexDirection: 'column' }}>
          <div style={{ padding: '12px 16px', borderBottom: '1px solid ' + A.line,
            display: 'flex', alignItems: 'center' }}>
            <div style={{ fontWeight: 700, fontSize: 14 }}>Snapshots</div>
            <div style={{ flex: 1 }} />
            <Pill color={A.honey} soft={A.honeySoft}>{SNAPSHOTS.length} kept</Pill>
          </div>
          <div style={{ flex: 1, overflow: 'auto' }}>
            {SNAPSHOTS.map((s, i) => {
              const grew = s.delta > 0;
              return (
                <div key={s.when} style={{ display: 'grid',
                  gridTemplateColumns: '1fr auto auto auto', alignItems: 'center',
                  gap: 14, padding: '12px 16px',
                  borderBottom: i < SNAPSHOTS.length - 1
                    ? '1px solid ' + A.line : 'none' }}>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 600 }}>{s.when}</div>
                    <div style={{ fontSize: 11, color: A.ink2 }}>
                      {fmtBytes(s.used)} used
                    </div>
                  </div>
                  <div style={{ fontSize: 12, fontWeight: 600,
                    color: grew ? A.coral : A.sage,
                    display: 'flex', alignItems: 'center', gap: 4 }}>
                    <Icon name={grew ? 'arrowup' : 'arrowdn'} size={12} stroke={2.4} />
                    {fmtBytes(Math.abs(s.delta))}
                  </div>
                  <button onClick={() => set({ toast: { message:
                    `Comparing ${s.when} → today (mock).` } })}
                    style={{ background: A.panel, border: 'none', borderRadius: 7,
                      padding: '5px 9px', fontSize: 11, fontWeight: 600,
                      color: A.ink, cursor: 'pointer' }}>
                    Compare
                  </button>
                  <button onClick={() => set({ toast: { message:
                    `Restore from ${s.when}? (mock — would roll trash back).` } })}
                    style={{ background: 'transparent', border: 'none',
                      color: A.ink2, padding: 4, cursor: 'pointer' }}>
                    <Icon name="refresh" size={13} stroke={2} />
                  </button>
                </div>
              );
            })}
          </div>
          <div style={{ padding: 12, borderTop: '1px solid ' + A.line,
            background: A.panel, fontSize: 11, color: A.ink2,
            display: 'flex', alignItems: 'center', gap: 8 }}>
            <Icon name="clock" size={12} stroke={2} />
            Next snapshot tonight at 02:00 — runs automatically.
          </div>
        </Card>

        {/* Growers & shrinkers */}
        <Card pad={0} style={{ overflow: 'hidden', display: 'flex',
          flexDirection: 'column' }}>
          <div style={{ padding: '12px 16px', borderBottom: '1px solid ' + A.line,
            display: 'flex', alignItems: 'center' }}>
            <div style={{ fontWeight: 700, fontSize: 14 }}>
              What changed in the last week
            </div>
          </div>
          <div style={{ flex: 1, overflow: 'auto', padding: 14,
            display: 'flex', flexDirection: 'column', gap: 14 }}>
            {/* Growers */}
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8,
                marginBottom: 8 }}>
                <Icon name="arrowup" size={14} stroke={2.4}
                  style={{ color: A.coral }} />
                <div style={{ fontSize: 12, fontWeight: 700, color: A.ink,
                  letterSpacing: 0.3, textTransform: 'uppercase' }}>Grew</div>
              </div>
              {grew.map((d) => (
                <div key={d.path} style={{ display: 'grid',
                  gridTemplateColumns: '1fr 100px 80px', alignItems: 'center',
                  gap: 10, padding: '6px 0' }}>
                  <div style={{ fontFamily: '"Geist Mono", monospace', fontSize: 11,
                    color: A.ink, whiteSpace: 'nowrap', overflow: 'hidden',
                    textOverflow: 'ellipsis' }}>{d.path}</div>
                  <div style={{ height: 6, borderRadius: 3,
                    background: A.line, overflow: 'hidden' }}>
                    <div style={{ height: '100%',
                      width: (d.delta / 4e9 * 100) + '%',
                      background: A.coral, borderRadius: 3 }} />
                  </div>
                  <div style={{ fontWeight: 700, fontSize: 13,
                    color: A.coral, textAlign: 'right',
                    fontVariantNumeric: 'tabular-nums' }}>
                    +{fmtBytes(d.delta)}
                  </div>
                </div>
              ))}
            </div>

            {/* Shrinkers */}
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8,
                marginBottom: 8 }}>
                <Icon name="arrowdn" size={14} stroke={2.4}
                  style={{ color: A.sage }} />
                <div style={{ fontSize: 12, fontWeight: 700, color: A.ink,
                  letterSpacing: 0.3, textTransform: 'uppercase' }}>Shrank</div>
              </div>
              {shrunk.map((d) => (
                <div key={d.path} style={{ display: 'grid',
                  gridTemplateColumns: '1fr 100px 80px', alignItems: 'center',
                  gap: 10, padding: '6px 0' }}>
                  <div style={{ fontFamily: '"Geist Mono", monospace', fontSize: 11,
                    color: A.ink, whiteSpace: 'nowrap', overflow: 'hidden',
                    textOverflow: 'ellipsis' }}>{d.path}</div>
                  <div style={{ height: 6, borderRadius: 3,
                    background: A.line, overflow: 'hidden' }}>
                    <div style={{ height: '100%',
                      width: (Math.abs(d.delta) / 10e9 * 100) + '%',
                      background: A.sage, borderRadius: 3 }} />
                  </div>
                  <div style={{ fontWeight: 700, fontSize: 13,
                    color: A.sage, textAlign: 'right',
                    fontVariantNumeric: 'tabular-nums' }}>
                    −{fmtBytes(Math.abs(d.delta))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

Object.assign(window, { PTypes, PHistory, TYPE_SAMPLES, HISTORY_DAILY, HISTORY_DELTAS });
