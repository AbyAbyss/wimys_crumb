// a-screens.jsx — Direction A (Honey) screens.
// 7 desktop windows, each ~1280×820. Reuses helpers from a-base.jsx + shared.jsx.

// ───────────────────────────────────────────────────────────────────────
// Shared inside this direction
// ───────────────────────────────────────────────────────────────────────

const A_VIZ_TABS = [
  { id: 'tree',    label: 'Treemap'  },
  { id: 'sun',     label: 'Sunburst' },
  { id: 'list',    label: 'File tree'},
  { id: 'bars',    label: 'Bar list' },
  { id: 'bubble',  label: 'Bubbles'  },
];

const VizSwitcher = ({ active = 'tree' }) => (
  <div style={{
    display: 'inline-flex', gap: 2, padding: 4, background: A.panel,
    borderRadius: 10, border: '1px solid ' + A.line,
  }}>
    {A_VIZ_TABS.map((t) => (
      <div key={t.id} style={{
        padding: '6px 11px', fontSize: 12, fontWeight: 600,
        color: active === t.id ? A.ink : A.ink2,
        background: active === t.id ? A.paper : 'transparent',
        borderRadius: 7, boxShadow: active === t.id ? '0 1px 0 ' + A.line : 'none',
      }}>{t.label}</div>
    ))}
  </div>
);

// Simple two-row mosaic treemap from a sorted size list.
const Treemap = ({ items, width, height, colors = A_HUES }) => {
  const total = items.reduce((s, it) => s + it.size, 0);
  // Split into 2 rows: top row holds the first 3 items, bottom holds rest.
  const top = items.slice(0, 3);
  const bot = items.slice(3);
  const topSum = top.reduce((s, it) => s + it.size, 0);
  const botSum = bot.reduce((s, it) => s + it.size, 0);
  const topH = Math.round(height * (topSum / total));
  const botH = height - topH;
  return (
    <div style={{ width, height, display: 'flex', flexDirection: 'column',
      borderRadius: 14, overflow: 'hidden', gap: 4, background: A.line }}>
      <div style={{ height: topH, display: 'flex', gap: 4 }}>
        {top.map((it, i) => {
          const w = Math.max(80, (it.size / topSum) * (width - 4 * (top.length - 1)));
          return (
            <div key={it.name} style={{
              flex: it.size, height: '100%', background: colors[(it.color ?? i) % colors.length],
              padding: 14, color: A.paper, position: 'relative',
              display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
              fontWeight: 600,
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13,
                opacity: 0.95 }}>
                {it.protected && <Icon name="shield" size={14} stroke={2} />}
                {it.name}
              </div>
              <div style={{ fontFamily: '"Bricolage Grotesque", sans-serif',
                fontSize: 28, fontWeight: 700, letterSpacing: -0.6 }}>
                {fmtBytes(it.size)}
              </div>
            </div>
          );
        })}
      </div>
      <div style={{ height: botH, display: 'flex', gap: 4 }}>
        {bot.map((it, i) => (
          <div key={it.name} style={{
            flex: it.size, height: '100%',
            background: colors[(it.color ?? i + 3) % colors.length],
            padding: 10, color: A.paper, display: 'flex',
            flexDirection: 'column', justifyContent: 'space-between',
            fontWeight: 600, opacity: 0.92,
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 12,
              opacity: 0.95 }}>
              {it.protected && <Icon name="shield" size={12} stroke={2} />}
              {it.name}
            </div>
            <div style={{ fontFamily: '"Bricolage Grotesque", sans-serif',
              fontSize: 18, fontWeight: 700 }}>
              {fmtBytes(it.size)}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// ───────────────────────────────────────────────────────────────────────
// SCREEN 1 — Start / Empty state
// ───────────────────────────────────────────────────────────────────────
const A1_Start = () => (
  <Window title="Crumb — Disk Space">
    <AppBar />
    <div style={{ padding: '24px 20px 20px', display: 'grid',
      gridTemplateColumns: '1.4fr 1fr', gap: 16, height: 'calc(100% - 76px)' }}>
      {/* Hero */}
      <Card pad={32} style={{
        background: `linear-gradient(135deg, ${A.honeySoft} 0%, ${A.coralSoft} 100%)`,
        border: '1px solid ' + A.line2, display: 'flex', flexDirection: 'column',
        justifyContent: 'space-between', position: 'relative', overflow: 'hidden',
      }}>
        {/* Dotted scrapbook texture */}
        <div style={{
          position: 'absolute', inset: 0, opacity: 0.18,
          backgroundImage: `radial-gradient(${A.ink} 0.8px, transparent 1px)`,
          backgroundSize: '12px 12px',
        }} />
        <div style={{ position: 'relative' }}>
          <Pill color={A.coral} soft={A.paper}>● Ready to scan</Pill>
          <h1 style={{
            fontFamily: '"Bricolage Grotesque", sans-serif', fontWeight: 800,
            fontSize: 56, lineHeight: 1.02, letterSpacing: -1.5, margin: '18px 0 12px',
            color: A.ink, maxWidth: 480,
          }}>
            Where did<br/>your space go?
          </h1>
          <p style={{ fontSize: 15, color: A.ink2, margin: 0, maxWidth: 440, lineHeight: 1.5 }}>
            We&rsquo;ll sweep your drive, group what&rsquo;s eating space, and tell you what&rsquo;s
            safe to delete. Takes about 90 seconds.
          </p>
        </div>
        <div style={{ position: 'relative', display: 'flex', gap: 12, alignItems: 'center' }}>
          <button style={{
            background: A.ink, color: A.paper, border: 'none', borderRadius: 12,
            padding: '14px 22px', fontSize: 15, fontWeight: 600, cursor: 'pointer',
            display: 'flex', alignItems: 'center', gap: 10,
            boxShadow: '0 4px 0 ' + A.ink + ', 0 6px 18px rgba(42,33,24,.25)',
          }}>
            <Icon name="search" size={17} stroke={2.2} />
            Scan Macintosh HD
          </button>
          <button style={{
            background: 'transparent', color: A.ink, border: 'none',
            padding: '14px 8px', fontSize: 14, fontWeight: 500, cursor: 'pointer',
            textDecoration: 'underline', textUnderlineOffset: 4,
          }}>
            Pick a specific folder…
          </button>
        </div>
      </Card>

      {/* Drives */}
      <Card pad={20}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          marginBottom: 14 }}>
          <div style={{ fontWeight: 700, fontSize: 14, letterSpacing: 0.2,
            color: A.ink, textTransform: 'uppercase' }}>Drives</div>
          <Icon name="refresh" size={15} stroke={1.8} style={{ color: A.ink2 }} />
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {DRIVES.map((d, i) => {
            const pct = Math.round((d.used / d.total) * 100);
            const colors = [A.coral, A.honey, A.sage];
            const isFull = pct > 85;
            return (
              <div key={d.id} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <Donut pct={pct} size={56} stroke={7} color={isFull ? A.red : colors[i]}
                  track={A.line}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: A.ink }}>{pct}%</div>
                </Donut>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <div style={{ fontWeight: 600, fontSize: 14 }}>{d.name}</div>
                    {isFull && <Pill color={A.red} soft={A.redSoft}>almost full</Pill>}
                  </div>
                  <div style={{ fontSize: 12, color: A.ink2, marginTop: 2 }}>
                    {fmtBytes(d.used)} used of {fmtBytes(d.total)} · {d.kind}
                  </div>
                </div>
                <button style={{ background: A.panel, color: A.ink, border: 'none',
                  borderRadius: 8, padding: '7px 11px', fontSize: 12, fontWeight: 600,
                  cursor: 'pointer' }}>Scan</button>
              </div>
            );
          })}
        </div>
        <div style={{ borderTop: '1px solid ' + A.line, marginTop: 16, paddingTop: 14 }}>
          <div style={{ fontWeight: 700, fontSize: 13, color: A.ink, marginBottom: 8 }}>
            Last scans
          </div>
          {[
            ['Macintosh HD', '2 days ago', '608 GB used'],
            ['Time Machine', '1 week ago', '2.8 TB used'],
          ].map((r) => (
            <div key={r[0]} style={{ display: 'flex', justifyContent: 'space-between',
              padding: '7px 0', fontSize: 12, color: A.ink2 }}>
              <span style={{ color: A.ink }}>{r[0]}</span>
              <span>{r[1]} · {r[2]}</span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  </Window>
);

// ───────────────────────────────────────────────────────────────────────
// SCREEN 2 — Scanning in progress
// ───────────────────────────────────────────────────────────────────────
const A2_Scanning = () => {
  const pct = 64;
  return (
    <Window title="Crumb — Scanning…">
      <AppBar />
      <div style={{ padding: '24px 20px', display: 'grid', gridTemplateColumns: '1.2fr 1fr',
        gap: 16, height: 'calc(100% - 76px)' }}>
        {/* Progress hero */}
        <Card pad={28}>
          <Pill color={A.coral} soft={A.coralSoft}>
            <span style={{ width: 6, height: 6, borderRadius: '50%',
              background: A.coral, display: 'inline-block', animation: 'aPulse 1s infinite' }} />
            Scanning
          </Pill>
          <style>{`@keyframes aPulse{0%,100%{opacity:1}50%{opacity:.35}}`}</style>
          <h2 style={{ fontFamily: '"Bricolage Grotesque", sans-serif', fontWeight: 800,
            fontSize: 32, letterSpacing: -0.8, margin: '12px 0 4px', color: A.ink }}>
            Sweeping Macintosh HD
          </h2>
          <div style={{ fontSize: 13, color: A.ink2 }}>
            We&rsquo;ll group similar things and show you the big stuff.
          </div>

          {/* Big numbers */}
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 14, margin: '28px 0 18px' }}>
            <div style={{ fontFamily: '"Bricolage Grotesque", sans-serif',
              fontSize: 84, fontWeight: 800, letterSpacing: -3, lineHeight: 1, color: A.ink }}>
              {pct}<span style={{ fontSize: 36, color: A.coral }}>%</span>
            </div>
            <div style={{ flex: 1 }}>
              <Bar pct={pct} color={A.coral} height={10} />
              <div style={{ display: 'flex', justifyContent: 'space-between',
                marginTop: 10, fontSize: 12, color: A.ink2 }}>
                <span>412,320 / 643,210 files</span>
                <span>about 38s left</span>
              </div>
            </div>
          </div>

          <div style={{ background: A.panel, border: '1px solid ' + A.line, borderRadius: 12,
            padding: '12px 14px', fontFamily: '"Geist Mono", ui-monospace, monospace',
            fontSize: 12, color: A.ink2 }}>
            <div style={{ color: A.ink3, fontSize: 11, marginBottom: 4, fontFamily: '"Geist", sans-serif' }}>
              currently scanning
            </div>
            ~/Library/Application Support/Slack/Cache/v45-store
          </div>

          <div style={{ display: 'flex', gap: 8, marginTop: 18 }}>
            <button style={{ background: A.paper, border: '1px solid ' + A.line2,
              borderRadius: 10, padding: '9px 14px', fontSize: 13, fontWeight: 600,
              color: A.ink, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}>
              <Icon name="pause" size={14} fill="currentColor" stroke={0} />
              Pause
            </button>
            <button style={{ background: 'transparent', border: '1px solid ' + A.line2,
              borderRadius: 10, padding: '9px 14px', fontSize: 13, fontWeight: 600,
              color: A.ink2, cursor: 'pointer' }}>Cancel</button>
            <div style={{ flex: 1 }} />
            <label style={{ display: 'flex', alignItems: 'center', gap: 7, fontSize: 12,
              color: A.ink2 }}>
              <input type="checkbox" defaultChecked />
              Include hidden folders
            </label>
          </div>
        </Card>

        {/* Live preview list */}
        <Card pad={20}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            marginBottom: 12 }}>
            <div style={{ fontWeight: 700, fontSize: 14, letterSpacing: 0.2,
              textTransform: 'uppercase', color: A.ink }}>Biggest so far</div>
            <Pill color={A.honey} soft={A.honeySoft}>live</Pill>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {HOME_FOLDERS.slice(0, 6).map((f, i) => (
              <div key={f.name}>
                <div style={{ display: 'flex', justifyContent: 'space-between',
                  alignItems: 'center', marginBottom: 5 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
                    <Icon name="folder" size={14} fill={A_HUES[i % A_HUES.length]}
                      stroke={0} style={{ color: A_HUES[i % A_HUES.length] }} />
                    <span style={{ fontSize: 13, fontWeight: 500 }}>{f.name}</span>
                  </div>
                  <span style={{ fontSize: 12, color: A.ink2, fontVariantNumeric: 'tabular-nums' }}>
                    {fmtBytes(f.size)}
                  </span>
                </div>
                <Bar pct={(f.size / 142e9) * 100} color={A_HUES[i % A_HUES.length]} height={5} />
              </div>
            ))}
          </div>
          <div style={{ borderTop: '1px dashed ' + A.line2, marginTop: 14, paddingTop: 12,
            fontSize: 12, color: A.ink3, lineHeight: 1.5 }}>
            <Icon name="sparkle" size={14} stroke={1.8} style={{ verticalAlign: -2,
              color: A.honey, marginRight: 6 }} />
            Already spotted <b style={{ color: A.ink }}>14 stale node_modules</b> — about
            24 GB you could free.
          </div>
        </Card>
      </div>
    </Window>
  );
};

// ───────────────────────────────────────────────────────────────────────
// SCREEN 3 — Dashboard (Overview)
// ───────────────────────────────────────────────────────────────────────
const A3_Dashboard = () => (
  <Window title="Crumb — Overview">
    <AppBar active="overview" />
    <div style={{ padding: '14px 20px 20px', height: 'calc(100% - 76px)',
      display: 'flex', flexDirection: 'column', gap: 14 }}>
      {/* Stat row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
        {[
          { label: 'Used', value: fmtBytes(DISK.used), accent: A.coral,
            sub: '61% of 1 TB', delta: '+4.2 GB this week' },
          { label: 'Free', value: fmtBytes(DISK.free), accent: A.sage,
            sub: '39% available' },
          { label: 'Items scanned', value: '1.2M', accent: A.honey,
            sub: 'in 612K folders' },
          { label: 'Could free', value: '57 GB', accent: A.lilac,
            sub: '5 quick wins', isCta: true },
        ].map((s) => (
          <Card key={s.label} pad={14} style={{
            background: s.isCta ? A.ink : A.paper,
            color: s.isCta ? A.paper : A.ink,
            border: '1px solid ' + (s.isCta ? A.ink : A.line),
            position: 'relative', overflow: 'hidden',
          }}>
            <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 0.6,
              textTransform: 'uppercase', color: s.isCta ? A.honey : A.ink2 }}>
              {s.label}
            </div>
            <div style={{ fontFamily: '"Bricolage Grotesque", sans-serif',
              fontWeight: 800, fontSize: 32, letterSpacing: -0.8, marginTop: 4 }}>
              {s.value}
            </div>
            <div style={{ fontSize: 12, color: s.isCta ? '#D2C0A0' : A.ink2, marginTop: 2 }}>
              {s.sub}
            </div>
            {s.delta && (
              <Pill color={A.coral} soft={A.coralSoft} dark={false}>
                <Icon name="arrowup" size={11} stroke={2.4} />{s.delta}
              </Pill>
            )}
          </Card>
        ))}
      </div>

      {/* Main row: viz + suggestions */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr', gap: 14, flex: 1,
        minHeight: 0 }}>
        <Card pad={18} style={{ display: 'flex', flexDirection: 'column' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            marginBottom: 14 }}>
            <div>
              <div style={{ fontWeight: 700, fontSize: 15, color: A.ink }}>
                What&rsquo;s using your disk
              </div>
              <div style={{ fontSize: 12, color: A.ink2, marginTop: 2 }}>
                Bigger blocks = bigger folders. Click to drill in.
              </div>
            </div>
            <VizSwitcher active="tree" />
          </div>
          <div style={{ flex: 1, minHeight: 0 }}>
            <Treemap items={TOP_FOLDERS} width="100%" height={310} />
          </div>
          <div style={{ display: 'flex', gap: 6, marginTop: 14, flexWrap: 'wrap' }}>
            {TOP_FOLDERS.map((f, i) => (
              <div key={f.name} style={{ display: 'flex', alignItems: 'center', gap: 5,
                fontSize: 11, color: A.ink2 }}>
                <div style={{ width: 8, height: 8, borderRadius: 2,
                  background: A_HUES[(f.color ?? i) % A_HUES.length] }} />
                {f.name}
              </div>
            ))}
          </div>
        </Card>

        {/* Side: file types + suggestions */}
        <div style={{ display: 'grid', gridTemplateRows: '1fr 1fr', gap: 14 }}>
          <Card pad={16}>
            <div style={{ display: 'flex', justifyContent: 'space-between',
              alignItems: 'center', marginBottom: 10 }}>
              <div style={{ fontWeight: 700, fontSize: 14 }}>By file type</div>
              <span style={{ fontSize: 11, color: A.ink2 }}>612 GB total</span>
            </div>
            {FILE_TYPES.slice(0, 6).map((t, i) => {
              const pct = (t.size / 168e9) * 100;
              return (
                <div key={t.name} style={{ display: 'flex', alignItems: 'center', gap: 10,
                  padding: '4px 0' }}>
                  <div style={{ width: 22, height: 22, borderRadius: 6,
                    background: A_HUES[i % A_HUES.length] + '22',
                    color: A_HUES[i % A_HUES.length],
                    display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <Icon name={t.icon} size={13} stroke={2} />
                  </div>
                  <div style={{ flex: 1, fontSize: 12 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between',
                      marginBottom: 3 }}>
                      <span style={{ fontWeight: 500 }}>{t.name}</span>
                      <span style={{ color: A.ink2, fontVariantNumeric: 'tabular-nums' }}>
                        {fmtBytes(t.size)}
                      </span>
                    </div>
                    <Bar pct={pct} color={A_HUES[i % A_HUES.length]} height={4} />
                  </div>
                </div>
              );
            })}
          </Card>

          <Card pad={16} style={{ background: A.honeySoft, border: '1px solid ' + A.line2 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
              <Icon name="sparkle" size={16} stroke={2} style={{ color: A.coral }} />
              <div style={{ fontWeight: 700, fontSize: 14 }}>Quick wins</div>
              <div style={{ flex: 1 }} />
              <Pill color={A.coral} soft={A.paper}>save up to 57 GB</Pill>
            </div>
            {SUGGESTIONS.slice(0, 4).map((s, i) => (
              <div key={s.title} style={{
                display: 'flex', alignItems: 'center', gap: 10,
                background: A.paper, padding: '8px 10px', borderRadius: 8,
                marginBottom: i < 3 ? 6 : 0, border: '1px solid ' + A.line,
              }}>
                <div style={{ width: 6, height: 6, borderRadius: '50%',
                  background: s.kind === 'safe' ? A.sage : A.honey }} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 12, fontWeight: 600,
                    whiteSpace: 'nowrap', textOverflow: 'ellipsis', overflow: 'hidden' }}>
                    {s.title}
                  </div>
                  <div style={{ fontSize: 11, color: A.ink2, whiteSpace: 'nowrap',
                    textOverflow: 'ellipsis', overflow: 'hidden' }}>{s.detail}</div>
                </div>
                <div style={{ fontFamily: '"Bricolage Grotesque", sans-serif',
                  fontWeight: 700, fontSize: 14, color: A.coral }}>
                  {fmtBytes(s.save)}
                </div>
              </div>
            ))}
          </Card>
        </div>
      </div>
    </div>
  </Window>
);

// ───────────────────────────────────────────────────────────────────────
// SCREEN 4 — Drill-down (folder view)
// ───────────────────────────────────────────────────────────────────────
const A4_Drill = () => {
  const sel = HOME_FOLDERS[2]; // Developer selected
  return (
    <Window title="Crumb — Users/lina">
      <AppBar active="overview" />
      <div style={{ padding: '14px 20px 20px', height: 'calc(100% - 76px)' }}>
        {/* Breadcrumb */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 6,
          padding: '0 4px 12px', fontSize: 13, color: A.ink2 }}>
          <Icon name="drive" size={14} stroke={1.8} />
          <span>Macintosh HD</span>
          <Icon name="chevron" size={12} stroke={2} />
          <span>Users</span>
          <Icon name="chevron" size={12} stroke={2} />
          <span style={{ color: A.ink, fontWeight: 600 }}>lina</span>
          <Icon name="chevron" size={12} stroke={2} />
          <span style={{ color: A.ink3 }}>Developer</span>
          <div style={{ flex: 1 }} />
          <Pill color={A.honey} soft={A.honeySoft}>last scanned 2d ago</Pill>
          <div style={{ display: 'flex', gap: 4, padding: 3, background: A.panel,
            borderRadius: 8, border: '1px solid ' + A.line, marginLeft: 8 }}>
            <div style={{ padding: 5, borderRadius: 5, background: A.paper,
              boxShadow: '0 1px 0 ' + A.line }}>
              <Icon name="list" size={13} stroke={2} />
            </div>
            <div style={{ padding: 5, borderRadius: 5, color: A.ink2 }}>
              <Icon name="grid" size={13} stroke={2} />
            </div>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '200px 1fr 280px',
          gap: 14, height: 'calc(100% - 36px)' }}>
          {/* Tree */}
          <Card pad={12} style={{ overflow: 'auto' }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: A.ink3,
              letterSpacing: 0.5, textTransform: 'uppercase', padding: '0 4px 8px' }}>
              folders
            </div>
            {[
              { n: 'Macintosh HD', d: 0, open: true,  size: '612 GB' },
              { n: 'Applications', d: 1, open: false, size: '78 GB' },
              { n: 'Users',        d: 1, open: true,  size: '412 GB' },
              { n: 'lina',         d: 2, open: true,  size: '412 GB' },
              { n: 'Movies',       d: 3, open: false, size: '142 GB' },
              { n: 'Photos Lib',   d: 3, open: false, size: '96 GB' },
              { n: 'Developer',    d: 3, open: true,  size: '84 GB', sel: true },
              { n: 'dashboard-v2', d: 4, open: false, size: '12 GB' },
              { n: 'api-server',   d: 4, open: false, size: '9 GB' },
              { n: 'old-prototype',d: 4, open: false, size: '6 GB' },
              { n: 'Downloads',    d: 3, open: false, size: '38 GB' },
              { n: 'Documents',    d: 3, open: false, size: '22 GB' },
              { n: 'System',       d: 1, open: false, size: '42 GB' },
            ].map((r, i) => (
              <div key={i} style={{
                display: 'flex', alignItems: 'center', gap: 4,
                padding: '4px 6px', borderRadius: 6, marginLeft: r.d * 10,
                background: r.sel ? A.coralSoft : 'transparent',
                color: r.sel ? A.coral : A.ink,
                fontWeight: r.sel ? 600 : 400,
              }}>
                <Icon name={r.open ? 'chevdown' : 'chevron'} size={10}
                  stroke={2.2} style={{ color: A.ink3 }} />
                <Icon name="folder" size={12} fill={r.sel ? A.coral : A.honey}
                  stroke={0} style={{ color: r.sel ? A.coral : A.honey }} />
                <span style={{ fontSize: 12, flex: 1 }}>{r.n}</span>
                <span style={{ fontSize: 10, color: r.sel ? A.coral : A.ink3,
                  fontVariantNumeric: 'tabular-nums' }}>{r.size}</span>
              </div>
            ))}
          </Card>

          {/* Folder content */}
          <Card pad={0} style={{ display: 'flex', flexDirection: 'column' }}>
            <div style={{ padding: '12px 16px', borderBottom: '1px solid ' + A.line,
              display: 'flex', alignItems: 'center', gap: 10 }}>
              <Icon name="folder" size={20} fill={A.honey} stroke={0}
                style={{ color: A.honey }} />
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 700, fontSize: 15 }}>Developer</div>
                <div style={{ fontSize: 11, color: A.ink2 }}>
                  84 GB · 920,411 items · modified today
                </div>
              </div>
              <div style={{ display: 'flex', gap: 2, padding: 3, background: A.panel,
                borderRadius: 8, border: '1px solid ' + A.line, fontSize: 11 }}>
                {['size', 'name', 'date', 'age'].map((s, i) => (
                  <div key={s} style={{ padding: '4px 9px', borderRadius: 5,
                    background: i === 0 ? A.paper : 'transparent',
                    fontWeight: i === 0 ? 600 : 400,
                    color: i === 0 ? A.ink : A.ink2 }}>{s}</div>
                ))}
              </div>
            </div>
            <div style={{ flex: 1, overflow: 'auto' }}>
              {[
                { n: 'dashboard-v2',   sz: 12.4e9, items: '124K', mod: 0,   sub: 'node_modules · 8.4 GB' },
                { n: 'api-server',     sz: 9.2e9,  items: '88K',  mod: 1,   sub: 'node_modules · 3.8 GB' },
                { n: 'old-prototype',  sz: 6.0e9,  items: '62K',  mod: 620, sub: 'node_modules · 4.2 GB · stale', warn: true },
                { n: 'sandbox',        sz: 5.1e9,  items: '54K',  mod: 88,  sub: 'node_modules · 3.4 GB' },
                { n: 'portfolio',      sz: 4.6e9,  items: '48K',  mod: 540, sub: 'node_modules · 2.9 GB · stale', warn: true },
                { n: 'marketing-site', sz: 8.1e9,  items: '92K',  mod: 320, sub: 'node_modules · 6.1 GB' },
                { n: 'blog',           sz: 3.4e9,  items: '36K',  mod: 720, sub: 'node_modules · 2.2 GB · stale', warn: true },
                { n: 'internal-tools', sz: 3.0e9,  items: '32K',  mod: 210, sub: 'node_modules · 2.6 GB' },
                { n: '.git-archive',   sz: 1.8e9,  items: '4K',   mod: 90,  sub: 'hidden', hidden: true },
              ].map((r, i) => {
                const pct = (r.sz / 12.4e9) * 100;
                const isSel = i === 0;
                return (
                  <div key={r.n} style={{
                    display: 'grid', gridTemplateColumns: '24px 1.2fr 1fr 80px 80px',
                    alignItems: 'center', gap: 12, padding: '11px 16px',
                    borderBottom: '1px solid ' + A.line,
                    background: isSel ? A.coralSoft + '88' : 'transparent',
                    opacity: r.hidden ? 0.6 : 1,
                  }}>
                    <input type="checkbox" defaultChecked={r.warn} />
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, minWidth: 0 }}>
                      <Icon name={r.hidden ? 'hidden' : 'folder'} size={15}
                        fill={r.hidden ? 'none' : (r.warn ? A.red : A.honey)} stroke={r.hidden ? 1.8 : 0}
                        style={{ color: r.hidden ? A.ink3 : (r.warn ? A.red : A.honey) }} />
                      <div style={{ minWidth: 0 }}>
                        <div style={{ fontWeight: 600, fontSize: 13 }}>{r.n}</div>
                        <div style={{ fontSize: 11, color: r.warn ? A.red : A.ink2,
                          whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                          {r.sub}
                        </div>
                      </div>
                    </div>
                    <Bar pct={pct} color={r.warn ? A.red : A.coral} height={5} />
                    <div style={{ fontSize: 12, color: A.ink2, fontVariantNumeric: 'tabular-nums' }}>
                      {fmtAge(r.mod)}
                    </div>
                    <div style={{ fontFamily: '"Bricolage Grotesque", sans-serif',
                      fontWeight: 700, fontSize: 14, textAlign: 'right',
                      fontVariantNumeric: 'tabular-nums' }}>
                      {fmtBytes(r.sz)}
                    </div>
                  </div>
                );
              })}
            </div>
            <div style={{ padding: '10px 16px', borderTop: '1px solid ' + A.line,
              display: 'flex', alignItems: 'center', gap: 10, background: A.panel }}>
              <span style={{ fontSize: 12, color: A.ink2 }}>3 selected · 9.3 GB</span>
              <div style={{ flex: 1 }} />
              <button style={{ background: A.paper, border: '1px solid ' + A.line,
                borderRadius: 8, padding: '6px 12px', fontSize: 12, fontWeight: 600,
                color: A.ink }}>Move to Trash</button>
              <button style={{ background: A.coral, border: 'none',
                borderRadius: 8, padding: '6px 12px', fontSize: 12, fontWeight: 600,
                color: A.paper, display: 'flex', alignItems: 'center', gap: 5 }}>
                <Icon name="trash" size={12} stroke={2.2} />Delete
              </button>
            </div>
          </Card>

          {/* Detail panel */}
          <Card pad={16}>
            <div style={{ width: '100%', height: 72, borderRadius: 10,
              background: `linear-gradient(135deg, ${A.coral}, ${A.honey})`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: A.paper, marginBottom: 12 }}>
              <Icon name="folder" size={36} fill="currentColor" stroke={0} />
            </div>
            <div style={{ fontWeight: 700, fontSize: 15 }}>dashboard-v2</div>
            <div style={{ fontSize: 11, color: A.ink2, marginBottom: 14,
              wordBreak: 'break-all' }}>
              ~/Developer/dashboard-v2
            </div>
            {[
              ['Size', '12.4 GB'],
              ['Of which', 'node_modules · 8.4 GB'],
              ['Items', '124,310'],
              ['Last modified', 'today, 11:42'],
              ['Created', 'Aug 14, 2024'],
              ['Kind', 'Folder (Node project)'],
              ['Permissions', 'Read & write'],
            ].map((r) => (
              <div key={r[0]} style={{ display: 'flex', justifyContent: 'space-between',
                padding: '6px 0', borderTop: '1px solid ' + A.line, fontSize: 12 }}>
                <span style={{ color: A.ink2 }}>{r[0]}</span>
                <span style={{ fontWeight: 500 }}>{r[1]}</span>
              </div>
            ))}
            <div style={{ marginTop: 12, display: 'flex', flexDirection: 'column', gap: 6 }}>
              <button style={{ background: A.ink, color: A.paper, border: 'none',
                borderRadius: 8, padding: '9px 12px', fontSize: 12, fontWeight: 600,
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
                <Icon name="search" size={12} stroke={2.2} />Reveal in Finder
              </button>
              <button style={{ background: A.paper, color: A.ink, border: '1px solid ' + A.line,
                borderRadius: 8, padding: '9px 12px', fontSize: 12, fontWeight: 600,
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
                Clean node_modules only
              </button>
            </div>
          </Card>
        </div>
      </div>
    </Window>
  );
};

// ───────────────────────────────────────────────────────────────────────
// SCREEN 5 — Groups (by name across system)
// ───────────────────────────────────────────────────────────────────────
const A5_Groups = () => {
  // Bubble layout — fixed positions to look nice.
  const bubbles = [
    { ...GROUPS[0], cx: 200, cy: 130, r: 96, color: A.coral },
    { ...GROUPS[2], cx: 380, cy: 90,  r: 60, color: A.honey },
    { ...GROUPS[4], cx: 510, cy: 165, r: 56, color: A.sage  },
    { ...GROUPS[1], cx: 640, cy: 95,  r: 46, color: A.lilac },
    { ...GROUPS[5], cx: 730, cy: 175, r: 42, color: A.navy  },
    { ...GROUPS[6], cx: 840, cy: 105, r: 36, color: '#D86A8A' },
    { ...GROUPS[3], cx: 880, cy: 195, r: 22, color: '#7BAFD4' },
  ];
  return (
    <Window title="Crumb — Groups">
      <AppBar active="groups" />
      <div style={{ padding: '14px 20px 20px', height: 'calc(100% - 76px)',
        display: 'flex', flexDirection: 'column', gap: 14 }}>
        {/* Bubble chart hero */}
        <Card pad={20} style={{ background: A.paper, position: 'relative' }}>
          <div style={{ display: 'flex', alignItems: 'flex-start',
            justifyContent: 'space-between', marginBottom: 6 }}>
            <div>
              <div style={{ fontWeight: 700, fontSize: 15 }}>Groups by name</div>
              <div style={{ fontSize: 12, color: A.ink2, marginTop: 2,
                maxWidth: 480, lineHeight: 1.4 }}>
                Folders with the same name across your disk, totalled.
                Most apps re-download these on demand &mdash; clean away.
              </div>
            </div>
            <VizSwitcher active="bubble" />
          </div>
          <div style={{ position: 'relative', height: 240 }}>
            <svg width="100%" height="240" viewBox="0 0 1000 240" style={{ display: 'block' }}>
              {bubbles.map((b) => (
                <g key={b.name}>
                  <circle cx={b.cx} cy={b.cy} r={b.r} fill={b.color} opacity="0.9" />
                  <text x={b.cx} y={b.cy - 4} textAnchor="middle"
                    fontFamily="Geist, sans-serif" fontWeight="600"
                    fontSize={b.r > 50 ? 14 : 11} fill="#fff">
                    {b.name}
                  </text>
                  <text x={b.cx} y={b.cy + (b.r > 50 ? 14 : 10)} textAnchor="middle"
                    fontFamily="Bricolage Grotesque, sans-serif" fontWeight="800"
                    fontSize={b.r > 50 ? 22 : 14} fill="#fff">
                    {fmtBytes(b.total)}
                  </text>
                </g>
              ))}
            </svg>
          </div>
        </Card>

        {/* Group list */}
        <Card pad={0} style={{ flex: 1, overflow: 'hidden', display: 'flex',
          flexDirection: 'column' }}>
          <div style={{ padding: '12px 16px', borderBottom: '1px solid ' + A.line,
            display: 'flex', alignItems: 'center', gap: 10 }}>
            <input type="checkbox" />
            <div style={{ fontSize: 13, fontWeight: 600 }}>7 groups · 89.9 GB</div>
            <div style={{ flex: 1 }} />
            <Pill color={A.ink2} soft={A.panel}><Icon name="filter" size={11} stroke={2} />Stale only</Pill>
            <Pill color={A.coral} soft={A.coralSoft} dark>Free 38.4 GB</Pill>
          </div>
          <div style={{ flex: 1, overflow: 'auto' }}>
            {GROUPS.map((g, i) => {
              const isOpen = i === 0;
              return (
                <div key={g.name} style={{
                  borderBottom: '1px solid ' + A.line,
                  background: isOpen ? A.coralSoft + '55' : 'transparent',
                }}>
                  <div style={{ display: 'grid',
                    gridTemplateColumns: '24px 24px 1.4fr 1fr 1fr 100px 100px',
                    alignItems: 'center', gap: 10, padding: '10px 16px' }}>
                    <input type="checkbox" defaultChecked={i === 0 || i === 2} />
                    <Icon name={isOpen ? 'chevdown' : 'chevron'} size={14} stroke={2}
                      style={{ color: A.ink2 }} />
                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <span style={{ fontFamily: '"Geist Mono", monospace',
                          fontWeight: 600, fontSize: 13 }}>{g.name}</span>
                        {g.devOnly && <Pill color={A.lilac} soft={A.lilacSoft}>dev</Pill>}
                      </div>
                      <div style={{ fontSize: 11, color: A.ink2, marginTop: 2 }}>
                        {g.tagline}
                      </div>
                    </div>
                    <div style={{ fontSize: 12, color: A.ink2 }}>
                      {g.count} folders
                    </div>
                    <div style={{ fontSize: 12, color: A.ink2 }}>
                      avg age {fmtAge(g.avgAge)}
                    </div>
                    <div style={{ width: 80 }}>
                      <Bar pct={(g.total / 42e9) * 100}
                        color={i === 0 ? A.coral : (i % 2 ? A.honey : A.sage)} height={5} />
                    </div>
                    <div style={{ fontFamily: '"Bricolage Grotesque", sans-serif',
                      fontWeight: 700, fontSize: 18, textAlign: 'right',
                      fontVariantNumeric: 'tabular-nums' }}>
                      {fmtBytes(g.total)}
                    </div>
                  </div>
                  {isOpen && g.instances && (
                    <div style={{ padding: '0 16px 12px 64px' }}>
                      {g.instances.slice(0, 6).map((it) => {
                        const stale = it.mod > 180;
                        return (
                          <div key={it.path} style={{ display: 'grid',
                            gridTemplateColumns: '24px 1.5fr 100px 90px 100px',
                            alignItems: 'center', gap: 10, padding: '7px 8px',
                            borderRadius: 8 }}>
                            <input type="checkbox" defaultChecked={stale} />
                            <div style={{ fontFamily: '"Geist Mono", monospace',
                              fontSize: 11, color: A.ink2,
                              whiteSpace: 'nowrap', overflow: 'hidden',
                              textOverflow: 'ellipsis' }}>{it.path}</div>
                            <div style={{ fontSize: 11, color: stale ? A.red : A.ink2,
                              fontWeight: stale ? 600 : 400 }}>
                              {fmtAge(it.mod)}{stale && ' · stale'}
                            </div>
                            <Bar pct={(it.size / 8.4e9) * 100}
                              color={stale ? A.red : A.coral} height={4} />
                            <div style={{ fontSize: 12, fontWeight: 600, textAlign: 'right',
                              fontVariantNumeric: 'tabular-nums' }}>{fmtBytes(it.size)}</div>
                          </div>
                        );
                      })}
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8,
                        padding: '10px 8px 4px', fontSize: 11, color: A.ink3 }}>
                        + 2 more instances
                        <div style={{ flex: 1 }} />
                        <button style={{ background: A.ink, color: A.paper, border: 'none',
                          borderRadius: 8, padding: '7px 12px', fontSize: 12,
                          fontWeight: 600, display: 'flex', alignItems: 'center', gap: 5 }}>
                          <Icon name="trash" size={12} stroke={2.2} />
                          Delete 3 selected · free 9.8 GB
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </Card>
      </div>
    </Window>
  );
};

// ───────────────────────────────────────────────────────────────────────
// SCREEN 6 — Delete confirmation w/ protected warning
// ───────────────────────────────────────────────────────────────────────
const A6_Delete = () => {
  const total = DELETE_TARGETS.reduce((s, t) => s + t.size, 0);
  return (
    <Window title="Crumb — Confirm cleanup">
      <AppBar active="groups" />
      {/* Dim backdrop */}
      <div style={{ position: 'absolute', top: 76, left: 0, right: 0, bottom: 0,
        background: 'rgba(42,33,24,0.36)', backdropFilter: 'blur(2px)' }} />
      <div style={{ position: 'relative', height: 'calc(100% - 76px)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
        <div style={{
          width: 580, background: A.paper, borderRadius: 20,
          boxShadow: '0 30px 80px rgba(42,33,24,.25), 0 0 0 1px ' + A.line2,
          overflow: 'hidden',
        }}>
          <div style={{ padding: '24px 26px 16px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ width: 44, height: 44, borderRadius: 12,
                background: A.coralSoft, color: A.coral,
                display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Icon name="trash" size={20} stroke={2} />
              </div>
              <div style={{ flex: 1 }}>
                <h3 style={{ fontFamily: '"Bricolage Grotesque", sans-serif',
                  fontWeight: 800, fontSize: 22, letterSpacing: -0.4, margin: 0 }}>
                  Delete 5 items?
                </h3>
                <div style={{ fontSize: 13, color: A.ink2, marginTop: 2 }}>
                  Frees about <b style={{ color: A.ink }}>{fmtBytes(total)}</b> on Macintosh HD.
                </div>
              </div>
            </div>

            {/* Protected warning */}
            <div style={{ marginTop: 18, padding: '12px 14px', borderRadius: 12,
              background: A.redSoft, border: '1px solid #EBC5BC',
              display: 'flex', gap: 10, alignItems: 'flex-start' }}>
              <Icon name="shield" size={18} stroke={2} style={{ color: A.red, marginTop: 1 }} />
              <div style={{ fontSize: 12.5, color: '#7A2618', lineHeight: 1.5 }}>
                <b>1 protected path was excluded.</b> <span style={{ color: '#A1422E' }}>
                /System/Library/Caches is part of macOS &mdash; deleting it can
                break apps or boot. We&rsquo;ll skip it.</span>
              </div>
            </div>
          </div>

          {/* Item list */}
          <div style={{ background: A.panel, borderTop: '1px solid ' + A.line,
            borderBottom: '1px solid ' + A.line, maxHeight: 220, overflow: 'auto' }}>
            {DELETE_TARGETS.map((t) => (
              <div key={t.path} style={{ display: 'grid',
                gridTemplateColumns: '18px 1fr 90px 80px', alignItems: 'center', gap: 10,
                padding: '10px 26px', borderBottom: '1px solid ' + A.line,
                opacity: t.protected ? 0.55 : 1,
                background: t.protected ? A.redSoft + '55' : 'transparent' }}>
                {t.protected
                  ? <Icon name="shield" size={14} stroke={2} style={{ color: A.red }} />
                  : <Icon name="trash" size={13} stroke={2} style={{ color: A.ink2 }} />}
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontFamily: '"Geist Mono", monospace', fontSize: 11.5,
                    color: A.ink, whiteSpace: 'nowrap', overflow: 'hidden',
                    textOverflow: 'ellipsis' }}>{t.path}</div>
                  {t.protected && (
                    <div style={{ fontSize: 10.5, color: A.red, marginTop: 2 }}>
                      Skipped — system protected
                    </div>
                  )}
                </div>
                <div style={{ fontSize: 11, color: A.ink2 }}>
                  {fmtAge(t.mod)}
                </div>
                <div style={{ fontFamily: '"Bricolage Grotesque", sans-serif',
                  fontWeight: 700, fontSize: 14, textAlign: 'right',
                  textDecoration: t.protected ? 'line-through' : 'none' }}>
                  {fmtBytes(t.size)}
                </div>
              </div>
            ))}
          </div>

          {/* Options + actions */}
          <div style={{ padding: '14px 26px 20px' }}>
            <div style={{ display: 'flex', gap: 8, marginBottom: 14 }}>
              {[
                { id: 'trash', label: 'Move to Trash', sub: 'recoverable', on: true },
                { id: 'gone',  label: 'Delete forever', sub: 'no undo', on: false },
              ].map((o) => (
                <div key={o.id} style={{
                  flex: 1, padding: '10px 12px', borderRadius: 12,
                  border: '1.5px solid ' + (o.on ? A.coral : A.line),
                  background: o.on ? A.coralSoft + '55' : A.paper,
                  display: 'flex', alignItems: 'center', gap: 10,
                }}>
                  <div style={{ width: 16, height: 16, borderRadius: '50%',
                    border: '2px solid ' + (o.on ? A.coral : A.line2),
                    display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    {o.on && <div style={{ width: 8, height: 8, borderRadius: '50%',
                      background: A.coral }} />}
                  </div>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 600 }}>{o.label}</div>
                    <div style={{ fontSize: 11, color: A.ink2 }}>{o.sub}</div>
                  </div>
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: 6,
                fontSize: 12, color: A.ink2 }}>
                <input type="checkbox" defaultChecked />
                Take snapshot first (undo for 30 days)
              </label>
              <div style={{ flex: 1 }} />
              <button style={{ background: 'transparent', border: 'none',
                color: A.ink2, fontSize: 13, fontWeight: 600, padding: '10px 14px',
                cursor: 'pointer' }}>Cancel</button>
              <button style={{ background: A.coral, color: A.paper, border: 'none',
                borderRadius: 10, padding: '11px 18px', fontSize: 13, fontWeight: 700,
                boxShadow: '0 3px 0 #B33E1F', cursor: 'pointer' }}>
                Move 4 items · free {fmtBytes(total - 2.1e9)}
              </button>
            </div>
          </div>
        </div>
      </div>
    </Window>
  );
};

// ───────────────────────────────────────────────────────────────────────
// SCREEN 7 — Settings
// ───────────────────────────────────────────────────────────────────────
const Toggle = ({ on, color = A.coral }) => (
  <div style={{ width: 36, height: 20, borderRadius: 999,
    background: on ? color : A.line2, padding: 2, transition: 'background .15s' }}>
    <div style={{ width: 16, height: 16, borderRadius: '50%', background: A.paper,
      transform: on ? 'translateX(16px)' : 'translateX(0)',
      transition: 'transform .15s',
      boxShadow: '0 1px 2px rgba(0,0,0,.2)' }} />
  </div>
);

const A7_Settings = () => (
  <Window title="Crumb — Settings">
    <AppBar active="overview" />
    <div style={{ padding: '14px 20px 20px', height: 'calc(100% - 76px)',
      display: 'grid', gridTemplateColumns: '210px 1fr', gap: 14 }}>
      {/* Settings sidebar */}
      <Card pad={10}>
        <div style={{ fontSize: 10, fontWeight: 700, color: A.ink3,
          letterSpacing: 0.6, textTransform: 'uppercase', padding: '4px 8px 8px' }}>
          Settings
        </div>
        {[
          ['Scans',       'cog',     false],
          ['Detection',   'sparkle', false],
          ['Safety',      'shield',  true],
          ['Snapshots',   'clock',   false],
          ['Export',      'download',false],
          ['About',       'other',   false],
        ].map(([n, icon, sel]) => (
          <div key={n} style={{
            display: 'flex', alignItems: 'center', gap: 9, padding: '8px 10px',
            borderRadius: 8, fontSize: 13, fontWeight: sel ? 600 : 500,
            color: sel ? A.coral : A.ink, background: sel ? A.coralSoft : 'transparent',
            marginBottom: 2,
          }}>
            <Icon name={icon} size={15} stroke={1.8} />
            {n}
          </div>
        ))}
      </Card>

      {/* Active section: Safety */}
      <Card pad={24} style={{ overflow: 'auto' }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14,
          paddingBottom: 18, borderBottom: '1px solid ' + A.line, marginBottom: 18 }}>
          <div style={{ width: 44, height: 44, borderRadius: 12, background: A.coralSoft,
            color: A.coral, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Icon name="shield" size={22} stroke={2} />
          </div>
          <div>
            <h2 style={{ fontFamily: '"Bricolage Grotesque", sans-serif',
              fontWeight: 800, fontSize: 24, letterSpacing: -0.5, margin: 0 }}>
              Safety
            </h2>
            <div style={{ fontSize: 13, color: A.ink2, marginTop: 4 }}>
              What Crumb refuses to delete &mdash; even if you tell it to.
            </div>
          </div>
        </div>

        {/* Toggles */}
        {[
          ['Protect system paths',      'Always skip /System, /usr, /private, and Windows / Linux equivalents.', true],
          ['Protect active projects',   'Skip folders modified in the last 7 days unless explicitly chosen.',     true],
          ['Confirm large deletes',     'Show this dialog for any cleanup over 1 GB.',                            true],
          ['Always snapshot first',     'Keeps a 30-day rollback. Uses ~1% of freed space.',                      true],
          ['Allow deleting hidden',     'Show and allow removal of dot-folders like .Trash, .config.',            false],
        ].map(([n, desc, on], i, all) => (
          <div key={n} style={{ display: 'flex', alignItems: 'flex-start', gap: 14,
            padding: '14px 0', borderBottom: i < all.length - 1 ? '1px solid ' + A.line : 'none' }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 600 }}>{n}</div>
              <div style={{ fontSize: 12, color: A.ink2, marginTop: 2 }}>{desc}</div>
            </div>
            <Toggle on={on} />
          </div>
        ))}

        {/* Protected paths list */}
        <div style={{ marginTop: 22 }}>
          <div style={{ display: 'flex', alignItems: 'center', marginBottom: 10 }}>
            <div style={{ fontSize: 14, fontWeight: 700 }}>Protected paths</div>
            <div style={{ flex: 1 }} />
            <button style={{ background: A.panel, border: '1px solid ' + A.line,
              borderRadius: 8, padding: '6px 11px', fontSize: 12, fontWeight: 600,
              color: A.ink, display: 'flex', alignItems: 'center', gap: 5 }}>
              <Icon name="plus" size={12} stroke={2.5} />Add path
            </button>
          </div>
          <div style={{ background: A.panel, border: '1px solid ' + A.line,
            borderRadius: 12, overflow: 'hidden' }}>
            {[
              { p: '/System',                       sys: true },
              { p: '/Library',                      sys: true },
              { p: '/private',                      sys: true },
              { p: '/usr',                          sys: true },
              { p: '~/Library/Application Support', sys: false },
              { p: '~/Developer/work-critical',     sys: false },
            ].map((r, i, all) => (
              <div key={r.p} style={{ display: 'flex', alignItems: 'center', gap: 10,
                padding: '10px 14px',
                borderBottom: i < all.length - 1 ? '1px solid ' + A.line : 'none' }}>
                <Icon name="shield" size={14} stroke={2}
                  style={{ color: r.sys ? A.red : A.ink2 }} />
                <span style={{ fontFamily: '"Geist Mono", monospace', fontSize: 12 }}>
                  {r.p}
                </span>
                {r.sys && <Pill color={A.red} soft={A.redSoft}>system</Pill>}
                <div style={{ flex: 1 }} />
                {!r.sys && (
                  <button style={{ background: 'transparent', border: 'none',
                    color: A.ink2, padding: 4, cursor: 'pointer' }}>
                    <Icon name="x" size={13} stroke={2} />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Scheduled scans (peek at another section) */}
        <div style={{ marginTop: 22, padding: 14, background: A.honeySoft,
          borderRadius: 12, display: 'flex', alignItems: 'center', gap: 12 }}>
          <Icon name="clock" size={20} stroke={2} style={{ color: A.coral }} />
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 13, fontWeight: 600 }}>
              Scheduled scan: every Sunday, 8:00am
            </div>
            <div style={{ fontSize: 11.5, color: A.ink2, marginTop: 1 }}>
              Next: Sun, May 31 &mdash; only runs when plugged in.
            </div>
          </div>
          <button style={{ background: A.paper, border: '1px solid ' + A.line,
            borderRadius: 8, padding: '7px 12px', fontSize: 12, fontWeight: 600,
            color: A.ink }}>Change</button>
        </div>
      </Card>
    </div>
  </Window>
);

Object.assign(window, {
  A1_Start, A2_Scanning, A3_Dashboard, A4_Drill, A5_Groups, A6_Delete, A7_Settings,
});
