// b-base.jsx — "Bubblegum" direction. Chunky candy aesthetic.
// Space Grotesk throughout; thick 2px ink borders, offset shadows.

const B = {
  bg:        '#F2EEFF',
  paper:     '#FFFFFF',
  panel:     '#EBE4FF',
  ink:       '#0F0A2E',
  ink2:      '#5A547A',
  ink3:      '#9690B5',
  line:      '#0F0A2E',          // chunky ink lines
  line2:     '#D6CFFA',          // soft lavender lines for inner dividers
  // Candy accents
  blue:      '#5840FF',
  blueSoft:  '#E0DAFF',
  pink:      '#FF4D9C',
  pinkSoft:  '#FFD9EA',
  lemon:     '#FFE74C',
  lemonSoft: '#FFF6BD',
  mint:      '#3DDC97',
  mintSoft:  '#CFF3E1',
  peach:     '#FF8A5B',
  peachSoft: '#FFD9C5',
  red:       '#E73C5C',
};

const B_HUES = [B.blue, B.pink, B.mint, B.lemon, B.peach, '#9B6BFF', '#3DAFFF'];

// Chunky shadow used everywhere (offset, hard, no blur)
const chunk = (x = 4, y = 4, c = B.ink) => `${x}px ${y}px 0 ${c}`;

// ── Window chrome (Linux/Win-style + bold borders) ───────────────────────
const BWindow = ({ title, children }) => (
  <div style={{
    width: '100%', height: '100%', background: B.bg, borderRadius: 24,
    overflow: 'hidden', position: 'relative',
    fontFamily: '"Space Grotesk", "Geist", sans-serif', color: B.ink,
    border: '2px solid ' + B.ink, boxShadow: '0 0 0 0',
  }}>
    {/* Title bar */}
    <div style={{
      height: 40, background: B.lemon, borderBottom: '2px solid ' + B.ink,
      display: 'flex', alignItems: 'center', padding: '0 14px', gap: 10,
    }}>
      <div style={{
        width: 18, height: 18, borderRadius: 5, background: B.pink,
        border: '1.5px solid ' + B.ink,
      }} />
      <div style={{ flex: 1, textAlign: 'center', fontSize: 12, color: B.ink,
        fontWeight: 600, letterSpacing: 0.2 }}>{title}</div>
      {/* Window controls */}
      <div style={{ display: 'flex', gap: 6 }}>
        {[null, null, null].map((_, i) => (
          <div key={i} style={{ width: 18, height: 18, borderRadius: 5,
            background: B.paper, border: '1.5px solid ' + B.ink,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 9, fontWeight: 800 }}>
            {i === 0 ? '–' : (i === 1 ? '◻' : '×')}
          </div>
        ))}
      </div>
    </div>
    {children}
  </div>
);

// ── App bar (logo + tabs) ────────────────────────────────────────────────
const BAppBar = ({ active = 'overview', drive = 'Macintosh HD' }) => (
  <div style={{
    display: 'flex', alignItems: 'center', padding: '16px 20px',
    borderBottom: '2px solid ' + B.ink, background: B.paper, gap: 14,
  }}>
    {/* Wordmark */}
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <div style={{
        width: 34, height: 34, borderRadius: 10, background: B.blue,
        border: '2px solid ' + B.ink, boxShadow: chunk(2, 2),
        display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 2, padding: 5,
      }}>
        <div style={{ background: B.pink, borderRadius: 2, border: '1px solid ' + B.ink }} />
        <div style={{ background: B.lemon, borderRadius: 2, border: '1px solid ' + B.ink }} />
        <div style={{ background: B.mint, borderRadius: 2, border: '1px solid ' + B.ink }} />
        <div style={{ background: B.peach, borderRadius: 2, border: '1px solid ' + B.ink }} />
      </div>
      <div style={{ fontWeight: 700, fontSize: 22, letterSpacing: -0.5 }}>Crumb</div>
    </div>
    {/* Tabs */}
    <div style={{ display: 'flex', gap: 6, marginLeft: 8 }}>
      {[
        ['overview', 'Overview'], ['groups', 'Groups'],
        ['types', 'Types'], ['history', 'History'],
      ].map(([id, label]) => (
        <div key={id} style={{
          padding: '7px 14px', borderRadius: 10, fontSize: 13, fontWeight: 600,
          border: '2px solid ' + B.ink,
          color: active === id ? B.paper : B.ink,
          background: active === id ? B.ink : B.paper,
          boxShadow: active === id ? chunk(2, 2, B.pink) : 'none',
        }}>{label}</div>
      ))}
    </div>
    <div style={{ flex: 1 }} />
    {/* Drive picker */}
    <div style={{
      display: 'flex', alignItems: 'center', gap: 8, padding: '7px 12px',
      background: B.lemonSoft, border: '2px solid ' + B.ink, borderRadius: 10,
      fontSize: 13, fontWeight: 600, boxShadow: chunk(2, 2),
    }}>
      <Icon name="drive" size={15} stroke={2} />
      {drive}
      <Icon name="chevdown" size={13} stroke={2.4} />
    </div>
    <button style={{
      width: 40, height: 40, borderRadius: 10, border: '2px solid ' + B.ink,
      background: B.paper, color: B.ink, display: 'flex', alignItems: 'center',
      justifyContent: 'center', cursor: 'pointer', boxShadow: chunk(2, 2),
    }}><Icon name="cog" size={17} stroke={2} /></button>
  </div>
);

// ── Bits ────────────────────────────────────────────────────────────────
const BCard = ({ children, style = {}, pad = 18, color = B.paper, shadow = true }) => (
  <div style={{
    background: color, border: '2px solid ' + B.ink, borderRadius: 18,
    padding: pad, boxShadow: shadow ? chunk(4, 4) : 'none', ...style,
  }}>{children}</div>
);

const BPill = ({ children, color = B.lemon }) => (
  <span style={{
    display: 'inline-flex', alignItems: 'center', gap: 5,
    padding: '3px 10px', borderRadius: 999, fontSize: 11, fontWeight: 700,
    background: color, color: B.ink, border: '1.5px solid ' + B.ink,
    letterSpacing: 0.2,
  }}>{children}</span>
);

const BBar = ({ pct, color = B.blue, height = 10 }) => (
  <div style={{
    background: B.paper, height, borderRadius: height,
    overflow: 'hidden', width: '100%', border: '1.5px solid ' + B.ink,
  }}>
    <div style={{ width: pct + '%', height: '100%', background: color,
      borderRight: pct < 100 ? '1.5px solid ' + B.ink : 'none' }} />
  </div>
);

// Donut with chunky border
const BDonut = ({ pct, size = 120, stroke = 14, color = B.blue, children }) => {
  const r = (size - stroke - 4) / 2;
  const c = 2 * Math.PI * r;
  return (
    <div style={{ position: 'relative', width: size, height: size }}>
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        <circle cx={size / 2} cy={size / 2} r={r + 1} fill="none"
          stroke={B.ink} strokeWidth={stroke + 4} />
        <circle cx={size / 2} cy={size / 2} r={r + 1} fill="none"
          stroke={B.paper} strokeWidth={stroke + 2} />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none"
          stroke={color} strokeWidth={stroke} strokeLinecap="butt"
          strokeDasharray={c} strokeDashoffset={c * (1 - pct / 100)} />
      </svg>
      <div style={{ position: 'absolute', inset: 0, display: 'flex',
        flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
        {children}
      </div>
    </div>
  );
};

const BToggle = ({ on, color = B.mint }) => (
  <div style={{ width: 42, height: 22, borderRadius: 999,
    background: on ? color : B.panel, padding: 1,
    border: '2px solid ' + B.ink }}>
    <div style={{ width: 16, height: 16, borderRadius: '50%', background: B.paper,
      border: '1.5px solid ' + B.ink,
      transform: on ? 'translateX(20px)' : 'translateX(0)',
      transition: 'transform .15s' }} />
  </div>
);

Object.assign(window, { B, B_HUES, BWindow, BAppBar, BCard, BPill, BBar, BDonut, BToggle, chunk });
