// shared.jsx — mock data + format helpers shared by both directions.
// Exposes everything to window at the bottom so direction-a/b can use it.

const fmtBytes = (bytes) => {
  if (bytes >= 1e12) return (bytes / 1e12).toFixed(2) + ' TB';
  if (bytes >= 1e9) return (bytes / 1e9).toFixed(1) + ' GB';
  if (bytes >= 1e6) return (bytes / 1e6).toFixed(0) + ' MB';
  if (bytes >= 1e3) return (bytes / 1e3).toFixed(0) + ' KB';
  return bytes + ' B';
};

const fmtAge = (days) => {
  if (days < 1) return 'today';
  if (days < 7) return days + 'd ago';
  if (days < 60) return Math.round(days / 7) + 'w ago';
  if (days < 365) return Math.round(days / 30) + 'mo ago';
  return (days / 365).toFixed(1) + 'y ago';
};

// Top-level disk summary
const DISK = {
  total: 1000e9,
  used: 612e9,
  free: 388e9,
  name: 'Macintosh HD',
};

// External / multi-disk
const DRIVES = [
  { id: 'mac', name: 'Macintosh HD', kind: 'internal', total: 1000e9, used: 612e9 },
  { id: 'tm',  name: 'Time Machine', kind: 'external', total: 4000e9, used: 2840e9 },
  { id: 'usb', name: 'Sandisk 64GB',  kind: 'usb',      total: 64e9,   used: 58e9 },
];

// Top folders for the dashboard (by size on the user disk).
const TOP_FOLDERS = [
  { name: 'Users/lina',          size: 412e9, items: 1240321, mod: 2,   color: 0 },
  { name: 'Applications',        size: 78e9,  items: 8230,    mod: 12,  color: 1 },
  { name: 'System',              size: 42e9,  items: 92410,   mod: 28,  color: 2, protected: true },
  { name: 'Library',             size: 36e9,  items: 220411,  mod: 4,   color: 3, protected: true },
  { name: 'opt',                 size: 24e9,  items: 18230,   mod: 18,  color: 4 },
  { name: 'private',             size: 12e9,  items: 6320,    mod: 30,  color: 5, protected: true },
  { name: 'Volumes',             size: 8e9,   items: 320,     mod: 1,   color: 6 },
];

// Drill-down: Users/lina contents
const HOME_FOLDERS = [
  { name: 'Movies',           size: 142e9, items: 312,   mod: 4 },
  { name: 'Photos Library',   size: 96e9,  items: 28410, mod: 1 },
  { name: 'Developer',        size: 84e9,  items: 920411,mod: 0 },
  { name: 'Downloads',        size: 38e9,  items: 4231,  mod: 2 },
  { name: 'Documents',        size: 22e9,  items: 18230, mod: 14 },
  { name: 'Music',            size: 18e9,  items: 8210,  mod: 89 },
  { name: '.Trash',           size: 6e9,   items: 412,   mod: 9, hidden: true },
  { name: '.config',          size: 1.2e9, items: 920,   mod: 6, hidden: true },
  { name: 'Desktop',          size: 3.4e9, items: 220,   mod: 0 },
];

// Group-by-name aggregations across the filesystem.
const GROUPS = [
  {
    name: 'node_modules', tagline: 'JavaScript dependencies',
    total: 41.2e9, count: 18, avgAge: 240, devOnly: true,
    instances: [
      { path: '~/Developer/dashboard-v2/node_modules',    size: 8.4e9,  mod: 412 },
      { path: '~/Developer/marketing-site/node_modules',   size: 6.1e9,  mod: 320 },
      { path: '~/Developer/old-prototype/node_modules',    size: 4.2e9,  mod: 620 },
      { path: '~/Developer/api-server/node_modules',       size: 3.8e9,  mod: 14 },
      { path: '~/Developer/sandbox/node_modules',          size: 3.4e9,  mod: 88 },
      { path: '~/Developer/portfolio/node_modules',        size: 2.9e9,  mod: 540 },
      { path: '~/Developer/internal-tools/node_modules',   size: 2.6e9,  mod: 210 },
      { path: '~/Developer/blog/node_modules',             size: 2.2e9,  mod: 720 },
    ],
  },
  {
    name: '.venv', tagline: 'Python virtual environments',
    total: 8.6e9, count: 12, avgAge: 180, devOnly: true,
  },
  {
    name: 'DerivedData', tagline: 'Xcode build cache',
    total: 14.8e9, count: 6, avgAge: 22, devOnly: true,
  },
  {
    name: '__pycache__', tagline: 'Python compiled cache',
    total: 1.4e9, count: 220, avgAge: 90, devOnly: true,
  },
  {
    name: 'Caches', tagline: 'App caches (Safari, Slack, …)',
    total: 12.1e9, count: 34, avgAge: 3, devOnly: false,
  },
  {
    name: 'Photos Library duplicates', tagline: 'Near-identical photos',
    total: 7.2e9, count: 412, avgAge: 220, devOnly: false,
  },
  {
    name: 'Old Downloads', tagline: 'Untouched > 6 months',
    total: 4.8e9, count: 88, avgAge: 280, devOnly: false,
  },
];

// File-type breakdown.
const FILE_TYPES = [
  { name: 'Video',     size: 168e9, count: 1320,    icon: 'video' },
  { name: 'Photos',    size: 112e9, count: 28410,   icon: 'photo' },
  { name: 'Code',      size: 96e9,  count: 920411,  icon: 'code' },
  { name: 'Apps',      size: 78e9,  count: 412,     icon: 'app' },
  { name: 'Documents', size: 28e9,  count: 8210,    icon: 'doc' },
  { name: 'Music',     size: 22e9,  count: 4120,    icon: 'music' },
  { name: 'Archives',  size: 18e9,  count: 220,     icon: 'archive' },
  { name: 'Other',     size: 90e9,  count: 84210,   icon: 'other' },
];

// Smart suggestions (cleanup tips).
const SUGGESTIONS = [
  { title: 'Empty Trash', detail: '412 items · last emptied 9 days ago', save: 6e9, kind: 'safe' },
  { title: 'Clear 14 stale node_modules', detail: 'Projects not touched in 6+ months', save: 24e9, kind: 'safe' },
  { title: 'Old downloads (88 files)', detail: 'Installer .dmg, .zip > 6mo old', save: 4.8e9, kind: 'safe' },
  { title: 'Duplicate photos', detail: '412 near-identical shots', save: 7.2e9, kind: 'review' },
  { title: 'Xcode DerivedData', detail: 'Safe to delete — Xcode rebuilds on demand', save: 14.8e9, kind: 'safe' },
];

// Recent snapshots (history).
const SNAPSHOTS = [
  { when: 'Today',         used: 612e9, delta: +4.2e9 },
  { when: 'Yesterday',     used: 608e9, delta: +1.1e9 },
  { when: 'Mon, May 19',   used: 607e9, delta: +12e9 },
  { when: 'Mon, May 12',   used: 595e9, delta: -3e9 },
  { when: 'Mon, May 5',    used: 598e9, delta: +8e9 },
  { when: 'Mon, Apr 28',   used: 590e9, delta: +6e9 },
];

// Live-scanning preview path samples.
const SCAN_PATHS = [
  '~/Library/Application Support/Slack/Cache',
  '~/Developer/dashboard-v2/node_modules/@types',
  '~/Library/Caches/com.apple.Safari',
  '~/Movies/family-2023.mov',
  '~/Photos Library.photoslibrary/originals',
  '~/Developer/api-server/.git/objects',
  '~/Downloads/Xcode_15.2.xip',
];

// Items targeted by the delete-confirm sheet (sample group cleanup).
const DELETE_TARGETS = [
  { path: '~/Developer/old-prototype/node_modules',    size: 4.2e9,  mod: 620, protected: false },
  { path: '~/Developer/sandbox/node_modules',          size: 3.4e9,  mod: 88,  protected: false },
  { path: '~/Developer/blog/node_modules',             size: 2.2e9,  mod: 720, protected: false },
  { path: '/System/Library/Caches',                    size: 2.1e9,  mod: 4,   protected: true },
  { path: '~/Developer/portfolio/node_modules',        size: 2.9e9,  mod: 540, protected: false },
];

// Simple SVG icon helper — pass name, returns a React element.
// All icons are 1.5px stroke, currentColor.
const ICONS = {
  folder: 'M3 6.5a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-11z',
  drive:  'M3 7h18v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7zM3 7l2-3h14l2 3M7 11.5h.01M11 11.5h6',
  search: 'M11 4a7 7 0 1 1 0 14 7 7 0 0 1 0-14zM21 21l-4.5-4.5',
  trash:  'M4 7h16M9 7V4h6v3M6 7l1 13a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-13M10 11v7M14 11v7',
  shield: 'M12 3l8 3v6c0 4.5-3.5 8.5-8 9-4.5-.5-8-4.5-8-9V6l8-3z',
  clock:  'M12 3a9 9 0 1 0 9 9M12 7v5l3 2',
  sparkle:'M12 3l1.7 4.6L18 9l-4.3 1.4L12 15l-1.7-4.6L6 9l4.3-1.4z M19 14l.7 1.8L21 17l-1.3.5L19 19l-.7-1.5L17 17l1.3-.5z',
  cog:    'M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6zM19 12a7 7 0 0 0-.1-1.2l2-1.5-2-3.4-2.3.9a7 7 0 0 0-2-1.2L14 3h-4l-.5 2.6a7 7 0 0 0-2.1 1.2L5 6l-2 3.4 2 1.5a7 7 0 0 0 0 2.4l-2 1.5 2 3.4 2.3-.9a7 7 0 0 0 2.1 1.2L10 21h4l.5-2.6a7 7 0 0 0 2-1.2l2.4.9 2-3.4-2-1.5c.1-.4.1-.8.1-1.2z',
  chevron:'M9 6l6 6-6 6',
  chevdown:'M6 9l6 6 6-6',
  chart:  'M3 20h18M6 20V10M11 20V4M16 20v-7M21 20v-3',
  arrowup:'M12 19V5M5 12l7-7 7 7',
  arrowdn:'M12 5v14M19 12l-7 7-7-7',
  plus:   'M12 5v14M5 12h14',
  x:      'M6 6l12 12M18 6L6 18',
  video:  'M3 6.5a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-9zM16 9.5l5-3v9l-5-3z',
  photo:  'M3 5.5h18v13H3zM3 14.5l5-5 5 5 3-3 5 5M17 9a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3z',
  code:   'M9 7l-5 5 5 5M15 7l5 5-5 5M14 5l-4 14',
  music:  'M9 18a2 2 0 1 1 0-4 2 2 0 0 1 0 4zM19 16a2 2 0 1 1 0-4 2 2 0 0 1 0 4zM9 14V4l10-2v12',
  doc:    'M6 3h8l5 5v12a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1zM14 3v5h5',
  archive:'M3 5.5h18v3H3zM5 8.5v11h14v-11M10 12h4',
  app:    'M4 5.5h6v6H4zM14 5.5h6v6h-6zM4 13.5h6v6H4zM14 13.5h6v6h-6z',
  other:  'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM12 8v4M12 16h.01',
  hidden: 'M3 12c2-4 5-6 9-6s7 2 9 6c-2 4-5 6-9 6s-7-2-9-6zM12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z',
  refresh:'M21 12a9 9 0 1 1-3-6.7M21 4v5h-5',
  download:'M12 3v12M5 11l7 7 7-7M4 21h16',
  play:   'M7 4l13 8-13 8z',
  pause:  'M6 4h4v16H6zM14 4h4v16h-4z',
  check:  'M5 12l5 5 9-12',
  warn:   'M12 3l10 18H2L12 3zM12 10v4M12 18h.01',
  filter: 'M3 5h18l-7 9v6l-4-2v-4z',
  grid:   'M4 5h7v7H4zM13 5h7v7h-7zM4 14h7v7H4zM13 14h7v7h-7z',
  list:   'M8 6h13M8 12h13M8 18h13M4 6h.01M4 12h.01M4 18h.01',
};

const Icon = ({ name, size = 18, stroke = 1.6, fill = 'none', className = '', style = {} }) => {
  const d = ICONS[name] || ICONS.other;
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke="currentColor"
      strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round"
      className={className} style={style}>
      <path d={d} />
    </svg>
  );
};

Object.assign(window, {
  fmtBytes, fmtAge,
  DISK, DRIVES, TOP_FOLDERS, HOME_FOLDERS, GROUPS, FILE_TYPES,
  SUGGESTIONS, SNAPSHOTS, SCAN_PATHS, DELETE_TARGETS,
  Icon, ICONS,
});
