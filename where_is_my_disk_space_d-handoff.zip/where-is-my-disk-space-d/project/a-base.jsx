// direction-a.jsx — "Honey" direction. Warm cream + walnut, scrapbook-y,
// playful but precise. Bricolage Grotesque display + Geist body.

const A = {
  bg:        '#FBF6EC',   // page bg
  paper:     '#FFFFFF',   // surface
  panel:     '#F4ECDA',   // muted surface
  ink:       '#2A2118',   // text
  ink2:      '#7C6F5F',   // muted text
  ink3:      '#B5A48E',   // tertiary text
  line:      '#E8DFCC',
  line2:     '#D7C9AA',
  // Accents — keep to a tight family
  coral:     '#E55934',
  coralSoft: '#FDE3DA',
  honey:     '#F3B95F',
  honeySoft: '#FBE9C6',
  sage:      '#5FA37C',
  sageSoft:  '#D8ECDD',
  lilac:     '#9E8FCF',
  lilacSoft: '#E8E2F5',
  navy:      '#2C3E66',
  navySoft:  '#D9DFEB',
  red:       '#C9412A',
  redSoft:   '#F6D9D2',
};

// Palette ring used in viz — saturated friendly hues.
const A_HUES = [A.coral, A.honey, A.sage, A.lilac, A.navy, '#D86A8A', '#7BAFD4'];

// ── Desktop window chrome ────────────────────────────────────────────────
const Window = ({ title, children, accent = A.coral }) => (
  <div style={{
    width: '100%', height: '100%', background: A.bg, borderRadius: 18, overflow: 'hidden',
    fontFamily: '"Geist", "Inter", ui-sans-serif, sans-serif',
    color: A.ink, position: 'relative', boxShadow: 'inset 0 0 0 1px ' + A.line,
  }}>
    {/* Title bar */}
    <div style={{
      height: 38, background: '#F0E7D2', borderBottom: '1px solid ' + A.line,
      display: 'flex', alignItems: 'center', padding: '0 14px', gap: 10,
    }}>
      <div style={{ display: 'flex', gap: 6 }}>
        {['#E55934', '#F3B95F', '#5FA37C'].map((c) => (
          <div key={c} style={{ width: 11, height: 11, borderRadius: '50%', background: c,
            boxShadow: 'inset 0 0 0 0.5px rgba(0,0,0,.12)' }} />
        ))}
      </div>
      <div style={{
        flex: 1, textAlign: 'center', fontSize: 12, color: A.ink2, fontWeight: 500,
        letterSpacing: 0.1,
      }}>{title}</div>
      <div style={{ width: 36 }} />
    </div>
    {children}
  </div>
);

// ── App chrome: brand row + tabs ─────────────────────────────────────────
const AppBar = ({ active = 'overview', drive = 'Macintosh HD' }) => (
  <div style={{
    display: 'flex', alignItems: 'center', padding: '14px 20px 0', gap: 18,
  }}>
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      {/* Mark: crumb dot trio */}
      <div style={{
        width: 32, height: 32, borderRadius: 10, background: A.coral,
        display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative',
      }}>
        <div style={{ position: 'absolute', width: 8, height: 8, borderRadius: '50%',
          background: A.honey, top: 6, left: 6 }} />
        <div style={{ position: 'absolute', width: 6, height: 6, borderRadius: '50%',
          background: A.paper, bottom: 7, right: 8 }} />
        <div style={{ position: 'absolute', width: 4, height: 4, borderRadius: '50%',
          background: A.honeySoft, top: 12, right: 6 }} />
      </div>
      <div style={{ fontFamily: '"Bricolage Grotesque", "Geist", sans-serif',
        fontWeight: 800, fontSize: 22, letterSpacing: -0.4 }}>Crumb</div>
    </div>
    <div style={{
      display: 'flex', gap: 4, background: A.paper, padding: 4, borderRadius: 12,
      border: '1px solid ' + A.line, marginLeft: 6,
    }}>
      {[
        ['overview', 'Overview'], ['groups', 'Groups'],
        ['types', 'File types'], ['history', 'History'],
      ].map(([id, label]) => (
        <div key={id} style={{
          padding: '7px 14px', borderRadius: 8, fontSize: 13, fontWeight: 600,
          color: active === id ? A.paper : A.ink2,
          background: active === id ? A.ink : 'transparent',
        }}>{label}</div>
      ))}
    </div>
    <div style={{ flex: 1 }} />
    <div style={{
      display: 'flex', alignItems: 'center', gap: 8, padding: '7px 12px',
      background: A.paper, border: '1px solid ' + A.line, borderRadius: 10,
      fontSize: 13, fontWeight: 500, color: A.ink,
    }}>
      <Icon name="drive" size={15} stroke={1.8} />
      {drive}
      <Icon name="chevdown" size={13} stroke={2} />
    </div>
    <button style={{
      width: 38, height: 38, borderRadius: 10, border: '1px solid ' + A.line,
      background: A.paper, color: A.ink2, display: 'flex', alignItems: 'center',
      justifyContent: 'center', cursor: 'pointer',
    }}><Icon name="cog" size={17} /></button>
  </div>
);

// ── Tiny reusable bits ───────────────────────────────────────────────────
const Card = ({ children, style = {}, pad = 18 }) => (
  <div style={{
    background: A.paper, border: '1px solid ' + A.line, borderRadius: 16,
    padding: pad, boxShadow: '0 1px 0 ' + A.line, ...style,
  }}>{children}</div>
);

const Pill = ({ children, color = A.honey, soft = A.honeySoft, dark }) => (
  <span style={{
    display: 'inline-flex', alignItems: 'center', gap: 5,
    padding: '3px 9px', borderRadius: 999, fontSize: 11, fontWeight: 600,
    background: dark ? color : soft, color: dark ? A.paper : color,
    letterSpacing: 0.2,
  }}>{children}</span>
);

const Bar = ({ pct, color = A.coral, height = 6 }) => (
  <div style={{ background: A.line, height, borderRadius: height,
    overflow: 'hidden', width: '100%' }}>
    <div style={{ width: pct + '%', height: '100%', background: color,
      borderRadius: height }} />
  </div>
);

// Donut ring (for total used). Renders an SVG ring with a gap.
const Donut = ({ pct, size = 120, stroke = 14, color = A.coral, track = A.line, children }) => {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  return (
    <div style={{ position: 'relative', width: size, height: size }}>
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={track} strokeWidth={stroke} />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color}
          strokeWidth={stroke} strokeLinecap="round" strokeDasharray={c}
          strokeDashoffset={c * (1 - pct / 100)} />
      </svg>
      <div style={{ position: 'absolute', inset: 0, display: 'flex',
        flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
        {children}
      </div>
    </div>
  );
};

Object.assign(window, { A, A_HUES, Window, AppBar, Card, Pill, Bar, Donut });
