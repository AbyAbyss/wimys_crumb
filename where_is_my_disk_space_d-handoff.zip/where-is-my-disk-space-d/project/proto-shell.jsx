// proto-shell.jsx — Interactive prototype shell.
// Holds global state, screen routing, scale-to-fit, top app bar, and a toast.
//
// We use React.useX directly throughout the prototype files to avoid
// const-redeclaration clashes across <script type="text/babel"> blocks.

// ── Scale-to-fit hook ─────────────────────────────────────────────────────
const useFitScale = (w, h, padding = 24) => {
  const [scale, setScale] = React.useState(1);
  React.useEffect(() => {
    const fit = () => {
      const sx = (window.innerWidth - padding * 2) / w;
      const sy = (window.innerHeight - padding * 2) / h;
      setScale(Math.min(1, Math.min(sx, sy)));
    };
    fit();
    window.addEventListener('resize', fit);
    return () => window.removeEventListener('resize', fit);
  }, [w, h, padding]);
  return scale;
};

// ── Default initial state ────────────────────────────────────────────────
const makeInitState = () => ({
  screen: 'start',       // 'start' | 'scanning' | 'overview' | 'drill' | 'groups' | 'settings'
  tab: 'overview',
  // scanning
  scanProgress: 0,
  scanning: false,
  scanPaused: false,
  scanDriveId: 'mac',
  scanCurrent: SCAN_PATHS[0],
  // drill
  drillCrumb: ['Macintosh HD', 'Users', 'lina'],
  drillItems: HOME_FOLDERS.slice(),
  drillSelected: {},
  // groups
  groupsData: GROUPS.map((g) => ({ ...g })),
  expandedGroup: 'node_modules',
  groupsSelected: {},      // path -> bool, for instances
  groupsFilter: 'all',     // 'all' | 'stale'
  // delete
  deleteOpen: false,
  deleteTargets: [],
  deleteKind: 'trash',
  deleteSnapshot: true,
  // toast
  toast: null,
  // running totals
  freedBytes: 0,
  // settings
  settingsActive: 'safety',
  toggles: {
    protectSystem: true,
    protectActive: true,
    confirmLarge: true,
    snapshots: true,
    allowHidden: false,
  },
  protectedPaths: [
    { p: '/System',                        sys: true },
    { p: '/Library',                       sys: true },
    { p: '/private',                       sys: true },
    { p: '/usr',                           sys: true },
    { p: '~/Library/Application Support',  sys: false },
    { p: '~/Developer/work-critical',      sys: false },
  ],
});

// ── App-level context ────────────────────────────────────────────────────
const AppCtx = React.createContext(null);
const useApp = () => React.useContext(AppCtx);

// ── Top app bar (interactive) ────────────────────────────────────────────
const IAppBar = () => {
  const { state, nav } = useApp();
  const drive = DRIVES.find((d) => d.id === state.scanDriveId) || DRIVES[0];
  return (
    <div style={{
      display: 'flex', alignItems: 'center', padding: '14px 20px 14px', gap: 18,
    }}>
      <button onClick={() => nav.goto('start')}
        style={{ display: 'flex', alignItems: 'center', gap: 10,
          background: 'transparent', border: 'none', cursor: 'pointer', padding: 0 }}>
        <div style={{
          width: 32, height: 32, borderRadius: 10, background: A.coral,
          display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative',
        }}>
          <div style={{ position: 'absolute', width: 8, height: 8, borderRadius: '50%',
            background: A.honey, top: 6, left: 6 }} />
          <div style={{ position: 'absolute', width: 6, height: 6, borderRadius: '50%',
            background: A.paper, bottom: 7, right: 8 }} />
          <div style={{ position: 'absolute', width: 4, height: 4, borderRadius: '50%',
            background: A.honeySoft, top: 12, right: 6 }} />
        </div>
        <div style={{ fontFamily: '"Bricolage Grotesque", sans-serif',
          fontWeight: 800, fontSize: 22, letterSpacing: -0.4, color: A.ink }}>Crumb</div>
      </button>

      {state.screen !== 'start' && state.screen !== 'scanning' && (
        <div style={{
          display: 'flex', gap: 4, background: A.paper, padding: 4, borderRadius: 12,
          border: '1px solid ' + A.line, marginLeft: 6,
        }}>
          {[
            ['overview', 'Overview'],
            ['groups',   'Groups'  ],
            ['types',    'File types'],
            ['history',  'History' ],
          ].map(([id, label]) => {
            const active =
              (id === 'overview' && (state.screen === 'overview' || state.screen === 'drill')) ||
              (id === 'groups'   && state.screen === 'groups')   ||
              (id === 'types'    && state.screen === 'types')    ||
              (id === 'history'  && state.screen === 'history');
            return (
              <button key={id} onClick={() => nav.gotoTab(id)}
                style={{
                  padding: '7px 14px', borderRadius: 8, fontSize: 13, fontWeight: 600,
                  border: 'none', cursor: 'pointer',
                  color: active ? A.paper : A.ink2,
                  background: active ? A.ink : 'transparent',
                }}>{label}</button>
            );
          })}
        </div>
      )}

      <div style={{ flex: 1 }} />

      {state.screen !== 'start' && state.screen !== 'scanning' && (
        <button onClick={() => nav.goto('scanning', { driveId: state.scanDriveId })}
          style={{
            display: 'flex', alignItems: 'center', gap: 7,
            background: A.paper, border: '1px solid ' + A.line, borderRadius: 10,
            padding: '7px 11px', fontSize: 12, fontWeight: 600, color: A.ink2,
            cursor: 'pointer',
          }}>
          <Icon name="refresh" size={13} stroke={2} />
          Rescan
        </button>
      )}

      <div style={{
        display: 'flex', alignItems: 'center', gap: 8, padding: '7px 12px',
        background: A.paper, border: '1px solid ' + A.line, borderRadius: 10,
        fontSize: 13, fontWeight: 500, color: A.ink, cursor: 'pointer',
      }}>
        <Icon name="drive" size={15} stroke={1.8} />
        {drive.name}
        <Icon name="chevdown" size={13} stroke={2} />
      </div>
      <button onClick={() => nav.goto('settings')}
        style={{
          width: 38, height: 38, borderRadius: 10, border: '1px solid ' + A.line,
          background: state.screen === 'settings' ? A.coralSoft : A.paper,
          color: state.screen === 'settings' ? A.coral : A.ink2,
          display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
        }}><Icon name="cog" size={17} /></button>
    </div>
  );
};

// ── Toast ────────────────────────────────────────────────────────────────
const Toast = () => {
  const { state, set } = useApp();
  const t = state.toast;
  React.useEffect(() => {
    if (!t) return;
    const id = setTimeout(() => set({ toast: null }), t.duration || 6000);
    return () => clearTimeout(id);
  }, [t]);
  if (!t) return null;
  return (
    <div style={{
      position: 'absolute', bottom: 22, left: '50%', transform: 'translateX(-50%)',
      background: A.ink, color: A.paper, borderRadius: 12, padding: '12px 16px',
      display: 'flex', alignItems: 'center', gap: 14, fontSize: 13,
      boxShadow: '0 10px 30px rgba(42,33,24,.35)',
      animation: 'aToastIn .3s cubic-bezier(.2,.7,.3,1.2)',
      zIndex: 50, fontFamily: '"Geist", sans-serif',
    }}>
      <style>{`
        @keyframes aToastIn {
          from { transform: translate(-50%, 20px); opacity: 0; }
          to { transform: translate(-50%, 0); opacity: 1; }
        }
      `}</style>
      <div style={{ width: 24, height: 24, borderRadius: '50%', background: A.sage,
        color: A.paper, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <Icon name="check" size={14} stroke={3} />
      </div>
      <div style={{ fontWeight: 500 }}>{t.message}</div>
      {t.action && (
        <button onClick={() => { t.action.run(); set({ toast: null }); }}
          style={{ background: 'transparent', border: 'none', color: A.honey,
            fontWeight: 700, cursor: 'pointer', padding: '4px 0', fontSize: 13 }}>
          {t.action.label}
        </button>
      )}
    </div>
  );
};

Object.assign(window, { useFitScale, makeInitState, AppCtx, useApp, IAppBar, Toast });
