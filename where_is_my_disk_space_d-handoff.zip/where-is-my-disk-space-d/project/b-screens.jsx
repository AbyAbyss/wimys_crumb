// b-screens.jsx — Direction B (Bubblegum) screens.

const B_VIZ_TABS = [
  { id: 'tree',    label: 'Treemap'  },
  { id: 'sun',     label: 'Sunburst' },
  { id: 'list',    label: 'File tree'},
  { id: 'bars',    label: 'Bar list' },
  { id: 'bubble',  label: 'Bubbles'  },
];

const BVizSwitcher = ({ active = 'sun' }) => (
  <div style={{ display: 'inline-flex', gap: 4, padding: 4,
    background: B.paper, borderRadius: 12, border: '2px solid ' + B.ink }}>
    {B_VIZ_TABS.map((t) => (
      <div key={t.id} style={{
        padding: '6px 11px', fontSize: 12, fontWeight: 700,
        color: active === t.id ? B.paper : B.ink,
        background: active === t.id ? B.ink : 'transparent',
        borderRadius: 7,
      }}>{t.label}</div>
    ))}
  </div>
);

// Sunburst — two-ring nested arcs.
const Sunburst = ({ items, size = 280, hues = B_HUES }) => {
  const total = items.reduce((s, it) => s + it.size, 0);
  let a0 = -Math.PI / 2;
  const cx = size / 2, cy = size / 2;
  const r1 = size / 2 - 6, r0 = size / 5;

  const arc = (cx, cy, r, a0, a1) => {
    const x0 = cx + r * Math.cos(a0), y0 = cy + r * Math.sin(a0);
    const x1 = cx + r * Math.cos(a1), y1 = cy + r * Math.sin(a1);
    const large = a1 - a0 > Math.PI ? 1 : 0;
    return `M${x0} ${y0} A${r} ${r} 0 ${large} 1 ${x1} ${y1}`;
  };
  const wedge = (cx, cy, r0, r1, a0, a1) => {
    const p0 = [cx + r0 * Math.cos(a0), cy + r0 * Math.sin(a0)];
    const p1 = [cx + r1 * Math.cos(a0), cy + r1 * Math.sin(a0)];
    const p2 = [cx + r1 * Math.cos(a1), cy + r1 * Math.sin(a1)];
    const p3 = [cx + r0 * Math.cos(a1), cy + r0 * Math.sin(a1)];
    const large = a1 - a0 > Math.PI ? 1 : 0;
    return `M${p0[0]} ${p0[1]} L${p1[0]} ${p1[1]} A${r1} ${r1} 0 ${large} 1 ${p2[0]} ${p2[1]} L${p3[0]} ${p3[1]} A${r0} ${r0} 0 ${large} 0 ${p0[0]} ${p0[1]} Z`;
  };

  return (
    <svg width={size} height={size}>
      {items.map((it, i) => {
        const a1 = a0 + (it.size / total) * Math.PI * 2;
        const mid = (a0 + a1) / 2;
        const labelR = (r0 + r1) / 2;
        const path = wedge(cx, cy, r0, r1, a0, a1);
        const fill = hues[i % hues.length];
        const lx = cx + labelR * Math.cos(mid);
        const ly = cy + labelR * Math.sin(mid);
        const showLabel = (a1 - a0) > 0.3;
        const out = (
          <g key={it.name}>
            <path d={path} fill={fill} stroke={B.ink} strokeWidth="2" />
            {showLabel && (
              <>
                <text x={lx} y={ly - 4} textAnchor="middle" fill="#fff"
                  fontFamily="Space Grotesk" fontWeight="700" fontSize="13">
                  {it.name}
                </text>
                <text x={lx} y={ly + 12} textAnchor="middle" fill="#fff"
                  fontFamily="Space Grotesk" fontWeight="700" fontSize="13">
                  {fmtBytes(it.size)}
                </text>
              </>
            )}
          </g>
        );
        a0 = a1;
        return out;
      })}
      <circle cx={cx} cy={cy} r={r0} fill={B.paper} stroke={B.ink} strokeWidth="2" />
      <text x={cx} y={cy - 4} textAnchor="middle"
        fontFamily="Space Grotesk" fontWeight="700" fontSize="14" fill={B.ink}>
        used
      </text>
      <text x={cx} y={cy + 14} textAnchor="middle"
        fontFamily="Space Grotesk" fontWeight="700" fontSize="16" fill={B.ink}>
        612 GB
      </text>
    </svg>
  );
};

// Chunky treemap with ink borders.
const BTreemap = ({ items, width, height, hues = B_HUES }) => {
  const total = items.reduce((s, it) => s + it.size, 0);
  const top = items.slice(0, 3);
  const bot = items.slice(3);
  const topSum = top.reduce((s, it) => s + it.size, 0);
  const botSum = bot.reduce((s, it) => s + it.size, 0);
  const topH = Math.round(height * (topSum / total));
  const botH = height - topH;
  return (
    <div style={{ width, height, display: 'flex', flexDirection: 'column',
      borderRadius: 14, overflow: 'hidden', gap: 0,
      border: '2px solid ' + B.ink, background: B.ink }}>
      <div style={{ height: topH, display: 'flex', borderBottom: '2px solid ' + B.ink }}>
        {top.map((it, i) => (
          <div key={it.name} style={{
            flex: it.size, height: '100%',
            background: hues[(it.color ?? i) % hues.length],
            borderRight: i < top.length - 1 ? '2px solid ' + B.ink : 'none',
            padding: 14, color: B.ink,
            display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13,
              fontWeight: 700 }}>
              {it.protected && <Icon name="shield" size={14} stroke={2.2} />}
              {it.name}
            </div>
            <div style={{ fontWeight: 700, fontSize: 28, letterSpacing: -0.6 }}>
              {fmtBytes(it.size)}
            </div>
          </div>
        ))}
      </div>
      <div style={{ height: botH, display: 'flex' }}>
        {bot.map((it, i) => (
          <div key={it.name} style={{
            flex: it.size, height: '100%',
            background: hues[(it.color ?? i + 3) % hues.length],
            borderRight: i < bot.length - 1 ? '2px solid ' + B.ink : 'none',
            padding: 10, color: B.ink,
            display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
            fontWeight: 700,
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 12 }}>
              {it.protected && <Icon name="shield" size={12} stroke={2.2} />}
              {it.name}
            </div>
            <div style={{ fontWeight: 700, fontSize: 16 }}>{fmtBytes(it.size)}</div>
          </div>
        ))}
      </div>
    </div>
  );
};

// ───────────────────────────────────────────────────────────────────────
// B1 — Start
// ───────────────────────────────────────────────────────────────────────
const B1_Start = () => (
  <BWindow title="Crumb">
    <BAppBar />
    <div style={{ padding: 22, display: 'grid', gridTemplateColumns: '1.5fr 1fr',
      gap: 18, height: 'calc(100% - 116px)' }}>
      {/* Hero */}
      <BCard color={B.lemon} pad={32} style={{ position: 'relative', overflow: 'hidden',
        display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
        {/* Sticker confetti */}
        <div style={{ position: 'absolute', top: 24, right: 28,
          width: 60, height: 60, borderRadius: '50%', background: B.pink,
          border: '2px solid ' + B.ink, boxShadow: chunk(3, 3),
          transform: 'rotate(-12deg)', display: 'flex', alignItems: 'center',
          justifyContent: 'center', fontWeight: 800, fontSize: 14, color: B.paper }}>
          612GB
        </div>
        <div style={{ position: 'absolute', top: 110, right: 110,
          width: 36, height: 36, borderRadius: 8, background: B.mint,
          border: '2px solid ' + B.ink, boxShadow: chunk(2, 2),
          transform: 'rotate(18deg)' }} />
        <div style={{ position: 'absolute', bottom: 36, right: 60,
          width: 26, height: 26, borderRadius: '50%', background: B.blue,
          border: '2px solid ' + B.ink, boxShadow: chunk(2, 2) }} />

        <BPill color={B.paper}>● Ready to scan</BPill>
        <div style={{ position: 'relative', marginTop: 26 }}>
          <h1 style={{
            fontFamily: '"Space Grotesk", sans-serif', fontWeight: 700,
            fontSize: 64, lineHeight: 0.95, letterSpacing: -2.5, margin: 0,
            color: B.ink, maxWidth: 440,
          }}>
            Find the<br />stuff eating<br />
            <span style={{
              background: B.pink, padding: '0 12px', borderRadius: 14,
              border: '2px solid ' + B.ink, display: 'inline-block',
              transform: 'rotate(-2deg)', boxShadow: chunk(3, 3),
              color: B.paper, marginTop: 6,
            }}>your disk.</span>
          </h1>
          <p style={{ fontSize: 15, color: B.ink, margin: '20px 0 0',
            maxWidth: 420, lineHeight: 1.5, fontWeight: 500 }}>
            Crumb groups what&rsquo;s similar across your whole drive &mdash;
            even dev junk you forgot about &mdash; and tells you what&rsquo;s safe to delete.
          </p>
        </div>
        <div style={{ display: 'flex', gap: 12, alignItems: 'center', marginTop: 26,
          position: 'relative' }}>
          <button style={{
            background: B.mint, color: B.ink, border: '2px solid ' + B.ink,
            borderRadius: 12, padding: '14px 22px', fontSize: 16, fontWeight: 700,
            cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 10,
            boxShadow: chunk(4, 4),
          }}>
            <Icon name="search" size={18} stroke={2.4} />
            Start scan
          </button>
          <button style={{
            background: B.paper, color: B.ink, border: '2px solid ' + B.ink,
            borderRadius: 12, padding: '14px 18px', fontSize: 14, fontWeight: 600,
            cursor: 'pointer', boxShadow: chunk(4, 4),
          }}>
            Pick a folder…
          </button>
        </div>
      </BCard>

      {/* Drives */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        <BCard pad={18} color={B.paper}>
          <div style={{ display: 'flex', alignItems: 'center',
            justifyContent: 'space-between', marginBottom: 14 }}>
            <div style={{ fontWeight: 700, fontSize: 14, letterSpacing: 0.3,
              textTransform: 'uppercase' }}>Your drives</div>
            <div style={{ width: 26, height: 26, borderRadius: 6,
              border: '1.5px solid ' + B.ink, background: B.lemon,
              display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Icon name="refresh" size={13} stroke={2.4} />
            </div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {DRIVES.map((d, i) => {
              const pct = Math.round((d.used / d.total) * 100);
              const colors = [B.blue, B.pink, B.peach];
              const isFull = pct > 85;
              return (
                <div key={d.id} style={{
                  display: 'flex', alignItems: 'center', gap: 12,
                  padding: 10, borderRadius: 12,
                  border: '2px solid ' + B.ink,
                  background: isFull ? B.pinkSoft : (i === 1 ? B.blueSoft : B.lemonSoft),
                }}>
                  <BDonut pct={pct} size={48} stroke={6} color={isFull ? B.pink : colors[i]}>
                    <div style={{ fontSize: 10, fontWeight: 800 }}>{pct}%</div>
                  </BDonut>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      <div style={{ fontWeight: 700, fontSize: 13 }}>{d.name}</div>
                      {isFull && <BPill color={B.pink}>full</BPill>}
                    </div>
                    <div style={{ fontSize: 11, color: B.ink2, marginTop: 2,
                      fontWeight: 500 }}>
                      {fmtBytes(d.used)} / {fmtBytes(d.total)}
                    </div>
                  </div>
                  <button style={{
                    background: B.paper, border: '1.5px solid ' + B.ink,
                    borderRadius: 7, padding: '5px 10px', fontSize: 12,
                    fontWeight: 700, color: B.ink,
                    boxShadow: chunk(2, 2),
                  }}>Scan</button>
                </div>
              );
            })}
          </div>
        </BCard>

        <BCard pad={16} color={B.mintSoft}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <Icon name="clock" size={18} stroke={2.2} />
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 700, fontSize: 13 }}>
                Auto-scan every Sunday
              </div>
              <div style={{ fontSize: 11, color: B.ink2, marginTop: 1, fontWeight: 500 }}>
                Last: Sun, May 24 · 612 GB used
              </div>
            </div>
            <BToggle on color={B.mint} />
          </div>
        </BCard>
      </div>
    </div>
  </BWindow>
);

// ───────────────────────────────────────────────────────────────────────
// B2 — Scanning
// ───────────────────────────────────────────────────────────────────────
const B2_Scanning = () => {
  const pct = 64;
  return (
    <BWindow title="Crumb — scanning…">
      <BAppBar />
      <div style={{ padding: 22, display: 'grid', gridTemplateColumns: '1.3fr 1fr',
        gap: 18, height: 'calc(100% - 116px)' }}>
        {/* Progress hero */}
        <BCard color={B.pinkSoft} pad={28} style={{ position: 'relative', overflow: 'hidden' }}>
          {/* spinning sticker */}
          <div style={{ position: 'absolute', top: -20, right: -20,
            width: 100, height: 100, borderRadius: '50%', background: B.blue,
            border: '2px solid ' + B.ink,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: B.paper, fontWeight: 800, fontSize: 14,
            animation: 'bspin 4s linear infinite' }}>
            sweeping
          </div>
          <style>{`@keyframes bspin{to{transform:rotate(360deg)}}`}</style>

          <BPill color={B.lemon}>
            <span style={{ width: 6, height: 6, borderRadius: '50%',
              background: B.ink, display: 'inline-block' }} />
            Live
          </BPill>
          <h2 style={{ fontWeight: 700, fontSize: 30, letterSpacing: -1,
            margin: '12px 0 4px' }}>
            Sweeping <span style={{ background: B.lemon,
              border: '2px solid ' + B.ink, padding: '0 8px',
              borderRadius: 8, display: 'inline-block' }}>Macintosh HD</span>
          </h2>
          <div style={{ fontSize: 13, color: B.ink2, fontWeight: 500 }}>
            We&rsquo;re grouping similar stuff so the cleanup is one click.
          </div>

          {/* Big percent */}
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: 14,
            margin: '28px 0 14px' }}>
            <div style={{ fontWeight: 700, fontSize: 96, letterSpacing: -4,
              lineHeight: 0.9, color: B.ink }}>
              {pct}<span style={{ color: B.pink, fontSize: 48 }}>%</span>
            </div>
            <div style={{ flex: 1, marginBottom: 10 }}>
              <BBar pct={pct} color={B.pink} height={16} />
              <div style={{ display: 'flex', justifyContent: 'space-between',
                marginTop: 8, fontSize: 12, fontWeight: 600 }}>
                <span>412,320 of 643,210 files</span>
                <span>~38s left</span>
              </div>
            </div>
          </div>

          <div style={{ background: B.paper, border: '2px solid ' + B.ink,
            borderRadius: 12, padding: '12px 14px',
            fontFamily: '"Geist Mono", ui-monospace, monospace',
            fontSize: 12, color: B.ink, boxShadow: chunk(3, 3) }}>
            <div style={{ color: B.ink2, fontSize: 10, marginBottom: 4,
              fontFamily: '"Space Grotesk", sans-serif', fontWeight: 700,
              letterSpacing: 0.5, textTransform: 'uppercase' }}>
              currently scanning
            </div>
            ~/Library/Application Support/Slack/Cache/v45-store
          </div>

          <div style={{ display: 'flex', gap: 8, marginTop: 18 }}>
            <button style={{ background: B.paper, border: '2px solid ' + B.ink,
              borderRadius: 10, padding: '8px 14px', fontSize: 13, fontWeight: 700,
              boxShadow: chunk(3, 3), display: 'flex', alignItems: 'center', gap: 6 }}>
              <Icon name="pause" size={13} fill="currentColor" stroke={0} />Pause
            </button>
            <button style={{ background: B.paper, border: '2px solid ' + B.ink,
              borderRadius: 10, padding: '8px 14px', fontSize: 13, fontWeight: 600,
              boxShadow: chunk(3, 3) }}>Cancel</button>
            <div style={{ flex: 1 }} />
            <label style={{ display: 'flex', alignItems: 'center', gap: 7, fontSize: 12,
              fontWeight: 500 }}>
              <input type="checkbox" defaultChecked />
              Include hidden folders
            </label>
          </div>
        </BCard>

        {/* Live finds */}
        <BCard pad={18}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
            <div style={{ fontWeight: 700, fontSize: 14, letterSpacing: 0.3,
              textTransform: 'uppercase' }}>Biggest so far</div>
            <div style={{ flex: 1 }} />
            <BPill color={B.lemon}>live</BPill>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {HOME_FOLDERS.slice(0, 6).map((f, i) => (
              <div key={f.name}>
                <div style={{ display: 'flex', justifyContent: 'space-between',
                  alignItems: 'center', marginBottom: 5 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <div style={{ width: 10, height: 10, borderRadius: 3,
                      background: B_HUES[i % B_HUES.length],
                      border: '1.5px solid ' + B.ink }} />
                    <span style={{ fontSize: 13, fontWeight: 600 }}>{f.name}</span>
                  </div>
                  <span style={{ fontSize: 12, fontWeight: 700,
                    fontVariantNumeric: 'tabular-nums' }}>{fmtBytes(f.size)}</span>
                </div>
                <BBar pct={(f.size / 142e9) * 100} color={B_HUES[i % B_HUES.length]} height={8} />
              </div>
            ))}
          </div>
          <div style={{ marginTop: 16, padding: 12, background: B.lemonSoft,
            border: '2px solid ' + B.ink, borderRadius: 12,
            fontSize: 12, fontWeight: 600, display: 'flex', gap: 8 }}>
            <Icon name="sparkle" size={16} stroke={2} />
            Spotted 14 stale node_modules — about <b>24 GB</b> easy.
          </div>
        </BCard>
      </div>
    </BWindow>
  );
};

// ───────────────────────────────────────────────────────────────────────
// B3 — Dashboard (Sunburst)
// ───────────────────────────────────────────────────────────────────────
const B3_Dashboard = () => (
  <BWindow title="Crumb — overview">
    <BAppBar active="overview" />
    <div style={{ padding: '14px 20px 20px', height: 'calc(100% - 116px)',
      display: 'flex', flexDirection: 'column', gap: 14 }}>
      {/* Stat row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
        {[
          { label: 'Used',         value: '612 GB', color: B.pink,  sub: '61% of 1 TB' },
          { label: 'Free',         value: '388 GB', color: B.mint,  sub: '39% available' },
          { label: 'Items',        value: '1.2M',   color: B.lemon, sub: '612K folders' },
          { label: 'Could free',   value: '57 GB',  color: B.blue,  sub: '5 quick wins', cta: true },
        ].map((s) => (
          <BCard key={s.label} pad={14} color={s.color}
            style={{ color: s.cta ? B.paper : B.ink }}>
            <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 0.6,
              textTransform: 'uppercase' }}>{s.label}</div>
            <div style={{ fontWeight: 700, fontSize: 32, letterSpacing: -0.8,
              marginTop: 4 }}>{s.value}</div>
            <div style={{ fontSize: 12, fontWeight: 600, marginTop: 2,
              opacity: 0.85 }}>{s.sub}</div>
          </BCard>
        ))}
      </div>

      {/* Main viz + side */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr',
        gap: 14, flex: 1, minHeight: 0 }}>
        <BCard pad={20} style={{ display: 'flex', flexDirection: 'column' }}>
          <div style={{ display: 'flex', alignItems: 'flex-start',
            justifyContent: 'space-between', marginBottom: 14 }}>
            <div>
              <div style={{ fontWeight: 700, fontSize: 15 }}>
                What&rsquo;s using your disk
              </div>
              <div style={{ fontSize: 12, color: B.ink2, marginTop: 2, fontWeight: 500 }}>
                Sunburst &mdash; outer ring = top folders, inner = subfolder split.
              </div>
            </div>
            <BVizSwitcher active="sun" />
          </div>
          <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 24,
            justifyContent: 'center' }}>
            <Sunburst items={TOP_FOLDERS} size={300} />
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, minWidth: 200 }}>
              {TOP_FOLDERS.map((f, i) => (
                <div key={f.name} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <div style={{ width: 14, height: 14, borderRadius: 4,
                    background: B_HUES[i % B_HUES.length],
                    border: '1.5px solid ' + B.ink }} />
                  <div style={{ flex: 1, fontSize: 12, fontWeight: 600 }}>
                    {f.name}
                    {f.protected && <Icon name="shield" size={11} stroke={2.4}
                      style={{ marginLeft: 4, verticalAlign: -1, color: B.ink2 }} />}
                  </div>
                  <div style={{ fontSize: 12, fontWeight: 700,
                    fontVariantNumeric: 'tabular-nums' }}>{fmtBytes(f.size)}</div>
                </div>
              ))}
            </div>
          </div>
        </BCard>

        {/* Side */}
        <div style={{ display: 'grid', gridTemplateRows: '1fr auto', gap: 14 }}>
          <BCard pad={16}>
            <div style={{ display: 'flex', justifyContent: 'space-between',
              alignItems: 'center', marginBottom: 12 }}>
              <div style={{ fontWeight: 700, fontSize: 14 }}>By file type</div>
              <BPill color={B.lemonSoft}>bar list</BPill>
            </div>
            {FILE_TYPES.slice(0, 6).map((t, i) => {
              const pct = (t.size / 168e9) * 100;
              return (
                <div key={t.name} style={{ display: 'flex', alignItems: 'center', gap: 10,
                  padding: '5px 0' }}>
                  <div style={{ width: 24, height: 24, borderRadius: 6,
                    background: B_HUES[i % B_HUES.length],
                    border: '1.5px solid ' + B.ink,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    color: B.ink }}>
                    <Icon name={t.icon} size={13} stroke={2.2} />
                  </div>
                  <div style={{ flex: 1, fontSize: 12 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between',
                      marginBottom: 3 }}>
                      <span style={{ fontWeight: 600 }}>{t.name}</span>
                      <span style={{ fontWeight: 700,
                        fontVariantNumeric: 'tabular-nums' }}>{fmtBytes(t.size)}</span>
                    </div>
                    <BBar pct={pct} color={B_HUES[i % B_HUES.length]} height={6} />
                  </div>
                </div>
              );
            })}
          </BCard>

          <BCard color={B.lemon} pad={16}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
              <Icon name="sparkle" size={16} stroke={2.2} />
              <div style={{ fontWeight: 700, fontSize: 14 }}>Quick wins</div>
              <div style={{ flex: 1 }} />
              <BPill color={B.paper}>save 57 GB</BPill>
            </div>
            {SUGGESTIONS.slice(0, 3).map((s, i) => (
              <div key={s.title} style={{
                display: 'flex', alignItems: 'center', gap: 10,
                background: B.paper, padding: '8px 10px', borderRadius: 8,
                border: '2px solid ' + B.ink, marginBottom: i < 2 ? 6 : 0,
                boxShadow: chunk(2, 2),
              }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 12, fontWeight: 700,
                    whiteSpace: 'nowrap', textOverflow: 'ellipsis', overflow: 'hidden' }}>
                    {s.title}
                  </div>
                  <div style={{ fontSize: 11, color: B.ink2, fontWeight: 500,
                    whiteSpace: 'nowrap', textOverflow: 'ellipsis', overflow: 'hidden' }}>
                    {s.detail}
                  </div>
                </div>
                <div style={{ fontWeight: 800, fontSize: 14, color: B.pink }}>
                  {fmtBytes(s.save)}
                </div>
              </div>
            ))}
          </BCard>
        </div>
      </div>
    </div>
  </BWindow>
);

// ───────────────────────────────────────────────────────────────────────
// B4 — Drill-down (file tree view)
// ───────────────────────────────────────────────────────────────────────
const B4_Drill = () => (
  <BWindow title="Crumb — Users/lina">
    <BAppBar active="overview" />
    <div style={{ padding: '14px 20px 20px', height: 'calc(100% - 116px)' }}>
      {/* Breadcrumb */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 6,
        padding: '0 4px 12px', fontSize: 13 }}>
        <Icon name="drive" size={14} stroke={2} />
        <span style={{ fontWeight: 500 }}>Macintosh HD</span>
        <Icon name="chevron" size={12} stroke={2.4} />
        <span style={{ fontWeight: 500 }}>Users</span>
        <Icon name="chevron" size={12} stroke={2.4} />
        <span style={{ background: B.lemon, padding: '2px 8px', borderRadius: 6,
          border: '1.5px solid ' + B.ink, fontWeight: 700 }}>lina</span>
        <Icon name="chevron" size={12} stroke={2.4} />
        <span style={{ color: B.ink2, fontWeight: 500 }}>Developer</span>
        <div style={{ flex: 1 }} />
        <BPill color={B.mintSoft}>scanned 2d ago</BPill>
        <BVizSwitcher active="list" />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '210px 1fr 290px',
        gap: 14, height: 'calc(100% - 40px)' }}>
        {/* Tree */}
        <BCard pad={10} style={{ overflow: 'auto' }}>
          <div style={{ fontSize: 10, fontWeight: 800, color: B.ink2,
            letterSpacing: 0.5, textTransform: 'uppercase', padding: '2px 4px 8px' }}>
            folders
          </div>
          {[
            { n: 'Macintosh HD', d: 0, open: true,  size: '612G' },
            { n: 'Applications', d: 1, open: false, size: '78G' },
            { n: 'Users',        d: 1, open: true,  size: '412G' },
            { n: 'lina',         d: 2, open: true,  size: '412G' },
            { n: 'Movies',       d: 3, open: false, size: '142G' },
            { n: 'Photos Lib',   d: 3, open: false, size: '96G' },
            { n: 'Developer',    d: 3, open: true,  size: '84G', sel: true },
            { n: 'dashboard-v2', d: 4, open: false, size: '12G' },
            { n: 'api-server',   d: 4, open: false, size: '9G' },
            { n: 'old-prototype',d: 4, open: false, size: '6G' },
            { n: 'Downloads',    d: 3, open: false, size: '38G' },
            { n: 'Documents',    d: 3, open: false, size: '22G' },
            { n: 'System',       d: 1, open: false, size: '42G' },
          ].map((r, i) => (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 5,
              padding: '5px 6px', borderRadius: 6, marginLeft: r.d * 9,
              background: r.sel ? B.lemon : 'transparent',
              border: r.sel ? '1.5px solid ' + B.ink : '1.5px solid transparent',
              fontWeight: r.sel ? 700 : 500,
              boxShadow: r.sel ? chunk(2, 2) : 'none',
              marginBottom: r.sel ? 4 : 1,
              marginTop: r.sel ? 2 : 0,
            }}>
              <Icon name={r.open ? 'chevdown' : 'chevron'} size={10} stroke={2.4} />
              <Icon name="folder" size={12} fill={r.sel ? B.pink : B.blue}
                stroke={0} style={{ color: r.sel ? B.pink : B.blue }} />
              <span style={{ fontSize: 12, flex: 1 }}>{r.n}</span>
              <span style={{ fontSize: 10, fontWeight: 700,
                fontVariantNumeric: 'tabular-nums' }}>{r.size}</span>
            </div>
          ))}
        </BCard>

        {/* Content */}
        <BCard pad={0} style={{ display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
          <div style={{ padding: '12px 16px', borderBottom: '2px solid ' + B.ink,
            display: 'flex', alignItems: 'center', gap: 10, background: B.lemonSoft }}>
            <div style={{ width: 32, height: 32, borderRadius: 8, background: B.lemon,
              border: '1.5px solid ' + B.ink, display: 'flex', alignItems: 'center',
              justifyContent: 'center' }}>
              <Icon name="folder" size={16} fill="currentColor" stroke={0} />
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 700, fontSize: 15 }}>Developer</div>
              <div style={{ fontSize: 11, color: B.ink2, fontWeight: 500 }}>
                84 GB · 920,411 items · modified today
              </div>
            </div>
            <div style={{ display: 'flex', gap: 4, padding: 3, background: B.paper,
              borderRadius: 8, border: '1.5px solid ' + B.ink, fontSize: 11 }}>
              {['size', 'name', 'date', 'age'].map((s, i) => (
                <div key={s} style={{ padding: '4px 9px', borderRadius: 5,
                  background: i === 0 ? B.ink : 'transparent',
                  fontWeight: i === 0 ? 700 : 600,
                  color: i === 0 ? B.paper : B.ink }}>{s}</div>
              ))}
            </div>
          </div>
          <div style={{ flex: 1, overflow: 'auto' }}>
            {[
              { n: 'dashboard-v2',   sz: 12.4e9, items: '124K', mod: 0,   sub: 'node_modules · 8.4 GB' },
              { n: 'api-server',     sz: 9.2e9,  items: '88K',  mod: 1,   sub: 'node_modules · 3.8 GB' },
              { n: 'old-prototype',  sz: 6.0e9,  items: '62K',  mod: 620, sub: 'node_modules · 4.2 GB · stale', warn: true },
              { n: 'sandbox',        sz: 5.1e9,  items: '54K',  mod: 88,  sub: 'node_modules · 3.4 GB' },
              { n: 'portfolio',      sz: 4.6e9,  items: '48K',  mod: 540, sub: 'node_modules · 2.9 GB · stale', warn: true },
              { n: 'marketing-site', sz: 8.1e9,  items: '92K',  mod: 320, sub: 'node_modules · 6.1 GB' },
              { n: 'blog',           sz: 3.4e9,  items: '36K',  mod: 720, sub: 'node_modules · 2.2 GB · stale', warn: true },
              { n: 'internal-tools', sz: 3.0e9,  items: '32K',  mod: 210, sub: 'node_modules · 2.6 GB' },
              { n: '.git-archive',   sz: 1.8e9,  items: '4K',   mod: 90,  sub: 'hidden', hidden: true },
            ].map((r) => {
              const pct = (r.sz / 12.4e9) * 100;
              const color = r.warn ? B.pink : (r.hidden ? B.ink3 : B.blue);
              return (
                <div key={r.n} style={{
                  display: 'grid', gridTemplateColumns: '22px 1.2fr 1fr 80px 80px',
                  alignItems: 'center', gap: 12, padding: '12px 16px',
                  borderBottom: '2px solid ' + B.line2,
                  background: r.warn ? B.pinkSoft + '88' : 'transparent',
                  opacity: r.hidden ? 0.6 : 1,
                }}>
                  <input type="checkbox" defaultChecked={r.warn} />
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, minWidth: 0 }}>
                    <Icon name={r.hidden ? 'hidden' : 'folder'} size={15}
                      fill={r.hidden ? 'none' : color} stroke={r.hidden ? 2 : 0}
                      style={{ color }} />
                    <div style={{ minWidth: 0 }}>
                      <div style={{ fontWeight: 700, fontSize: 13 }}>{r.n}</div>
                      <div style={{ fontSize: 11, color: r.warn ? B.pink : B.ink2,
                        fontWeight: 500,
                        whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                        {r.sub}
                      </div>
                    </div>
                  </div>
                  <BBar pct={pct} color={color} height={7} />
                  <div style={{ fontSize: 12, color: B.ink2, fontWeight: 600 }}>
                    {fmtAge(r.mod)}
                  </div>
                  <div style={{ fontWeight: 800, fontSize: 15, textAlign: 'right',
                    fontVariantNumeric: 'tabular-nums' }}>{fmtBytes(r.sz)}</div>
                </div>
              );
            })}
          </div>
          <div style={{ padding: '10px 16px', borderTop: '2px solid ' + B.ink,
            background: B.lemonSoft, display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ fontSize: 12, fontWeight: 600 }}>3 selected · 9.3 GB</span>
            <div style={{ flex: 1 }} />
            <button style={{ background: B.paper, border: '1.5px solid ' + B.ink,
              borderRadius: 8, padding: '6px 12px', fontSize: 12, fontWeight: 600,
              boxShadow: chunk(2, 2) }}>Move to Trash</button>
            <button style={{ background: B.pink, color: B.paper, border: '1.5px solid ' + B.ink,
              borderRadius: 8, padding: '6px 12px', fontSize: 12, fontWeight: 700,
              boxShadow: chunk(2, 2), display: 'flex', alignItems: 'center', gap: 5 }}>
              <Icon name="trash" size={12} stroke={2.4} />Delete
            </button>
          </div>
        </BCard>

        {/* Detail */}
        <BCard pad={16}>
          <div style={{ width: '100%', height: 84, borderRadius: 12,
            background: B.pink, border: '2px solid ' + B.ink, boxShadow: chunk(3, 3),
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: B.paper, marginBottom: 14 }}>
            <Icon name="folder" size={40} fill="currentColor" stroke={0} />
          </div>
          <div style={{ fontWeight: 700, fontSize: 16 }}>dashboard-v2</div>
          <div style={{ fontFamily: '"Geist Mono", monospace', fontSize: 11,
            color: B.ink2, marginBottom: 14, wordBreak: 'break-all' }}>
            ~/Developer/dashboard-v2
          </div>
          {[
            ['Size', '12.4 GB'],
            ['Of which', 'node_modules · 8.4 GB'],
            ['Items', '124,310'],
            ['Last modified', 'today, 11:42'],
            ['Created', 'Aug 14, 2024'],
            ['Kind', 'Node project'],
          ].map((r) => (
            <div key={r[0]} style={{ display: 'flex', justifyContent: 'space-between',
              padding: '6px 0', borderTop: '1.5px solid ' + B.line2,
              fontSize: 12 }}>
              <span style={{ color: B.ink2, fontWeight: 500 }}>{r[0]}</span>
              <span style={{ fontWeight: 700 }}>{r[1]}</span>
            </div>
          ))}
          <div style={{ marginTop: 14, display: 'flex', flexDirection: 'column', gap: 8 }}>
            <button style={{ background: B.blue, color: B.paper,
              border: '2px solid ' + B.ink, borderRadius: 10,
              padding: '10px 12px', fontSize: 13, fontWeight: 700,
              boxShadow: chunk(3, 3),
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
              <Icon name="search" size={13} stroke={2.4} />Reveal in Finder
            </button>
            <button style={{ background: B.paper, color: B.ink,
              border: '2px solid ' + B.ink, borderRadius: 10,
              padding: '10px 12px', fontSize: 13, fontWeight: 700,
              boxShadow: chunk(3, 3) }}>Clean node_modules</button>
          </div>
        </BCard>
      </div>
    </div>
  </BWindow>
);

// ───────────────────────────────────────────────────────────────────────
// B5 — Groups (with chunky treemap)
// ───────────────────────────────────────────────────────────────────────
const B5_Groups = () => (
  <BWindow title="Crumb — groups">
    <BAppBar active="groups" />
    <div style={{ padding: '14px 20px 20px', height: 'calc(100% - 116px)',
      display: 'flex', flexDirection: 'column', gap: 14 }}>
      {/* Treemap hero */}
      <BCard pad={20}>
        <div style={{ display: 'flex', alignItems: 'flex-start',
          justifyContent: 'space-between', marginBottom: 14 }}>
          <div>
            <div style={{ fontWeight: 700, fontSize: 15 }}>
              Groups across your disk
            </div>
            <div style={{ fontSize: 12, color: B.ink2, marginTop: 2, fontWeight: 500,
              maxWidth: 540, lineHeight: 1.4 }}>
              Folders sharing a name &mdash; node_modules, .venv, caches &mdash; tallied
              everywhere they live. Treemap shows how much each group hogs.
            </div>
          </div>
          <BVizSwitcher active="tree" />
        </div>
        <BTreemap items={GROUPS.map((g) => ({ name: g.name, size: g.total }))}
          width="100%" height={170} />
      </BCard>

      {/* Group list */}
      <BCard pad={0} style={{ flex: 1, overflow: 'hidden', display: 'flex',
        flexDirection: 'column' }}>
        <div style={{ padding: '12px 16px', borderBottom: '2px solid ' + B.ink,
          display: 'flex', alignItems: 'center', gap: 10, background: B.lemonSoft }}>
          <input type="checkbox" />
          <div style={{ fontSize: 13, fontWeight: 700 }}>7 groups · 89.9 GB total</div>
          <div style={{ flex: 1 }} />
          <BPill color={B.paper}>
            <Icon name="filter" size={11} stroke={2.4} />Stale only
          </BPill>
          <BPill color={B.pink}>Free 38.4 GB →</BPill>
        </div>
        <div style={{ flex: 1, overflow: 'auto' }}>
          {GROUPS.map((g, i) => {
            const isOpen = i === 0;
            const color = B_HUES[i % B_HUES.length];
            return (
              <div key={g.name} style={{
                borderBottom: '2px solid ' + B.line2,
                background: isOpen ? B.lemonSoft + '70' : 'transparent',
              }}>
                <div style={{ display: 'grid',
                  gridTemplateColumns: '22px 22px 1.4fr 1fr 1fr 100px 100px',
                  alignItems: 'center', gap: 10, padding: '12px 16px' }}>
                  <input type="checkbox" defaultChecked={i === 0 || i === 2} />
                  <Icon name={isOpen ? 'chevdown' : 'chevron'} size={14} stroke={2.4} />
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <div style={{ width: 28, height: 28, borderRadius: 7,
                      background: color, border: '1.5px solid ' + B.ink,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      color: B.ink, fontWeight: 800, fontSize: 14,
                      fontFamily: '"Geist Mono", monospace' }}>
                      {g.name.replace(/[^a-z]/gi, '').slice(0, 1).toUpperCase()}
                    </div>
                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <span style={{ fontFamily: '"Geist Mono", monospace',
                          fontWeight: 700, fontSize: 13 }}>{g.name}</span>
                        {g.devOnly && <BPill color={B.blueSoft}>dev</BPill>}
                      </div>
                      <div style={{ fontSize: 11, color: B.ink2, marginTop: 2,
                        fontWeight: 500 }}>{g.tagline}</div>
                    </div>
                  </div>
                  <div style={{ fontSize: 12, color: B.ink2, fontWeight: 600 }}>
                    {g.count} folders
                  </div>
                  <div style={{ fontSize: 12, color: B.ink2, fontWeight: 600 }}>
                    avg age {fmtAge(g.avgAge)}
                  </div>
                  <div>
                    <BBar pct={(g.total / 42e9) * 100} color={color} height={8} />
                  </div>
                  <div style={{ fontWeight: 800, fontSize: 18, textAlign: 'right',
                    fontVariantNumeric: 'tabular-nums' }}>{fmtBytes(g.total)}</div>
                </div>
                {isOpen && g.instances && (
                  <div style={{ padding: '0 16px 12px 60px' }}>
                    {g.instances.slice(0, 6).map((it) => {
                      const stale = it.mod > 180;
                      return (
                        <div key={it.path} style={{ display: 'grid',
                          gridTemplateColumns: '22px 1.5fr 110px 90px 100px',
                          alignItems: 'center', gap: 10, padding: '8px 10px',
                          borderRadius: 8, background: B.paper,
                          border: '1.5px solid ' + B.line2, marginBottom: 6 }}>
                          <input type="checkbox" defaultChecked={stale} />
                          <div style={{ fontFamily: '"Geist Mono", monospace',
                            fontSize: 11, color: B.ink, fontWeight: 500,
                            whiteSpace: 'nowrap', overflow: 'hidden',
                            textOverflow: 'ellipsis' }}>{it.path}</div>
                          <div style={{ fontSize: 11, fontWeight: 700,
                            color: stale ? B.pink : B.ink2 }}>
                            {fmtAge(it.mod)}{stale && ' · stale'}
                          </div>
                          <BBar pct={(it.size / 8.4e9) * 100}
                            color={stale ? B.pink : B.blue} height={6} />
                          <div style={{ fontWeight: 700, fontSize: 12, textAlign: 'right',
                            fontVariantNumeric: 'tabular-nums' }}>{fmtBytes(it.size)}</div>
                        </div>
                      );
                    })}
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8,
                      padding: '4px 0', fontSize: 11, color: B.ink2, fontWeight: 600 }}>
                      + 2 more instances
                      <div style={{ flex: 1 }} />
                      <button style={{ background: B.pink, color: B.paper,
                        border: '2px solid ' + B.ink, borderRadius: 8,
                        padding: '7px 12px', fontSize: 12, fontWeight: 700,
                        boxShadow: chunk(2, 2),
                        display: 'flex', alignItems: 'center', gap: 5 }}>
                        <Icon name="trash" size={12} stroke={2.4} />
                        Delete 3 · free 9.8 GB
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </BCard>
    </div>
  </BWindow>
);

// ───────────────────────────────────────────────────────────────────────
// B6 — Delete confirm
// ───────────────────────────────────────────────────────────────────────
const B6_Delete = () => {
  const total = DELETE_TARGETS.reduce((s, t) => s + t.size, 0);
  return (
    <BWindow title="Crumb — confirm cleanup">
      <BAppBar active="groups" />
      <div style={{ position: 'absolute', top: 102, left: 0, right: 0, bottom: 0,
        background: 'rgba(15,10,46,.32)' }} />
      <div style={{ position: 'relative', height: 'calc(100% - 116px)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
        <div style={{
          width: 600, background: B.paper, borderRadius: 20,
          border: '2px solid ' + B.ink, boxShadow: '0 12px 0 ' + B.ink,
          overflow: 'hidden',
        }}>
          <div style={{ padding: '24px 26px 16px', background: B.lemonSoft,
            borderBottom: '2px solid ' + B.ink }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ width: 50, height: 50, borderRadius: 12,
                background: B.pink, border: '2px solid ' + B.ink, boxShadow: chunk(3, 3),
                color: B.paper,
                display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Icon name="trash" size={22} stroke={2.4} />
              </div>
              <div style={{ flex: 1 }}>
                <h3 style={{ fontWeight: 700, fontSize: 24, letterSpacing: -0.6, margin: 0 }}>
                  Delete 5 items?
                </h3>
                <div style={{ fontSize: 13, color: B.ink2, marginTop: 2, fontWeight: 500 }}>
                  Frees about <b style={{ color: B.ink }}>{fmtBytes(total)}</b> on
                  Macintosh HD.
                </div>
              </div>
            </div>
          </div>

          {/* Protected warning */}
          <div style={{ margin: 20, padding: '12px 14px', borderRadius: 12,
            background: B.pinkSoft, border: '2px solid ' + B.ink,
            boxShadow: chunk(3, 3),
            display: 'flex', gap: 10, alignItems: 'flex-start' }}>
            <Icon name="shield" size={20} stroke={2.4} style={{ marginTop: 1 }} />
            <div style={{ fontSize: 12.5, lineHeight: 1.5, fontWeight: 500 }}>
              <b>1 protected path was excluded.</b> /System/Library/Caches is part
              of macOS &mdash; deleting it can break apps or boot. We&rsquo;ll skip it.
            </div>
          </div>

          {/* Item list */}
          <div style={{ background: B.bg, borderTop: '2px solid ' + B.ink,
            borderBottom: '2px solid ' + B.ink, maxHeight: 220, overflow: 'auto' }}>
            {DELETE_TARGETS.map((t) => (
              <div key={t.path} style={{ display: 'grid',
                gridTemplateColumns: '20px 1fr 90px 80px', alignItems: 'center', gap: 10,
                padding: '10px 26px', borderBottom: '1.5px solid ' + B.line2,
                opacity: t.protected ? 0.55 : 1,
                background: t.protected ? B.pinkSoft + '88' : 'transparent' }}>
                {t.protected
                  ? <Icon name="shield" size={14} stroke={2.4} />
                  : <Icon name="trash" size={13} stroke={2.2} />}
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontFamily: '"Geist Mono", monospace', fontSize: 11.5,
                    fontWeight: 500,
                    whiteSpace: 'nowrap', overflow: 'hidden',
                    textOverflow: 'ellipsis' }}>{t.path}</div>
                  {t.protected && (
                    <div style={{ fontSize: 10.5, color: B.pink, marginTop: 2,
                      fontWeight: 700 }}>
                      Skipped — system protected
                    </div>
                  )}
                </div>
                <div style={{ fontSize: 11, color: B.ink2, fontWeight: 600 }}>
                  {fmtAge(t.mod)}
                </div>
                <div style={{ fontWeight: 800, fontSize: 14, textAlign: 'right',
                  textDecoration: t.protected ? 'line-through' : 'none' }}>
                  {fmtBytes(t.size)}
                </div>
              </div>
            ))}
          </div>

          {/* Options */}
          <div style={{ padding: '14px 26px 22px' }}>
            <div style={{ display: 'flex', gap: 10, marginBottom: 14 }}>
              {[
                { id: 'trash', label: 'Move to Trash', sub: 'recoverable', on: true },
                { id: 'gone',  label: 'Delete forever', sub: 'no undo', on: false },
              ].map((o) => (
                <div key={o.id} style={{
                  flex: 1, padding: '11px 12px', borderRadius: 12,
                  border: '2px solid ' + B.ink,
                  background: o.on ? B.mintSoft : B.paper,
                  boxShadow: o.on ? chunk(3, 3) : 'none',
                  display: 'flex', alignItems: 'center', gap: 10,
                }}>
                  <div style={{ width: 18, height: 18, borderRadius: '50%',
                    border: '2px solid ' + B.ink,
                    background: o.on ? B.mint : B.paper,
                    display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    {o.on && <Icon name="check" size={11} stroke={3} />}
                  </div>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 700 }}>{o.label}</div>
                    <div style={{ fontSize: 11, color: B.ink2, fontWeight: 500 }}>{o.sub}</div>
                  </div>
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: 6,
                fontSize: 12, fontWeight: 500 }}>
                <input type="checkbox" defaultChecked />
                Snapshot first (30-day undo)
              </label>
              <div style={{ flex: 1 }} />
              <button style={{ background: 'transparent', border: 'none',
                fontSize: 13, fontWeight: 600, padding: '10px 14px' }}>Cancel</button>
              <button style={{ background: B.pink, color: B.paper,
                border: '2px solid ' + B.ink, borderRadius: 10,
                padding: '11px 18px', fontSize: 13, fontWeight: 800,
                boxShadow: chunk(3, 3) }}>
                Move 4 · free {fmtBytes(total - 2.1e9)}
              </button>
            </div>
          </div>
        </div>
      </div>
    </BWindow>
  );
};

// ───────────────────────────────────────────────────────────────────────
// B7 — Settings
// ───────────────────────────────────────────────────────────────────────
const B7_Settings = () => (
  <BWindow title="Crumb — settings">
    <BAppBar active="overview" />
    <div style={{ padding: '14px 20px 20px', height: 'calc(100% - 116px)',
      display: 'grid', gridTemplateColumns: '220px 1fr', gap: 14 }}>
      {/* Sidebar */}
      <BCard pad={10}>
        <div style={{ fontSize: 10, fontWeight: 800, color: B.ink2,
          letterSpacing: 0.6, textTransform: 'uppercase', padding: '4px 8px 8px' }}>
          settings
        </div>
        {[
          ['Scans',       'cog',     false, B.blue],
          ['Detection',   'sparkle', false, B.lemon],
          ['Safety',      'shield',  true,  B.pink],
          ['Snapshots',   'clock',   false, B.mint],
          ['Export',      'download',false, B.peach],
          ['About',       'other',   false, B.ink2],
        ].map(([n, icon, sel, c]) => (
          <div key={n} style={{
            display: 'flex', alignItems: 'center', gap: 10, padding: '9px 10px',
            borderRadius: 10, fontSize: 13, fontWeight: 700,
            color: B.ink,
            background: sel ? B.lemon : 'transparent',
            border: sel ? '2px solid ' + B.ink : '2px solid transparent',
            boxShadow: sel ? chunk(2, 2) : 'none',
            marginBottom: sel ? 4 : 1,
          }}>
            <div style={{ width: 22, height: 22, borderRadius: 6, background: c,
              border: '1.5px solid ' + B.ink,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: B.ink }}>
              <Icon name={icon} size={12} stroke={2.2} />
            </div>
            {n}
          </div>
        ))}
      </BCard>

      {/* Main panel — Safety */}
      <BCard pad={26} style={{ overflow: 'auto' }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14,
          paddingBottom: 18, borderBottom: '2px solid ' + B.line2, marginBottom: 18 }}>
          <div style={{ width: 50, height: 50, borderRadius: 12,
            background: B.pink, border: '2px solid ' + B.ink, boxShadow: chunk(3, 3),
            color: B.paper,
            display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Icon name="shield" size={24} stroke={2.4} />
          </div>
          <div>
            <h2 style={{ fontWeight: 700, fontSize: 26, letterSpacing: -0.6, margin: 0 }}>
              Safety
            </h2>
            <div style={{ fontSize: 13, color: B.ink2, marginTop: 4, fontWeight: 500 }}>
              What Crumb refuses to delete &mdash; even if you tell it to.
            </div>
          </div>
        </div>

        {[
          ['Protect system paths',      'Always skip /System, /usr, /private, plus Windows / Linux equivalents.', true],
          ['Protect active projects',   'Skip folders modified in the last 7 days unless explicitly chosen.',     true],
          ['Confirm large deletes',     'Show a dialog for any cleanup over 1 GB.',                               true],
          ['Always snapshot first',     '30-day rollback. Uses ~1% of freed space.',                              true],
          ['Allow deleting hidden',     'Show and allow removal of dot-folders like .Trash, .config.',            false],
        ].map(([n, desc, on], i, all) => (
          <div key={n} style={{ display: 'flex', alignItems: 'flex-start', gap: 14,
            padding: '14px 0',
            borderBottom: i < all.length - 1 ? '1.5px solid ' + B.line2 : 'none' }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 700 }}>{n}</div>
              <div style={{ fontSize: 12, color: B.ink2, marginTop: 2, fontWeight: 500 }}>
                {desc}
              </div>
            </div>
            <BToggle on={on} />
          </div>
        ))}

        {/* Protected paths */}
        <div style={{ marginTop: 22 }}>
          <div style={{ display: 'flex', alignItems: 'center', marginBottom: 10 }}>
            <div style={{ fontSize: 14, fontWeight: 700 }}>Protected paths</div>
            <div style={{ flex: 1 }} />
            <button style={{ background: B.lemon, border: '2px solid ' + B.ink,
              borderRadius: 8, padding: '6px 11px', fontSize: 12, fontWeight: 700,
              boxShadow: chunk(2, 2),
              display: 'flex', alignItems: 'center', gap: 5 }}>
              <Icon name="plus" size={12} stroke={2.6} />Add path
            </button>
          </div>
          <div style={{ border: '2px solid ' + B.ink, borderRadius: 12,
            overflow: 'hidden', background: B.paper }}>
            {[
              { p: '/System',                       sys: true },
              { p: '/Library',                      sys: true },
              { p: '/private',                      sys: true },
              { p: '/usr',                          sys: true },
              { p: '~/Library/Application Support', sys: false },
              { p: '~/Developer/work-critical',     sys: false },
            ].map((r, i, all) => (
              <div key={r.p} style={{ display: 'flex', alignItems: 'center', gap: 10,
                padding: '10px 14px',
                borderBottom: i < all.length - 1 ? '1.5px solid ' + B.line2 : 'none' }}>
                <Icon name="shield" size={14} stroke={2.4}
                  style={{ color: r.sys ? B.pink : B.ink2 }} />
                <span style={{ fontFamily: '"Geist Mono", monospace', fontSize: 12,
                  fontWeight: 500 }}>{r.p}</span>
                {r.sys && <BPill color={B.pinkSoft}>system</BPill>}
                <div style={{ flex: 1 }} />
                {!r.sys && (
                  <Icon name="x" size={14} stroke={2.4} style={{ color: B.ink2 }} />
                )}
              </div>
            ))}
          </div>
        </div>
      </BCard>
    </div>
  </BWindow>
);

Object.assign(window, {
  B1_Start, B2_Scanning, B3_Dashboard, B4_Drill, B5_Groups, B6_Delete, B7_Settings,
});
