// proto-app.jsx — top-level App component: state wiring + screen router.


const App = () => {
  const [state, setState] = React.useState(makeInitState);

  // Polymorphic setter: accepts either an object patch or a fn(state)→patch.
  const set = React.useCallback((patch) => {
    setState((s) => ({ ...s, ...(typeof patch === 'function' ? patch(s) : patch) }));
  }, []);

  // Navigation helpers.
  const nav = React.useMemo(() => ({
    goto: (screen, extra = {}) => {
      if (screen === 'scanning') {
        // Reset progress and start the animation.
        set({
          screen: 'scanning', scanning: true, scanPaused: false,
          scanProgress: 0, scanCurrent: SCAN_PATHS[0],
          scanDriveId: extra.driveId || 'mac',
        });
        return;
      }
      if (screen === 'drill') {
        set({ screen: 'drill', tab: 'overview',
          drillCrumb: extra.crumb, drillItems: extra.items,
          drillSelected: {} });
        return;
      }
      if (screen === 'overview') {
        set({ screen: 'overview', tab: 'overview' });
        return;
      }
      if (screen === 'groups') {
        set({ screen: 'groups', tab: 'groups' });
        return;
      }
      if (screen === 'types') {
        set({ screen: 'types', tab: 'types' });
        return;
      }
      if (screen === 'history') {
        set({ screen: 'history', tab: 'history' });
        return;
      }
      if (screen === 'settings') {
        set({ screen: 'settings', tab: 'overview' });
        return;
      }
      if (screen === 'start') {
        set({ screen: 'start', tab: 'overview', scanning: false,
          drillSelected: {}, groupsSelected: {} });
        return;
      }
      set({ screen, ...extra });
    },
    gotoTab: (tabId) => {
      if (tabId === 'groups')   { set({ screen: 'groups',   tab: 'groups'   }); return; }
      if (tabId === 'overview') { set({ screen: 'overview', tab: 'overview' }); return; }
      if (tabId === 'types')    { set({ screen: 'types',    tab: 'types'    }); return; }
      if (tabId === 'history')  { set({ screen: 'history',  tab: 'history'  }); return; }
      set({ tab: tabId });
    },
  }), [set]);

  const ctxValue = React.useMemo(() => ({ state, set, nav }), [state, set, nav]);

  // Pick the active screen.
  let body = null;
  if (state.screen === 'start')     body = <PStart />;
  else if (state.screen === 'scanning') body = <PScanning />;
  else if (state.screen === 'overview') body = <POverview />;
  else if (state.screen === 'drill')    body = <PDrill />;
  else if (state.screen === 'groups')   body = <PGroups />;
  else if (state.screen === 'types')    body = <PTypes />;
  else if (state.screen === 'history')  body = <PHistory />;
  else if (state.screen === 'settings') body = <PSettings />;

  const scale = useFitScale(1280, 820);

  return (
    <AppCtx.Provider value={ctxValue}>
      <div style={{
        width: '100vw', height: '100vh', overflow: 'hidden',
        background: '#E8DECB',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        backgroundImage: `radial-gradient(rgba(42,33,24,.07) 1px, transparent 1px)`,
        backgroundSize: '24px 24px',
      }}>
        <div style={{ width: 1280, height: 820, transform: `scale(${scale})`,
          transformOrigin: 'center center' }}>
          <div style={{
            width: '100%', height: '100%', background: A.bg, borderRadius: 22,
            overflow: 'hidden', position: 'relative',
            fontFamily: '"Geist", "Inter", ui-sans-serif, sans-serif',
            color: A.ink,
            boxShadow: '0 30px 80px rgba(42,33,24,.25), 0 0 0 1px ' + A.line2,
          }}>
            {/* Title bar */}
            <div style={{
              height: 38, background: '#F0E7D2',
              borderBottom: '1px solid ' + A.line,
              display: 'flex', alignItems: 'center', padding: '0 14px', gap: 10,
            }}>
              <div style={{ display: 'flex', gap: 6 }}>
                {['#E55934', '#F3B95F', '#5FA37C'].map((c) => (
                  <div key={c} style={{ width: 11, height: 11, borderRadius: '50%',
                    background: c,
                    boxShadow: 'inset 0 0 0 0.5px rgba(0,0,0,.12)' }} />
                ))}
              </div>
              <div style={{ flex: 1, textAlign: 'center', fontSize: 12,
                color: A.ink2, fontWeight: 500, letterSpacing: 0.1 }}>
                Crumb — {DRIVES.find((d) => d.id === state.scanDriveId)?.name}
              </div>
              <div style={{ width: 36 }} />
            </div>

            <IAppBar />

            {/* Body with subtle screen-change crossfade */}
            <div key={state.screen} style={{
              height: 'calc(100% - 76px - 38px)',
              animation: 'aScreenIn .25s ease',
            }}>
              <style>{`@keyframes aScreenIn{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:none}}`}</style>
              {body}
            </div>

            <DeleteModal />
            <Toast />
          </div>
        </div>
      </div>
    </AppCtx.Provider>
  );
};

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
