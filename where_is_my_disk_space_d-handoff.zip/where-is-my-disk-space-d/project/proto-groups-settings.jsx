// proto-groups-settings.jsx — Groups, Delete modal, Settings.

// ───────────────────────────────────────────────────────────────────────
// Groups
// ───────────────────────────────────────────────────────────────────────

// Fixed bubble positions sized by group.total — same as the static screen.
const computeBubbles = (groups) => {
  const bubbles = [
    { idx: 0, cx: 200, cy: 130, color: A.coral  },
    { idx: 2, cx: 380, cy: 90,  color: A.honey  },
    { idx: 4, cx: 510, cy: 165, color: A.sage   },
    { idx: 1, cx: 640, cy: 95,  color: A.lilac  },
    { idx: 5, cx: 730, cy: 175, color: A.navy   },
    { idx: 6, cx: 840, cy: 105, color: '#D86A8A'},
    { idx: 3, cx: 880, cy: 195, color: '#7BAFD4'},
  ];
  const maxTotal = Math.max(...groups.map((g) => g.total));
  return bubbles.map((b) => {
    const g = groups[b.idx];
    const r = 18 + Math.sqrt(g.total / maxTotal) * 80;
    return { ...b, g, r };
  });
};

const PGroups = () => {
  const { state, nav, set } = useApp();
  const groups = state.groupsData;
  const totalAll = groups.reduce((s, g) => s + g.total, 0);
  const bubbles = computeBubbles(groups);
  const selPaths = Object.keys(state.groupsSelected)
    .filter((k) => state.groupsSelected[k]);

  // Compute total selected size by looking up instance paths
  const selSize = groups.reduce((acc, g) => {
    if (!g.instances) return acc;
    return acc + g.instances.filter((it) => state.groupsSelected[it.path])
      .reduce((s, it) => s + it.size, 0);
  }, 0);

  const toggleGroup = (name) => {
    set({ expandedGroup: state.expandedGroup === name ? null : name });
  };

  const bulkDeleteSelected = () => {
    const targets = [];
    groups.forEach((g) => {
      if (!g.instances) return;
      g.instances.forEach((it) => {
        if (state.groupsSelected[it.path]) {
          targets.push({ path: it.path, size: it.size, mod: it.mod });
        }
      });
    });
    if (targets.length) set({ deleteOpen: true, deleteTargets: targets });
  };

  const filteredGroups = state.groupsFilter === 'stale'
    ? groups.filter((g) => g.avgAge > 90) : groups;

  return (
    <div style={{ padding: '0 20px 20px', height: '100%',
      display: 'flex', flexDirection: 'column', gap: 14 }}>
      {/* Bubble hero */}
      <Card pad={20}>
        <div style={{ display: 'flex', alignItems: 'flex-start',
          justifyContent: 'space-between', marginBottom: 6 }}>
          <div>
            <div style={{ fontWeight: 700, fontSize: 15 }}>Groups by name</div>
            <div style={{ fontSize: 12, color: A.ink2, marginTop: 2,
              maxWidth: 540, lineHeight: 1.4 }}>
              Folders with the same name across your disk, totalled.
              Click a bubble to expand the group below.
            </div>
          </div>
          <Pill color={A.honey} soft={A.honeySoft}>
            {groups.length} groups · {fmtBytes(totalAll)}
          </Pill>
        </div>
        <div style={{ position: 'relative', height: 240 }}>
          <svg width="100%" height="240" viewBox="0 0 1000 240"
            style={{ display: 'block' }}>
            {bubbles.map((b) => {
              const selected = state.expandedGroup === b.g.name;
              return (
                <g key={b.g.name} style={{ cursor: 'pointer' }}
                  onClick={() => toggleGroup(b.g.name)}>
                  <circle cx={b.cx} cy={b.cy} r={b.r} fill={b.color}
                    opacity={selected ? 1 : 0.88}
                    stroke={selected ? A.ink : 'none'} strokeWidth={selected ? 3 : 0} />
                  <text x={b.cx} y={b.cy - 4} textAnchor="middle"
                    fontFamily="Geist, sans-serif" fontWeight="600"
                    fontSize={b.r > 50 ? 14 : 11} fill="#fff"
                    style={{ pointerEvents: 'none' }}>
                    {b.g.name}
                  </text>
                  <text x={b.cx} y={b.cy + (b.r > 50 ? 14 : 10)} textAnchor="middle"
                    fontFamily="Bricolage Grotesque, sans-serif" fontWeight="800"
                    fontSize={b.r > 50 ? 22 : 14} fill="#fff"
                    style={{ pointerEvents: 'none' }}>
                    {fmtBytes(b.g.total)}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>
      </Card>

      {/* Group list */}
      <Card pad={0} style={{ flex: 1, overflow: 'hidden', display: 'flex',
        flexDirection: 'column' }}>
        <div style={{ padding: '12px 16px', borderBottom: '1px solid ' + A.line,
          display: 'flex', alignItems: 'center', gap: 10 }}>
          <input type="checkbox" />
          <div style={{ fontSize: 13, fontWeight: 600 }}>
            {filteredGroups.length} groups · {fmtBytes(totalAll)}
          </div>
          <div style={{ flex: 1 }} />
          <button
            onClick={() => set({ groupsFilter: state.groupsFilter === 'stale' ? 'all' : 'stale' })}
            style={{
              display: 'inline-flex', alignItems: 'center', gap: 5,
              padding: '4px 10px', borderRadius: 999, fontSize: 11, fontWeight: 600,
              background: state.groupsFilter === 'stale' ? A.ink : A.panel,
              color: state.groupsFilter === 'stale' ? A.paper : A.ink2,
              border: 'none', cursor: 'pointer', fontFamily: 'inherit',
            }}>
            <Icon name="filter" size={11} stroke={2} />
            Stale only{state.groupsFilter === 'stale' && ' ✓'}
          </button>
          {selPaths.length > 0 && (
            <button onClick={bulkDeleteSelected}
              style={{ display: 'inline-flex', alignItems: 'center', gap: 5,
                padding: '4px 11px', borderRadius: 999, fontSize: 11, fontWeight: 700,
                background: A.coral, color: A.paper, border: 'none',
                cursor: 'pointer', fontFamily: 'inherit' }}>
              Free {fmtBytes(selSize)} →
            </button>
          )}
        </div>
        <div style={{ flex: 1, overflow: 'auto' }}>
          {filteredGroups.map((g, i) => {
            const isOpen = state.expandedGroup === g.name;
            return (
              <div key={g.name} style={{
                borderBottom: '1px solid ' + A.line,
                background: isOpen ? A.coralSoft + '55' : 'transparent',
              }}>
                <button onClick={() => toggleGroup(g.name)}
                  style={{ display: 'grid', width: '100%',
                  gridTemplateColumns: '24px 24px 1.4fr 1fr 1fr 100px 100px',
                  alignItems: 'center', gap: 10, padding: '10px 16px',
                  background: 'transparent', border: 'none',
                  cursor: 'pointer', textAlign: 'left', fontFamily: 'inherit' }}>
                  <input type="checkbox"
                    checked={g.instances && g.instances.every(
                      (it) => state.groupsSelected[it.path])}
                    onClick={(e) => e.stopPropagation()}
                    onChange={(e) => {
                      const next = { ...state.groupsSelected };
                      if (g.instances) g.instances.forEach((it) => {
                        next[it.path] = e.target.checked;
                      });
                      set({ groupsSelected: next });
                    }} />
                  <Icon name={isOpen ? 'chevdown' : 'chevron'} size={14} stroke={2}
                    style={{ color: A.ink2 }} />
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      <span style={{ fontFamily: '"Geist Mono", monospace',
                        fontWeight: 600, fontSize: 13 }}>{g.name}</span>
                      {g.devOnly && <Pill color={A.lilac} soft={A.lilacSoft}>dev</Pill>}
                    </div>
                    <div style={{ fontSize: 11, color: A.ink2, marginTop: 2 }}>
                      {g.tagline}
                    </div>
                  </div>
                  <div style={{ fontSize: 12, color: A.ink2 }}>
                    {g.count} folders
                  </div>
                  <div style={{ fontSize: 12, color: A.ink2 }}>
                    avg age {fmtAge(g.avgAge)}
                  </div>
                  <div style={{ width: 80 }}>
                    <Bar pct={(g.total / 42e9) * 100}
                      color={i === 0 ? A.coral : (i % 2 ? A.honey : A.sage)} height={5} />
                  </div>
                  <div style={{ fontFamily: '"Bricolage Grotesque", sans-serif',
                    fontWeight: 700, fontSize: 18, textAlign: 'right',
                    fontVariantNumeric: 'tabular-nums' }}>
                    {fmtBytes(g.total)}
                  </div>
                </button>
                {isOpen && g.instances && (
                  <div style={{ padding: '0 16px 12px 64px' }}>
                    {g.instances.map((it) => {
                      const stale = it.mod > 180;
                      const sel = !!state.groupsSelected[it.path];
                      return (
                        <label key={it.path} style={{ display: 'grid',
                          gridTemplateColumns: '24px 1.5fr 100px 90px 100px',
                          alignItems: 'center', gap: 10, padding: '7px 8px',
                          borderRadius: 8, cursor: 'pointer' }}>
                          <input type="checkbox" checked={sel}
                            onChange={(e) => set({ groupsSelected: {
                              ...state.groupsSelected,
                              [it.path]: e.target.checked } })} />
                          <div style={{ fontFamily: '"Geist Mono", monospace',
                            fontSize: 11, color: A.ink2,
                            whiteSpace: 'nowrap', overflow: 'hidden',
                            textOverflow: 'ellipsis' }}>{it.path}</div>
                          <div style={{ fontSize: 11,
                            color: stale ? A.red : A.ink2,
                            fontWeight: stale ? 600 : 400 }}>
                            {fmtAge(it.mod)}{stale && ' · stale'}
                          </div>
                          <Bar pct={(it.size / 8.4e9) * 100}
                            color={stale ? A.red : A.coral} height={4} />
                          <div style={{ fontSize: 12, fontWeight: 600,
                            textAlign: 'right',
                            fontVariantNumeric: 'tabular-nums' }}>
                            {fmtBytes(it.size)}
                          </div>
                        </label>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
};

// ───────────────────────────────────────────────────────────────────────
// Delete modal
// ───────────────────────────────────────────────────────────────────────
const DeleteModal = () => {
  const { state, set } = useApp();
  if (!state.deleteOpen) return null;
  const targets = state.deleteTargets;
  const total = targets.reduce((s, t) => s + t.size, 0);
  const protectedTargets = targets.filter((t) => t.protected);
  const okTargets = targets.filter((t) => !t.protected);
  const okTotal = okTargets.reduce((s, t) => s + t.size, 0);
  const okCount = okTargets.length;

  const confirm = () => {
    // Snapshot for undo
    const undoState = {
      drillItems: state.drillItems,
      groupsData: state.groupsData,
      groupsSelected: state.groupsSelected,
      freedBytes: state.freedBytes,
    };
    // Remove from drillItems
    const newDrillItems = state.drillItems.filter((di) => {
      const path = state.drillCrumb.join('/') + '/' + di.name;
      return !okTargets.some((t) => t.path === path);
    });
    // Remove from group instances
    const newGroups = state.groupsData.map((g) => {
      if (!g.instances) return g;
      const remaining = g.instances.filter((it) => !okTargets.some((t) => t.path === it.path));
      const removedSize = g.instances.filter((it) => okTargets.some((t) => t.path === it.path))
        .reduce((s, it) => s + it.size, 0);
      return {
        ...g,
        instances: remaining,
        total: Math.max(0, g.total - removedSize),
        count: Math.max(0, g.count - (g.instances.length - remaining.length)),
      };
    });
    // Clear those selections
    const newSelected = { ...state.groupsSelected };
    const newDrillSel = { ...state.drillSelected };
    okTargets.forEach((t) => {
      delete newSelected[t.path];
    });
    state.drillItems.forEach((di) => {
      const path = state.drillCrumb.join('/') + '/' + di.name;
      if (okTargets.some((t) => t.path === path)) delete newDrillSel[di.name];
    });

    set({
      deleteOpen: false,
      drillItems: newDrillItems,
      groupsData: newGroups,
      groupsSelected: newSelected,
      drillSelected: newDrillSel,
      freedBytes: state.freedBytes + okTotal,
      toast: {
        message: `Freed ${fmtBytes(okTotal)} — ${okCount} item${okCount === 1 ? '' : 's'} ${state.deleteKind === 'trash' ? 'moved to Trash' : 'deleted'}.`,
        action: state.deleteKind === 'trash' ? {
          label: 'Undo', run: () => set(undoState),
        } : null,
        duration: 8000,
      },
    });
  };

  return (
    <div style={{ position: 'absolute', inset: 0,
      background: 'rgba(42,33,24,0.36)', backdropFilter: 'blur(2px)',
      display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20,
      zIndex: 40, animation: 'aFadeIn .2s ease' }}>
      <style>{`@keyframes aFadeIn{from{opacity:0}to{opacity:1}}
        @keyframes aPopIn{from{transform:scale(.96);opacity:0}to{transform:scale(1);opacity:1}}`}</style>
      <div style={{
        width: 580, background: A.paper, borderRadius: 20,
        boxShadow: '0 30px 80px rgba(42,33,24,.25), 0 0 0 1px ' + A.line2,
        overflow: 'hidden', animation: 'aPopIn .22s cubic-bezier(.2,.7,.3,1.1)',
      }}>
        <div style={{ padding: '24px 26px 16px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ width: 44, height: 44, borderRadius: 12,
              background: A.coralSoft, color: A.coral,
              display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Icon name="trash" size={20} stroke={2} />
            </div>
            <div style={{ flex: 1 }}>
              <h3 style={{ fontFamily: '"Bricolage Grotesque", sans-serif',
                fontWeight: 800, fontSize: 22, letterSpacing: -0.4, margin: 0 }}>
                Delete {targets.length} item{targets.length === 1 ? '' : 's'}?
              </h3>
              <div style={{ fontSize: 13, color: A.ink2, marginTop: 2 }}>
                Frees about <b style={{ color: A.ink }}>{fmtBytes(okTotal)}</b>.
                {protectedTargets.length > 0 &&
                  <span> {protectedTargets.length} protected item{protectedTargets.length === 1 ? '' : 's'} will be skipped.</span>}
              </div>
            </div>
          </div>

          {protectedTargets.length > 0 && (
            <div style={{ marginTop: 18, padding: '12px 14px', borderRadius: 12,
              background: A.redSoft, border: '1px solid #EBC5BC',
              display: 'flex', gap: 10, alignItems: 'flex-start' }}>
              <Icon name="shield" size={18} stroke={2}
                style={{ color: A.red, marginTop: 1 }} />
              <div style={{ fontSize: 12.5, color: '#7A2618', lineHeight: 1.5 }}>
                <b>System protected paths excluded.</b>{' '}
                <span style={{ color: '#A1422E' }}>
                  These are part of macOS and could break apps or boot — we&rsquo;ll skip them.
                </span>
              </div>
            </div>
          )}
        </div>

        <div style={{ background: A.panel, borderTop: '1px solid ' + A.line,
          borderBottom: '1px solid ' + A.line, maxHeight: 220, overflow: 'auto' }}>
          {targets.map((t) => (
            <div key={t.path} style={{ display: 'grid',
              gridTemplateColumns: '18px 1fr 90px 80px', alignItems: 'center',
              gap: 10, padding: '10px 26px',
              borderBottom: '1px solid ' + A.line,
              opacity: t.protected ? 0.55 : 1,
              background: t.protected ? A.redSoft + '55' : 'transparent' }}>
              {t.protected
                ? <Icon name="shield" size={14} stroke={2} style={{ color: A.red }} />
                : <Icon name="trash" size={13} stroke={2} style={{ color: A.ink2 }} />}
              <div style={{ minWidth: 0 }}>
                <div style={{ fontFamily: '"Geist Mono", monospace', fontSize: 11.5,
                  color: A.ink, whiteSpace: 'nowrap', overflow: 'hidden',
                  textOverflow: 'ellipsis' }}>{t.path}</div>
                {t.protected && (
                  <div style={{ fontSize: 10.5, color: A.red, marginTop: 2 }}>
                    Skipped — system protected
                  </div>
                )}
              </div>
              <div style={{ fontSize: 11, color: A.ink2 }}>
                {fmtAge(t.mod)}
              </div>
              <div style={{ fontFamily: '"Bricolage Grotesque", sans-serif',
                fontWeight: 700, fontSize: 14, textAlign: 'right',
                textDecoration: t.protected ? 'line-through' : 'none' }}>
                {fmtBytes(t.size)}
              </div>
            </div>
          ))}
        </div>

        <div style={{ padding: '14px 26px 20px' }}>
          <div style={{ display: 'flex', gap: 8, marginBottom: 14 }}>
            {[
              { id: 'trash', label: 'Move to Trash', sub: 'recoverable' },
              { id: 'forever', label: 'Delete forever', sub: 'no undo' },
            ].map((o) => {
              const on = state.deleteKind === o.id;
              return (
                <button key={o.id}
                  onClick={() => set({ deleteKind: o.id })}
                  style={{
                    flex: 1, padding: '10px 12px', borderRadius: 12,
                    border: '1.5px solid ' + (on ? A.coral : A.line),
                    background: on ? A.coralSoft + '55' : A.paper,
                    display: 'flex', alignItems: 'center', gap: 10,
                    cursor: 'pointer', fontFamily: 'inherit', textAlign: 'left',
                  }}>
                  <div style={{ width: 16, height: 16, borderRadius: '50%',
                    border: '2px solid ' + (on ? A.coral : A.line2),
                    display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    {on && <div style={{ width: 8, height: 8, borderRadius: '50%',
                      background: A.coral }} />}
                  </div>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 600 }}>{o.label}</div>
                    <div style={{ fontSize: 11, color: A.ink2 }}>{o.sub}</div>
                  </div>
                </button>
              );
            })}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: 6,
              fontSize: 12, color: A.ink2, cursor: 'pointer' }}>
              <input type="checkbox" checked={state.deleteSnapshot}
                onChange={(e) => set({ deleteSnapshot: e.target.checked })} />
              Take snapshot first (undo for 30 days)
            </label>
            <div style={{ flex: 1 }} />
            <button
              onClick={() => set({ deleteOpen: false })}
              style={{ background: 'transparent', border: 'none',
                color: A.ink2, fontSize: 13, fontWeight: 600,
                padding: '10px 14px', cursor: 'pointer' }}>Cancel</button>
            <button onClick={confirm}
              disabled={okCount === 0}
              style={{ background: okCount ? A.coral : A.line,
                color: A.paper, border: 'none',
                borderRadius: 10, padding: '11px 18px', fontSize: 13, fontWeight: 700,
                boxShadow: okCount ? '0 3px 0 #B33E1F' : 'none',
                cursor: okCount ? 'pointer' : 'not-allowed' }}>
              {state.deleteKind === 'trash' ? 'Move' : 'Delete'} {okCount}
              {okCount > 0 && ' · free ' + fmtBytes(okTotal)}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// ───────────────────────────────────────────────────────────────────────
// Settings
// ───────────────────────────────────────────────────────────────────────
const Toggle = ({ on, onChange, color = A.coral }) => (
  <button onClick={() => onChange && onChange(!on)}
    style={{ width: 36, height: 20, borderRadius: 999,
      background: on ? color : A.line2, padding: 2,
      border: 'none', cursor: 'pointer',
      transition: 'background .15s' }}>
    <div style={{ width: 16, height: 16, borderRadius: '50%', background: A.paper,
      transform: on ? 'translateX(16px)' : 'translateX(0)',
      transition: 'transform .15s',
      boxShadow: '0 1px 2px rgba(0,0,0,.2)' }} />
  </button>
);

const PSettings = () => {
  const { state, set } = useApp();
  const setToggle = (key, val) => set({ toggles: { ...state.toggles, [key]: val } });

  return (
    <div style={{ padding: '0 20px 20px', height: '100%',
      display: 'grid', gridTemplateColumns: '210px 1fr', gap: 14 }}>
      <Card pad={10}>
        <div style={{ fontSize: 10, fontWeight: 700, color: A.ink3,
          letterSpacing: 0.6, textTransform: 'uppercase',
          padding: '4px 8px 8px' }}>
          Settings
        </div>
        {[
          ['scans',     'Scans',     'cog'    ],
          ['detection', 'Detection', 'sparkle'],
          ['safety',    'Safety',    'shield' ],
          ['snapshots', 'Snapshots', 'clock'  ],
          ['export',    'Export',    'download'],
          ['about',     'About',     'other'  ],
        ].map(([id, n, icon]) => {
          const sel = state.settingsActive === id;
          return (
            <button key={id}
              onClick={() => set({ settingsActive: id })}
              style={{
                display: 'flex', alignItems: 'center', gap: 9,
                padding: '8px 10px', borderRadius: 8, fontSize: 13,
                fontWeight: sel ? 600 : 500,
                color: sel ? A.coral : A.ink,
                background: sel ? A.coralSoft : 'transparent',
                marginBottom: 2, border: 'none', cursor: 'pointer',
                width: '100%', textAlign: 'left', fontFamily: 'inherit',
              }}>
              <Icon name={icon} size={15} stroke={1.8} />
              {n}
            </button>
          );
        })}
      </Card>

      <Card pad={24} style={{ overflow: 'auto' }}>
        {state.settingsActive === 'safety' && <SafetyPanel />}
        {state.settingsActive === 'scans' && <ScansPanel />}
        {state.settingsActive !== 'safety' && state.settingsActive !== 'scans' && (
          <EmptyPanel name={state.settingsActive} />
        )}
      </Card>
    </div>
  );
};

const SafetyPanel = () => {
  const { state, set } = useApp();
  const setToggle = (key, val) => set({ toggles: { ...state.toggles, [key]: val } });
  return (
    <>
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14,
        paddingBottom: 18, borderBottom: '1px solid ' + A.line, marginBottom: 18 }}>
        <div style={{ width: 44, height: 44, borderRadius: 12,
          background: A.coralSoft, color: A.coral,
          display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Icon name="shield" size={22} stroke={2} />
        </div>
        <div>
          <h2 style={{ fontFamily: '"Bricolage Grotesque", sans-serif',
            fontWeight: 800, fontSize: 24, letterSpacing: -0.5, margin: 0 }}>
            Safety
          </h2>
          <div style={{ fontSize: 13, color: A.ink2, marginTop: 4 }}>
            What Crumb refuses to delete &mdash; even if you tell it to.
          </div>
        </div>
      </div>

      {[
        ['protectSystem','Protect system paths',     'Always skip /System, /usr, /private, and Windows / Linux equivalents.'],
        ['protectActive','Protect active projects',  'Skip folders modified in the last 7 days unless explicitly chosen.'],
        ['confirmLarge', 'Confirm large deletes',    'Show this dialog for any cleanup over 1 GB.'],
        ['snapshots',    'Always snapshot first',    'Keeps a 30-day rollback. Uses ~1% of freed space.'],
        ['allowHidden',  'Allow deleting hidden',    'Show and allow removal of dot-folders like .Trash, .config.'],
      ].map(([key, n, desc], i, all) => (
        <div key={key} style={{ display: 'flex', alignItems: 'flex-start',
          gap: 14, padding: '14px 0',
          borderBottom: i < all.length - 1 ? '1px solid ' + A.line : 'none' }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 14, fontWeight: 600 }}>{n}</div>
            <div style={{ fontSize: 12, color: A.ink2, marginTop: 2 }}>{desc}</div>
          </div>
          <Toggle on={state.toggles[key]} onChange={(v) => setToggle(key, v)} />
        </div>
      ))}

      <div style={{ marginTop: 22 }}>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 10 }}>
          <div style={{ fontSize: 14, fontWeight: 700 }}>Protected paths</div>
          <div style={{ flex: 1 }} />
          <button
            onClick={() => {
              const p = window.prompt('Enter a path to protect:', '~/');
              if (p && p.trim()) {
                set({ protectedPaths: [...state.protectedPaths,
                  { p: p.trim(), sys: false }] });
              }
            }}
            style={{ background: A.panel, border: '1px solid ' + A.line,
              borderRadius: 8, padding: '6px 11px', fontSize: 12, fontWeight: 600,
              color: A.ink, display: 'flex', alignItems: 'center', gap: 5,
              cursor: 'pointer' }}>
            <Icon name="plus" size={12} stroke={2.5} />Add path
          </button>
        </div>
        <div style={{ background: A.panel, border: '1px solid ' + A.line,
          borderRadius: 12, overflow: 'hidden' }}>
          {state.protectedPaths.map((r, i, all) => (
            <div key={r.p + i} style={{ display: 'flex', alignItems: 'center',
              gap: 10, padding: '10px 14px',
              borderBottom: i < all.length - 1 ? '1px solid ' + A.line : 'none' }}>
              <Icon name="shield" size={14} stroke={2}
                style={{ color: r.sys ? A.red : A.ink2 }} />
              <span style={{ fontFamily: '"Geist Mono", monospace',
                fontSize: 12 }}>{r.p}</span>
              {r.sys && <Pill color={A.red} soft={A.redSoft}>system</Pill>}
              <div style={{ flex: 1 }} />
              {!r.sys && (
                <button
                  onClick={() => set({ protectedPaths: state.protectedPaths
                    .filter((_, j) => j !== i) })}
                  style={{ background: 'transparent', border: 'none',
                    color: A.ink2, padding: 4, cursor: 'pointer' }}>
                  <Icon name="x" size={13} stroke={2} />
                </button>
              )}
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

const ScansPanel = () => {
  const { state, set } = useApp();
  return (
    <>
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14,
        paddingBottom: 18, borderBottom: '1px solid ' + A.line, marginBottom: 18 }}>
        <div style={{ width: 44, height: 44, borderRadius: 12,
          background: A.honeySoft, color: A.coral,
          display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Icon name="clock" size={22} stroke={2} />
        </div>
        <div>
          <h2 style={{ fontFamily: '"Bricolage Grotesque", sans-serif',
            fontWeight: 800, fontSize: 24, letterSpacing: -0.5, margin: 0 }}>
            Scans
          </h2>
          <div style={{ fontSize: 13, color: A.ink2, marginTop: 4 }}>
            When and how Crumb sweeps your drives.
          </div>
        </div>
      </div>
      <div style={{ padding: 14, background: A.honeySoft, borderRadius: 12,
        display: 'flex', alignItems: 'center', gap: 12 }}>
        <Icon name="clock" size={20} stroke={2} style={{ color: A.coral }} />
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 13, fontWeight: 600 }}>
            Scheduled scan: every Sunday, 8:00am
          </div>
          <div style={{ fontSize: 11.5, color: A.ink2, marginTop: 1 }}>
            Next: Sun, May 31 &mdash; only runs when plugged in.
          </div>
        </div>
        <Toggle on={true} />
      </div>
    </>
  );
};

const EmptyPanel = ({ name }) => (
  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center',
    justifyContent: 'center', height: '100%', color: A.ink3, gap: 8 }}>
    <Icon name="cog" size={40} stroke={1.5} />
    <div style={{ fontFamily: '"Bricolage Grotesque", sans-serif',
      fontSize: 18, fontWeight: 700, color: A.ink2 }}>
      {name.charAt(0).toUpperCase() + name.slice(1)} settings
    </div>
    <div style={{ fontSize: 12, textAlign: 'center', maxWidth: 280 }}>
      This panel would let you configure {name}-related behavior.
      Wired in this prototype: Scans and Safety.
    </div>
  </div>
);

Object.assign(window, { PGroups, DeleteModal, PSettings });
