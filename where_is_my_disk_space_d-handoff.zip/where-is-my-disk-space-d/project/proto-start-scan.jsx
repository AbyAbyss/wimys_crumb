// proto-start-scan.jsx — Start + Scanning screens.


// ───────────────────────────────────────────────────────────────────────
// Start
// ───────────────────────────────────────────────────────────────────────
const PStart = () => {
  const { state, nav, set } = useApp();
  return (
    <div style={{ padding: '0 20px 20px', display: 'grid',
      gridTemplateColumns: '1.4fr 1fr', gap: 16, height: '100%' }}>
      {/* Hero */}
      <Card pad={32} style={{
        background: `linear-gradient(135deg, ${A.honeySoft} 0%, ${A.coralSoft} 100%)`,
        border: '1px solid ' + A.line2, display: 'flex', flexDirection: 'column',
        justifyContent: 'space-between', position: 'relative', overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute', inset: 0, opacity: 0.18,
          backgroundImage: `radial-gradient(${A.ink} 0.8px, transparent 1px)`,
          backgroundSize: '12px 12px',
        }} />
        <div style={{ position: 'relative' }}>
          <Pill color={A.coral} soft={A.paper}>● Ready to scan</Pill>
          <h1 style={{
            fontFamily: '"Bricolage Grotesque", sans-serif', fontWeight: 800,
            fontSize: 56, lineHeight: 1.02, letterSpacing: -1.5, margin: '18px 0 12px',
            color: A.ink, maxWidth: 480,
          }}>
            Where did<br/>your space go?
          </h1>
          <p style={{ fontSize: 15, color: A.ink2, margin: 0, maxWidth: 440, lineHeight: 1.5 }}>
            We&rsquo;ll sweep your drive, group what&rsquo;s eating space, and tell you what&rsquo;s
            safe to delete. Takes about 90 seconds.
          </p>
        </div>
        <div style={{ position: 'relative', display: 'flex', gap: 12, alignItems: 'center' }}>
          <button onClick={() => nav.goto('scanning', { driveId: 'mac' })}
            style={{
              background: A.ink, color: A.paper, border: 'none', borderRadius: 12,
              padding: '14px 22px', fontSize: 15, fontWeight: 600, cursor: 'pointer',
              display: 'flex', alignItems: 'center', gap: 10,
              boxShadow: '0 4px 0 ' + A.ink + ', 0 6px 18px rgba(42,33,24,.25)',
              transition: 'transform .08s',
            }}
            onMouseDown={(e) => e.currentTarget.style.transform = 'translateY(2px)'}
            onMouseUp={(e) => e.currentTarget.style.transform = ''}
            onMouseLeave={(e) => e.currentTarget.style.transform = ''}>
            <Icon name="search" size={17} stroke={2.2} />
            Scan Macintosh HD
          </button>
          <button onClick={() => set({ toast: { message: 'Folder picker would open here.' } })}
            style={{
              background: 'transparent', color: A.ink, border: 'none',
              padding: '14px 8px', fontSize: 14, fontWeight: 500, cursor: 'pointer',
              textDecoration: 'underline', textUnderlineOffset: 4,
            }}>
            Pick a specific folder…
          </button>
        </div>
      </Card>

      {/* Drives */}
      <Card pad={20}>
        <div style={{ display: 'flex', alignItems: 'center',
          justifyContent: 'space-between', marginBottom: 14 }}>
          <div style={{ fontWeight: 700, fontSize: 14, letterSpacing: 0.2,
            color: A.ink, textTransform: 'uppercase' }}>Drives</div>
          <Icon name="refresh" size={15} stroke={1.8} style={{ color: A.ink2 }} />
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {DRIVES.map((d, i) => {
            const pct = Math.round((d.used / d.total) * 100);
            const colors = [A.coral, A.honey, A.sage];
            const isFull = pct > 85;
            return (
              <div key={d.id} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <Donut pct={pct} size={56} stroke={7}
                  color={isFull ? A.red : colors[i]} track={A.line}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: A.ink }}>{pct}%</div>
                </Donut>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <div style={{ fontWeight: 600, fontSize: 14 }}>{d.name}</div>
                    {isFull && <Pill color={A.red} soft={A.redSoft}>almost full</Pill>}
                  </div>
                  <div style={{ fontSize: 12, color: A.ink2, marginTop: 2 }}>
                    {fmtBytes(d.used)} used of {fmtBytes(d.total)} · {d.kind}
                  </div>
                </div>
                <button onClick={() => nav.goto('scanning', { driveId: d.id })}
                  style={{ background: A.panel, color: A.ink, border: 'none',
                    borderRadius: 8, padding: '7px 11px', fontSize: 12, fontWeight: 600,
                    cursor: 'pointer' }}>
                  Scan
                </button>
              </div>
            );
          })}
        </div>
        <div style={{ borderTop: '1px solid ' + A.line, marginTop: 16, paddingTop: 14 }}>
          <div style={{ fontWeight: 700, fontSize: 13, color: A.ink, marginBottom: 8 }}>
            Last scans
          </div>
          {[
            ['Macintosh HD', '2 days ago', '608 GB used'],
            ['Time Machine', '1 week ago', '2.8 TB used'],
          ].map((r) => (
            <button key={r[0]} onClick={() => nav.goto('overview')}
              style={{ display: 'flex', justifyContent: 'space-between', width: '100%',
                padding: '7px 0', fontSize: 12, color: A.ink2,
                background: 'transparent', border: 'none', cursor: 'pointer',
                textAlign: 'left', fontFamily: 'inherit' }}>
              <span style={{ color: A.ink }}>{r[0]}</span>
              <span>{r[1]} · {r[2]}</span>
            </button>
          ))}
        </div>
      </Card>
    </div>
  );
};

// ───────────────────────────────────────────────────────────────────────
// Scanning — animates progress, auto-completes
// ───────────────────────────────────────────────────────────────────────
const PScanning = () => {
  const { state, nav, set } = useApp();
  const pct = state.scanProgress;
  const drive = DRIVES.find((d) => d.id === state.scanDriveId) || DRIVES[0];

  // Animate progress + cycle current path.
  React.useEffect(() => {
    if (!state.scanning || state.scanPaused) return;
    const id = setInterval(() => {
      set((s) => {
        if (!s.scanning || s.scanPaused) return {};
        const next = s.scanProgress + 1.2;
        if (next >= 100) {
          return {
            scanProgress: 100, scanning: false,
            screen: 'overview', tab: 'overview',
            toast: { message: 'Scan complete — 612 GB used, 57 GB you could free.' },
          };
        }
        const pathIdx = Math.floor((next / 100) * SCAN_PATHS.length) % SCAN_PATHS.length;
        return { scanProgress: next, scanCurrent: SCAN_PATHS[pathIdx] };
      });
    }, 80);
    return () => clearInterval(id);
  }, [state.scanning, state.scanPaused]);

  return (
    <div style={{ padding: '0 20px 20px', display: 'grid',
      gridTemplateColumns: '1.2fr 1fr', gap: 16, height: '100%' }}>
      {/* Progress hero */}
      <Card pad={28}>
        <Pill color={A.coral} soft={A.coralSoft}>
          <span style={{ width: 6, height: 6, borderRadius: '50%',
            background: A.coral, display: 'inline-block',
            animation: state.scanPaused ? 'none' : 'aPulse 1s infinite' }} />
          {state.scanPaused ? 'Paused' : 'Scanning'}
        </Pill>
        <style>{`@keyframes aPulse{0%,100%{opacity:1}50%{opacity:.35}}`}</style>
        <h2 style={{ fontFamily: '"Bricolage Grotesque", sans-serif', fontWeight: 800,
          fontSize: 32, letterSpacing: -0.8, margin: '12px 0 4px', color: A.ink }}>
          Sweeping {drive.name}
        </h2>
        <div style={{ fontSize: 13, color: A.ink2 }}>
          We&rsquo;ll group similar things and show you the big stuff.
        </div>

        <div style={{ display: 'flex', alignItems: 'baseline', gap: 14,
          margin: '28px 0 18px' }}>
          <div style={{ fontFamily: '"Bricolage Grotesque", sans-serif',
            fontSize: 84, fontWeight: 800, letterSpacing: -3, lineHeight: 1,
            color: A.ink, fontVariantNumeric: 'tabular-nums' }}>
            {Math.floor(pct)}<span style={{ fontSize: 36, color: A.coral }}>%</span>
          </div>
          <div style={{ flex: 1 }}>
            <Bar pct={pct} color={A.coral} height={10} />
            <div style={{ display: 'flex', justifyContent: 'space-between',
              marginTop: 10, fontSize: 12, color: A.ink2 }}>
              <span>{Math.floor(643210 * pct / 100).toLocaleString()} / 643,210 files</span>
              <span>~{Math.max(1, Math.ceil((100 - pct) * 0.6))}s left</span>
            </div>
          </div>
        </div>

        <div style={{ background: A.panel, border: '1px solid ' + A.line,
          borderRadius: 12, padding: '12px 14px',
          fontFamily: '"Geist Mono", ui-monospace, monospace',
          fontSize: 12, color: A.ink2 }}>
          <div style={{ color: A.ink3, fontSize: 11, marginBottom: 4,
            fontFamily: '"Geist", sans-serif' }}>
            currently scanning
          </div>
          {state.scanCurrent}
        </div>

        <div style={{ display: 'flex', gap: 8, marginTop: 18 }}>
          <button onClick={() => set({ scanPaused: !state.scanPaused })}
            style={{ background: A.paper, border: '1px solid ' + A.line2,
              borderRadius: 10, padding: '9px 14px', fontSize: 13, fontWeight: 600,
              color: A.ink, cursor: 'pointer', display: 'flex',
              alignItems: 'center', gap: 6 }}>
            <Icon name={state.scanPaused ? 'play' : 'pause'} size={14}
              fill="currentColor" stroke={0} />
            {state.scanPaused ? 'Resume' : 'Pause'}
          </button>
          <button onClick={() => nav.goto('start')}
            style={{ background: 'transparent', border: '1px solid ' + A.line2,
              borderRadius: 10, padding: '9px 14px', fontSize: 13, fontWeight: 600,
              color: A.ink2, cursor: 'pointer' }}>Cancel</button>
          <button onClick={() => set({ scanProgress: 100, scanning: false,
            screen: 'overview', toast: { message: 'Skipped — showing results.' } })}
            style={{ background: 'transparent', border: 'none',
              padding: '9px 14px', fontSize: 12, fontWeight: 500, color: A.ink3,
              cursor: 'pointer', marginLeft: 'auto' }}>Skip animation →</button>
        </div>
      </Card>

      {/* Live preview list */}
      <Card pad={20}>
        <div style={{ display: 'flex', alignItems: 'center',
          justifyContent: 'space-between', marginBottom: 12 }}>
          <div style={{ fontWeight: 700, fontSize: 14, letterSpacing: 0.2,
            textTransform: 'uppercase', color: A.ink }}>Biggest so far</div>
          <Pill color={A.honey} soft={A.honeySoft}>live</Pill>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {HOME_FOLDERS.slice(0, Math.max(1, Math.ceil(pct / 16))).map((f, i) => (
            <div key={f.name} style={{ animation: 'aSlideIn .3s ease' }}>
              <style>{`@keyframes aSlideIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}`}</style>
              <div style={{ display: 'flex', justifyContent: 'space-between',
                alignItems: 'center', marginBottom: 5 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
                  <Icon name="folder" size={14} fill={A_HUES[i % A_HUES.length]}
                    stroke={0} style={{ color: A_HUES[i % A_HUES.length] }} />
                  <span style={{ fontSize: 13, fontWeight: 500 }}>{f.name}</span>
                </div>
                <span style={{ fontSize: 12, color: A.ink2,
                  fontVariantNumeric: 'tabular-nums' }}>
                  {fmtBytes(f.size)}
                </span>
              </div>
              <Bar pct={(f.size / 142e9) * 100} color={A_HUES[i % A_HUES.length]} height={5} />
            </div>
          ))}
        </div>
        <div style={{ borderTop: '1px dashed ' + A.line2, marginTop: 14,
          paddingTop: 12, fontSize: 12, color: A.ink3, lineHeight: 1.5 }}>
          <Icon name="sparkle" size={14} stroke={1.8} style={{ verticalAlign: -2,
            color: A.honey, marginRight: 6 }} />
          {pct < 40 ? 'Looking for stale node_modules…' :
            <>Spotted <b style={{ color: A.ink }}>14 stale node_modules</b> —
              about 24 GB you could free.</>}
        </div>
      </Card>
    </div>
  );
};

Object.assign(window, { PStart, PScanning });
