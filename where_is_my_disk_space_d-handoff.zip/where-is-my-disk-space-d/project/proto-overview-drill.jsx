// proto-overview-drill.jsx — Overview (dashboard) + Drill-down screens.


// Compact interactive treemap.
const ITreemap = ({ items, height, onClick, colors = A_HUES }) => {
  const total = items.reduce((s, it) => s + it.size, 0);
  const top = items.slice(0, 3);
  const bot = items.slice(3);
  const topSum = top.reduce((s, it) => s + it.size, 0) || 1;
  const botSum = bot.reduce((s, it) => s + it.size, 0) || 1;
  const topH = Math.round(height * (topSum / total));
  const botH = height - topH;

  const Tile = ({ it, i, big }) => (
    <button
      key={it.name}
      onClick={() => onClick && onClick(it)}
      style={{
        flex: it.size, height: '100%',
        background: colors[(it.color ?? i) % colors.length],
        padding: big ? 14 : 10, color: A.paper, position: 'relative',
        display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
        fontWeight: 600, border: 'none', cursor: onClick ? 'pointer' : 'default',
        textAlign: 'left', fontFamily: 'inherit', opacity: big ? 1 : 0.92,
        transition: 'opacity .15s, transform .15s',
      }}
      onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(.985)'}
      onMouseLeave={(e) => e.currentTarget.style.transform = ''}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6,
        fontSize: big ? 13 : 12, opacity: 0.95 }}>
        {it.protected && <Icon name="shield" size={big ? 14 : 12} stroke={2} />}
        {it.name}
      </div>
      <div style={{ fontFamily: '"Bricolage Grotesque", sans-serif',
        fontSize: big ? 28 : 18, fontWeight: 700, letterSpacing: -0.6 }}>
        {fmtBytes(it.size)}
      </div>
    </button>
  );
  return (
    <div style={{ width: '100%', height, display: 'flex', flexDirection: 'column',
      borderRadius: 14, overflow: 'hidden', gap: 4, background: A.line }}>
      <div style={{ height: topH, display: 'flex', gap: 4 }}>
        {top.map((it, i) => <Tile key={it.name} it={it} i={i} big />)}
      </div>
      <div style={{ height: botH, display: 'flex', gap: 4 }}>
        {bot.map((it, i) => <Tile key={it.name} it={it} i={i + 3} />)}
      </div>
    </div>
  );
};

// ───────────────────────────────────────────────────────────────────────
// Overview
// ───────────────────────────────────────────────────────────────────────
const POverview = () => {
  const { state, nav, set } = useApp();
  // Live values
  const used = DISK.used - state.freedBytes;
  const free = DISK.total - used;

  const drillInto = (f) => {
    nav.goto('drill', { crumb: ['Macintosh HD', f.name],
      items: f.name === 'Users/lina' ? HOME_FOLDERS.slice() :
             (f.name === 'Applications' ? FAKE_APPS : [{ name: '(empty)', size: 0, mod: 0, items: 0 }]),
    });
  };

  return (
    <div style={{ padding: '0 20px 20px', display: 'flex', flexDirection: 'column',
      gap: 14, height: '100%' }}>
      {/* Stat row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
        {[
          { label: 'Used', value: fmtBytes(used), accent: A.coral,
            sub: Math.round((used / DISK.total) * 100) + '% of 1 TB',
            delta: '+4.2 GB this week' },
          { label: 'Free', value: fmtBytes(free), accent: A.sage,
            sub: Math.round((free / DISK.total) * 100) + '% available' },
          { label: 'Items scanned', value: '1.2M', accent: A.honey,
            sub: 'in 612K folders' },
          { label: state.freedBytes ? 'Freed so far' : 'Could free',
            value: state.freedBytes ? fmtBytes(state.freedBytes) : '57 GB',
            sub: state.freedBytes ? 'this session' : '5 quick wins',
            isCta: true, onClick: () => nav.gotoTab('groups') },
        ].map((s) => (
          <button key={s.label} onClick={s.onClick}
            disabled={!s.onClick}
            style={{
              background: s.isCta ? A.ink : A.paper,
              color: s.isCta ? A.paper : A.ink,
              border: '1px solid ' + (s.isCta ? A.ink : A.line),
              borderRadius: 16, padding: 14, textAlign: 'left',
              cursor: s.onClick ? 'pointer' : 'default',
              fontFamily: 'inherit', position: 'relative', overflow: 'hidden',
              transition: 'transform .1s',
            }}
            onMouseEnter={(e) => s.onClick && (e.currentTarget.style.transform = 'translateY(-1px)')}
            onMouseLeave={(e) => e.currentTarget.style.transform = ''}>
            <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 0.6,
              textTransform: 'uppercase', color: s.isCta ? A.honey : A.ink2 }}>
              {s.label}
            </div>
            <div style={{ fontFamily: '"Bricolage Grotesque", sans-serif',
              fontWeight: 800, fontSize: 32, letterSpacing: -0.8, marginTop: 4 }}>
              {s.value}
            </div>
            <div style={{ fontSize: 12, color: s.isCta ? '#D2C0A0' : A.ink2,
              marginTop: 2 }}>{s.sub}</div>
            {s.delta && (
              <Pill color={A.coral} soft={A.coralSoft}>
                <Icon name="arrowup" size={11} stroke={2.4} />{s.delta}
              </Pill>
            )}
          </button>
        ))}
      </div>

      {/* Main */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr',
        gap: 14, flex: 1, minHeight: 0 }}>
        <Card pad={18} style={{ display: 'flex', flexDirection: 'column' }}>
          <div style={{ display: 'flex', alignItems: 'center',
            justifyContent: 'space-between', marginBottom: 14 }}>
            <div>
              <div style={{ fontWeight: 700, fontSize: 15, color: A.ink }}>
                What&rsquo;s using your disk
              </div>
              <div style={{ fontSize: 12, color: A.ink2, marginTop: 2 }}>
                Click a tile to drill in.
              </div>
            </div>
          </div>
          <ITreemap items={TOP_FOLDERS} height={310} onClick={drillInto} />
          <div style={{ display: 'flex', gap: 10, marginTop: 14, flexWrap: 'wrap' }}>
            {TOP_FOLDERS.map((f, i) => (
              <div key={f.name} style={{ display: 'flex', alignItems: 'center',
                gap: 5, fontSize: 11, color: A.ink2 }}>
                <div style={{ width: 8, height: 8, borderRadius: 2,
                  background: A_HUES[(f.color ?? i) % A_HUES.length] }} />
                {f.name}
              </div>
            ))}
          </div>
        </Card>

        {/* Side: file types + suggestions */}
        <div style={{ display: 'grid', gridTemplateRows: '1fr 1fr', gap: 14,
          minHeight: 0 }}>
          <Card pad={16} style={{ overflow: 'auto' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between',
              alignItems: 'center', marginBottom: 10 }}>
              <div style={{ fontWeight: 700, fontSize: 14 }}>By file type</div>
              <span style={{ fontSize: 11, color: A.ink2 }}>
                {fmtBytes(used)} total
              </span>
            </div>
            {FILE_TYPES.slice(0, 6).map((t, i) => {
              const pct = (t.size / 168e9) * 100;
              return (
                <button key={t.name}
                  onClick={() => set({ toast: { message: `Filtering by ${t.name}…` } })}
                  style={{ display: 'flex', alignItems: 'center', gap: 10,
                    padding: '5px 0', width: '100%', background: 'transparent',
                    border: 'none', cursor: 'pointer', textAlign: 'left',
                    fontFamily: 'inherit' }}>
                  <div style={{ width: 22, height: 22, borderRadius: 6,
                    background: A_HUES[i % A_HUES.length] + '22',
                    color: A_HUES[i % A_HUES.length], display: 'flex',
                    alignItems: 'center', justifyContent: 'center' }}>
                    <Icon name={t.icon} size={13} stroke={2} />
                  </div>
                  <div style={{ flex: 1, fontSize: 12 }}>
                    <div style={{ display: 'flex',
                      justifyContent: 'space-between', marginBottom: 3 }}>
                      <span style={{ fontWeight: 500 }}>{t.name}</span>
                      <span style={{ color: A.ink2,
                        fontVariantNumeric: 'tabular-nums' }}>
                        {fmtBytes(t.size)}
                      </span>
                    </div>
                    <Bar pct={pct} color={A_HUES[i % A_HUES.length]} height={4} />
                  </div>
                </button>
              );
            })}
          </Card>

          <Card pad={16} style={{ background: A.honeySoft,
            border: '1px solid ' + A.line2, overflow: 'auto' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8,
              marginBottom: 10 }}>
              <Icon name="sparkle" size={16} stroke={2} style={{ color: A.coral }} />
              <div style={{ fontWeight: 700, fontSize: 14 }}>Quick wins</div>
              <div style={{ flex: 1 }} />
              <Pill color={A.coral} soft={A.paper}>save up to 57 GB</Pill>
            </div>
            {SUGGESTIONS.slice(0, 4).map((sg, i) => (
              <button key={sg.title}
                onClick={() => {
                  // Show delete modal with sample targets
                  const targets = DELETE_TARGETS.slice();
                  set({ deleteOpen: true, deleteTargets: targets });
                }}
                style={{
                  display: 'flex', alignItems: 'center', gap: 10,
                  background: A.paper, padding: '8px 10px', borderRadius: 8,
                  marginBottom: i < 3 ? 6 : 0, border: '1px solid ' + A.line,
                  width: '100%', cursor: 'pointer', fontFamily: 'inherit',
                  textAlign: 'left',
                }}>
                <div style={{ width: 6, height: 6, borderRadius: '50%',
                  background: sg.kind === 'safe' ? A.sage : A.honey }} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 12, fontWeight: 600,
                    whiteSpace: 'nowrap', textOverflow: 'ellipsis',
                    overflow: 'hidden' }}>{sg.title}</div>
                  <div style={{ fontSize: 11, color: A.ink2,
                    whiteSpace: 'nowrap', textOverflow: 'ellipsis',
                    overflow: 'hidden' }}>{sg.detail}</div>
                </div>
                <div style={{ fontFamily: '"Bricolage Grotesque", sans-serif',
                  fontWeight: 700, fontSize: 14, color: A.coral }}>
                  {fmtBytes(sg.save)}
                </div>
              </button>
            ))}
          </Card>
        </div>
      </div>
    </div>
  );
};

// ───────────────────────────────────────────────────────────────────────
// Drill-down
// ───────────────────────────────────────────────────────────────────────

// Sample placeholder Application items for when user drills into Applications
const FAKE_APPS = [
  { name: 'Xcode.app',       size: 18e9,  mod: 12,  items: 220, sub: 'developer · 18 GB' },
  { name: 'Photoshop 2024',  size: 6.2e9, mod: 80,  items: 412, sub: 'graphics · 6.2 GB' },
  { name: 'Final Cut Pro',   size: 5.4e9, mod: 200, items: 88,  sub: 'video · 5.4 GB' },
  { name: 'Slack.app',       size: 480e6, mod: 1,   items: 32,  sub: 'comms · 480 MB' },
  { name: 'Chrome.app',      size: 620e6, mod: 4,   items: 48,  sub: 'browser · 620 MB' },
];

const PDrill = () => {
  const { state, nav, set } = useApp();
  const items = state.drillItems || [];
  const selectedIds = Object.keys(state.drillSelected).filter((k) => state.drillSelected[k]);
  const selSize = items.filter((i) => state.drillSelected[i.name])
    .reduce((s, i) => s + i.size, 0);
  const maxSize = Math.max(1, ...items.map((i) => i.size));
  const [selDetail, setSelDetail] = React.useState(items[0]?.name);
  const detailItem = items.find((i) => i.name === selDetail) || items[0];

  return (
    <div style={{ padding: '0 20px 20px', height: '100%',
      display: 'flex', flexDirection: 'column' }}>
      {/* Breadcrumb */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 6,
        padding: '0 4px 12px', fontSize: 13, color: A.ink2 }}>
        <Icon name="drive" size={14} stroke={1.8} />
        {state.drillCrumb.map((c, i, all) => (
          <React.Fragment key={i}>
            <button
              onClick={() => {
                if (i === all.length - 1) return;
                // Go back to overview if clicking first crumb
                if (i === 0) nav.goto('overview');
              }}
              style={{
                background: 'transparent', border: 'none', cursor: 'pointer',
                fontFamily: 'inherit', fontSize: 13, padding: 0,
                color: i === all.length - 1 ? A.ink : A.ink2,
                fontWeight: i === all.length - 1 ? 600 : 400,
              }}>
              {c}
            </button>
            {i < all.length - 1 && <Icon name="chevron" size={12} stroke={2} />}
          </React.Fragment>
        ))}
        <div style={{ flex: 1 }} />
        <Pill color={A.honey} soft={A.honeySoft}>last scanned 2d ago</Pill>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 280px',
        gap: 14, flex: 1, minHeight: 0 }}>
        {/* Content list */}
        <Card pad={0} style={{ display: 'flex', flexDirection: 'column',
          overflow: 'hidden' }}>
          <div style={{ padding: '12px 16px', borderBottom: '1px solid ' + A.line,
            display: 'flex', alignItems: 'center', gap: 10 }}>
            <Icon name="folder" size={20} fill={A.honey} stroke={0}
              style={{ color: A.honey }} />
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 700, fontSize: 15 }}>
                {state.drillCrumb[state.drillCrumb.length - 1]}
              </div>
              <div style={{ fontSize: 11, color: A.ink2 }}>
                {items.length} folders · {fmtBytes(items.reduce((s, i) => s + i.size, 0))}
              </div>
            </div>
            <label style={{ display: 'flex', alignItems: 'center', gap: 6,
              fontSize: 11, color: A.ink2 }}>
              <input type="checkbox"
                checked={state.toggles.allowHidden}
                onChange={(e) => set({ toggles: { ...state.toggles,
                  allowHidden: e.target.checked } })} />
              Show hidden
            </label>
          </div>
          <div style={{ flex: 1, overflow: 'auto' }}>
            {items.filter((r) => state.toggles.allowHidden || !r.hidden)
              .map((r) => {
              const pct = (r.size / maxSize) * 100;
              const sel = !!state.drillSelected[r.name];
              const isDetail = detailItem?.name === r.name;
              const stale = r.mod > 180;
              return (
                <div key={r.name}
                  onClick={() => setSelDetail(r.name)}
                  style={{
                    display: 'grid',
                    gridTemplateColumns: '24px 1.2fr 1fr 80px 80px',
                    alignItems: 'center', gap: 12, padding: '11px 16px',
                    borderBottom: '1px solid ' + A.line,
                    background: isDetail ? A.coralSoft + '70' : 'transparent',
                    cursor: 'pointer',
                  }}>
                  <input type="checkbox" checked={sel}
                    onClick={(e) => e.stopPropagation()}
                    onChange={(e) => set({ drillSelected: {
                      ...state.drillSelected, [r.name]: e.target.checked } })} />
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8,
                    minWidth: 0 }}>
                    <Icon name={r.hidden ? 'hidden' : 'folder'} size={15}
                      fill={r.hidden ? 'none' : (stale ? A.red : A.honey)}
                      stroke={r.hidden ? 1.8 : 0}
                      style={{ color: r.hidden ? A.ink3 : (stale ? A.red : A.honey) }} />
                    <div style={{ minWidth: 0 }}>
                      <div style={{ fontWeight: 600, fontSize: 13 }}>{r.name}</div>
                      <div style={{ fontSize: 11, color: stale ? A.red : A.ink2,
                        whiteSpace: 'nowrap', overflow: 'hidden',
                        textOverflow: 'ellipsis' }}>
                        {r.sub || `${(r.items || 0).toLocaleString()} items`}
                        {stale && ' · stale'}
                      </div>
                    </div>
                  </div>
                  <Bar pct={pct} color={stale ? A.red : A.coral} height={5} />
                  <div style={{ fontSize: 12, color: A.ink2,
                    fontVariantNumeric: 'tabular-nums' }}>
                    {fmtAge(r.mod)}
                  </div>
                  <div style={{ fontFamily: '"Bricolage Grotesque", sans-serif',
                    fontWeight: 700, fontSize: 14, textAlign: 'right',
                    fontVariantNumeric: 'tabular-nums' }}>
                    {fmtBytes(r.size)}
                  </div>
                </div>
              );
            })}
          </div>
          <div style={{ padding: '10px 16px', borderTop: '1px solid ' + A.line,
            display: 'flex', alignItems: 'center', gap: 10, background: A.panel }}>
            <span style={{ fontSize: 12, color: A.ink2 }}>
              {selectedIds.length} selected · {fmtBytes(selSize)}
            </span>
            <div style={{ flex: 1 }} />
            <button
              disabled={selectedIds.length === 0}
              onClick={() => {
                const targets = items.filter((i) => state.drillSelected[i.name])
                  .map((i) => ({ path: state.drillCrumb.join('/') + '/' + i.name,
                    size: i.size, mod: i.mod, protected: i.protected }));
                if (targets.length) set({ deleteOpen: true, deleteTargets: targets });
              }}
              style={{ background: selectedIds.length ? A.coral : A.line,
                border: 'none', borderRadius: 8,
                padding: '6px 12px', fontSize: 12, fontWeight: 600,
                color: selectedIds.length ? A.paper : A.ink3,
                cursor: selectedIds.length ? 'pointer' : 'not-allowed',
                display: 'flex', alignItems: 'center', gap: 5 }}>
              <Icon name="trash" size={12} stroke={2.2} />Delete
            </button>
          </div>
        </Card>

        {/* Detail */}
        <Card pad={16} style={{ overflow: 'auto' }}>
          <div style={{ width: '100%', height: 72, borderRadius: 10,
            background: `linear-gradient(135deg, ${A.coral}, ${A.honey})`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: A.paper, marginBottom: 12 }}>
            <Icon name="folder" size={36} fill="currentColor" stroke={0} />
          </div>
          <div style={{ fontWeight: 700, fontSize: 15 }}>{detailItem?.name}</div>
          <div style={{ fontSize: 11, color: A.ink2, marginBottom: 14,
            wordBreak: 'break-all' }}>
            {state.drillCrumb.join('/')}/{detailItem?.name}
          </div>
          {[
            ['Size', fmtBytes(detailItem?.size || 0)],
            ['Items', (detailItem?.items || 0).toLocaleString()],
            ['Last modified', fmtAge(detailItem?.mod || 0)],
            ['Kind', detailItem?.hidden ? 'Hidden folder' : 'Folder'],
            ['Permissions', 'Read & write'],
          ].map((r) => (
            <div key={r[0]} style={{ display: 'flex',
              justifyContent: 'space-between', padding: '6px 0',
              borderTop: '1px solid ' + A.line, fontSize: 12 }}>
              <span style={{ color: A.ink2 }}>{r[0]}</span>
              <span style={{ fontWeight: 500 }}>{r[1]}</span>
            </div>
          ))}
          <div style={{ marginTop: 12, display: 'flex',
            flexDirection: 'column', gap: 6 }}>
            <button onClick={() => set({ toast: { message: 'Revealed in Finder.' } })}
              style={{ background: A.ink, color: A.paper, border: 'none',
                borderRadius: 8, padding: '9px 12px', fontSize: 12, fontWeight: 600,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                gap: 6, cursor: 'pointer' }}>
              <Icon name="search" size={12} stroke={2.2} />Reveal in Finder
            </button>
            <button
              onClick={() => set({ deleteOpen: true,
                deleteTargets: [{
                  path: state.drillCrumb.join('/') + '/' + (detailItem?.name || ''),
                  size: detailItem?.size || 0, mod: detailItem?.mod || 0,
                }] })}
              style={{ background: A.paper, color: A.ink,
                border: '1px solid ' + A.line, borderRadius: 8,
                padding: '9px 12px', fontSize: 12, fontWeight: 600,
                cursor: 'pointer' }}>
              Delete this folder
            </button>
          </div>
        </Card>
      </div>
    </div>
  );
};

Object.assign(window, { POverview, PDrill, ITreemap, FAKE_APPS });
